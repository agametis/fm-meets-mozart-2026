# FileMaker-Integration

## Web-Viewer-Einrichtung

- FileMaker-Datei: `Offene Rechnungen.fmp12`
- Widget-ID für den Upload: `offeneRechnungen`
- Web-Viewer-Objektname: in FileMaker festlegen und in den unten genannten Schritten einsetzen
- **JavaScript darf FileMaker-Scripts ausführen** aktivieren
- FileMaker darf die JavaScript-Adapter erst aufrufen, wenn Web Viewer und Funktionen geladen sind

## Scriptvertrag

Alle über FMGofer aufgerufenen Scripts lesen zunächst dessen gemeinsamen Umschlag:

```text
Set Variable [ $scriptParameter ; Value: Get ( ScriptParameter ) ]
Set Variable [ $parameter ; Value: JSONGetElement ( $scriptParameter ; "parameter" ) ]
Set Variable [ $callbackName ; Value: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Set Variable [ $promiseID ; Value: JSONGetElement ( $scriptParameter ; "promiseID" ) ]
```

Erfolg wird mit `$promiseID, <Meldung>, False` bestätigt, ein Fehler mit
`$promiseID, <Fehlermeldung>, True` abgelehnt.

### `fmWidget_getData`

- Richtung: Widget → FileMaker → Widget
- Geschäftsparameter: keiner
- Ergebnis: JSON-Text im bestätigten Eingabevertrag
- Relevante Schritte:
  1. Die Rechnungsabfrage in FileMaker ausführen.
  2. `$payload` mit `meta.title`, `meta.currency`, `meta.locale` und dem Array `data`
     aufbauen.
  3. Jedes Element enthält `recordId`, `invoiceNumber`, `customer`, den numerischen
     `amount`, `dueDate` als `YYYY-MM-DD` und einen gültigen `status`.
  4. Callback ausführen:

```text
Perform JavaScript in Web Viewer [
  Object Name: <Web-Viewer-Objektname> ;
  Function Name: $callbackName ;
  Parameters: $promiseID, $payload, False
]
```

Bei einem Fehler wird anstelle von `$payload` eine verständliche Fehlermeldung mit `True`
zurückgegeben.

### `fmWidget_handleEvent`

- Richtung: Widget → FileMaker → Widget
- Parameter unter dem FMGofer-Umschlag:

```json
{
  "event": "save-changes",
  "data": {
    "updated": [
      {
        "recordId": "42",
        "changes": {
          "status": "paid"
        }
      }
    ],
    "created": [],
    "deleted": []
  }
}
```

- Ergebnis: Erfolgs- oder Fehlermeldung als Text
- Relevante Schritte:

```text
Set Variable [ $event ; Value: JSONGetElement ( $parameter ; "event" ) ]
Set Variable [ $updated ; Value: JSONGetElement ( $parameter ; "data.updated" ) ]
Set Variable [ $created ; Value: JSONGetElement ( $parameter ; "data.created" ) ]
Set Variable [ $deleted ; Value: JSONGetElement ( $parameter ; "data.deleted" ) ]

If [ $event ≠ "save-changes" ]
  # Callback mit "Unbekanntes Ereignis." und True
  Exit Script
End If

# Sicherstellen, dass created und deleted leer sind.
# Über die Elemente in $updated iterieren.
# recordId aus "[<index>].recordId" und Status aus
# "[<index>].changes.status" lesen.
# Nur status = "paid" akzeptieren.
# Den FileMaker-Datensatz ausschließlich über recordId ermitteln und aktualisieren.
# Bei vollständigem Erfolg Callback mit einer Erfolgsmeldung und False ausführen.
# Bei Validierungs-, Such- oder Schreibfehlern Callback mit einer Fehlermeldung und True ausführen.
```

Die konkrete Datensatzsuche und Transaktionsstrategie richtet sich nach dem vorhandenen
FileMaker-Datenmodell und wird nicht vom Widget vorgegeben.

### `fmWidget_reportData`

- Richtung: FileMaker → Widget → FileMaker
- Start: FileMaker ruft `fmWidgetRequestData` auf und beendet das auslösende Script.
- Parameter unter dem FMGofer-Umschlag:

```json
{
  "data": {
    "updated": [
      {
        "recordId": "42",
        "changes": {
          "status": "paid"
        }
      }
    ],
    "created": [],
    "deleted": []
  }
}
```

```text
Set Variable [ $data ; Value: JSONGetElement ( $parameter ; "data" ) ]
# Den aktuellen Änderungssatz verarbeiten.
# Callback mit Meldung und False oder Fehlermeldung und True ausführen.
```

Das aufrufende Script erwartet keinen direkten JavaScript-Rückgabewert.

### `fmWidget_reportState`

- Richtung: FileMaker → Widget → FileMaker
- Start: FileMaker ruft `fmWidgetRequestState` auf und beendet das auslösende Script.
- Parameter unter dem FMGofer-Umschlag: `{ "dirty": true }`

```text
Set Variable [ $dirty ; Value: JSONGetElement ( $parameter ; "dirty" ) ]
If [ $dirty ]
  # Fenster offen halten oder das Verwerfen ungespeicherter Änderungen bestätigen lassen.
Else
  # Schließen oder Navigation fortsetzen.
End If
# Callback mit Meldung und False oder Fehlermeldung und True ausführen.
```

FileMaker darf nicht auf JavaScript warten, während JavaScript auf dasselbe FileMaker-Script
wartet.

### `fmWidget_upload`

- Richtung: Upload-Werkzeug → FileMaker
- Parameter:

```json
{
  "thePath": "/absoluter/pfad/zu/dist/index.html",
  "widgetName": "offeneRechnungen"
}
```

Die vorhandene Uploadmechanik bleibt von den Laufzeit-Scripts getrennt.

## JavaScript-Einstiegspunkte

Für **JavaScript in Web Viewer ausführen** nur die globalen Funktionsnamen verwenden:

- `fmWidgetRefresh` ohne Parameter — Daten neu aus FileMaker abrufen
- `fmWidgetLoad` mit einer vollständigen Eingabe-Payload — Daten optional aktiv hineinschieben
- `fmWidgetRequestData` ohne Parameter — aktuellen Änderungssatz melden
- `fmWidgetRequestState` ohne Parameter — Dirty-State melden

Keine gepunkteten Namen wie `window.fmWidget.refresh` in diesem FileMaker-Scriptschritt verwenden.

## Speicher- und Dirty-State-Sequenz

1. Laden akzeptierter Daten setzt die Baseline und `dirty: false`.
2. Eine Bezahlt-Markierung erzeugt einen Eintrag in `data.updated` und setzt `dirty: true`.
3. Zurücknehmen der letzten Markierung setzt `dirty: false`.
4. Speichern startet `fmWidget_handleEvent` und wartet auf dessen Callback.
5. Bei Erfolg werden lokale `paid`-Status zur neuen Baseline; die Liste wird nicht neu geladen.
6. Bei Fehler bleiben Änderungssatz und Dirty-State erhalten.

## Manuelle Prüfung

- [ ] Web Viewer erlaubt JavaScript, FileMaker-Scripts auszuführen.
- [ ] Die Seite und ihre Adapter sind geladen, bevor FileMaker JavaScript aufruft.
- [ ] Der initiale Aufruf von `fmWidget_getData` lädt und formatiert die Rechnungsliste.
- [ ] `fmWidgetRefresh` lädt die aktuelle Liste manuell neu.
- [ ] Ein Save erreicht `fmWidget_handleEvent` mit ausschließlich geänderten `recordId`-Werten.
- [ ] Ein bestätigter Save zeigt die FM-Meldung, behält die Zeilen und setzt Dirty zurück.
- [ ] Ein abgelehnter Save zeigt den Fehler und bewahrt alle Markierungen.
- [ ] `fmWidgetRequestData` meldet den aktuellen Änderungssatz.
- [ ] `fmWidgetRequestState` meldet ausschließlich `{ "dirty": true|false }`.
- [ ] Leere, ungültige oder doppelte Datensätze erzeugen eine verständliche Fehlermeldung.
