# Offene Rechnungen — Umsetzungsplan

## Ziel

Eine aus FileMaker geladene Liste offener Rechnungen anzeigen, einzelne Rechnungen als bezahlt
vormerken und beim Speichern ausschließlich den Änderungssatz an FileMaker übermitteln.

## Bestätigte Benennung

- FileMaker-Datei: `Offene Rechnungen.fmp12`
- npm-Paket: `offene-rechnungen`
- Widget-ID: `offeneRechnungen`

## Primärer Ablauf

1. Das Widget ruft beim Öffnen automatisch `window.fmWidget.refresh()` auf.
2. `fmWidget_getData` liefert Metadaten und höchstens einige Hundert Rechnungen.
3. Das Widget sortiert nach Fälligkeit, hebt überfällige Rechnungen hervor und zeigt Anzahl sowie
   Gesamtsumme der nicht bezahlten Rechnungen.
4. Nutzer markieren eine oder mehrere Rechnungen als bezahlt und können jede Markierung vor dem
   Speichern zurücknehmen.
5. `Änderungen speichern` sendet alle vorgemerkten Statusänderungen gemeinsam.
6. Nach erfolgreicher FileMaker-Bestätigung bleiben die Rechnungen sichtbar, erscheinen lokal als
   bezahlt und bilden die neue Baseline. Es erfolgt kein automatischer Reload.
7. Bei einem Fehler bleiben Änderungen und Dirty-State erhalten.

Die Oberfläche berücksichtigt Laden, Bereit, Leer, Geändert, Speichern, Erfolg, Fehler und
ungültige Eingabedaten. Eine manuelle Aktualisierung bleibt verfügbar.

## Datenvertrag

Die Daten werden vom Widget über `fmWidget_getData` abgerufen:

```json
{
  "meta": {
    "title": "Offene Rechnungen",
    "currency": "EUR",
    "locale": "de-DE"
  },
  "data": [
    {
      "recordId": "42",
      "invoiceNumber": "RE-2026-1042",
      "customer": "Muster AG",
      "amount": 125.5,
      "dueDate": "2026-09-15",
      "status": "open"
    }
  ]
}
```

Alle Eigenschaften sind Pflichtfelder und dürfen weder fehlen noch `null` oder leer sein.
`recordId` ist die eindeutige, stabile FileMaker-Datensatz-ID. Datumswerte verwenden
`YYYY-MM-DD`, Beträge sind endliche Zahlen, und Statuswerte sind `open`, `overdue` oder
`paid`. Das Widget formatiert Beträge und Datumswerte mit `currency` und `locale`.

## Ausgabe und Zustand

`fmWidget_handleEvent` erhält:

```json
{
  "event": "save-changes",
  "data": {
    "updated": [
      {
        "recordId": "42",
        "changes": {
          "status": "paid"
        }
      }
    ],
    "created": [],
    "deleted": []
  }
}
```

Nicht geänderte Rechnungen werden nicht gesendet. `created` und `deleted` sind immer leer.
`fmWidgetRequestData` meldet den aktuellen Änderungssatz ohne `event` über
`fmWidget_reportData`. `fmWidgetRequestState` meldet ausschließlich
`{ "dirty": true|false }` über `fmWidget_reportState`.

Geladene oder erfolgreich gespeicherte Daten setzen die Baseline. Nur eine von FileMaker
bestätigte Speicherung setzt `dirty` zurück; eine abgelehnte Speicherung bewahrt den Entwurf.

## Stack

- React, TypeScript und Vite aus der Vorlage
- vorhandenes CSS für die responsive Oberfläche
- `useMemo` für Sortierung und Summenbildung
- TypeScript-Typen und explizite Laufzeitprüfungen für den festen Datenvertrag
- keine zusätzlichen Abhängigkeiten

## FileMaker-Änderungen

- `fmWidget_getData` erzeugt die bestätigte Eingabe-Payload.
- `fmWidget_handleEvent` verarbeitet ausschließlich `save-changes` und ordnet Updates über
  `recordId` zu.
- `fmWidget_reportData` nimmt den aktuellen Änderungssatz entgegen.
- `fmWidget_reportState` nimmt den Dirty-State entgegen.
- Im Web Viewer ist **JavaScript darf FileMaker-Scripts ausführen** aktiviert.
- Die konkreten Scriptparameter und Callback-Schritte stehen in `docs/FM-INTEGRATION.md`.

## Abnahmekriterien

- [ ] Gültige Daten laden automatisch und lassen sich manuell aktualisieren.
- [ ] Rechnungen erscheinen nach ISO-Fälligkeit sortiert und gemäß `locale` und `currency`
      formatiert.
- [ ] Überfällige Einträge sowie Anzahl und Gesamtsumme offener Rechnungen sind erkennbar.
- [ ] Bezahlt-Markierungen lassen sich vor dem Speichern zurücknehmen.
- [ ] Ohne Änderungen wird kein leerer Save ausgelöst.
- [ ] Der Save enthält nur geänderte `recordId`-Werte mit Status `paid`; `created` und
      `deleted` bleiben leer.
- [ ] Erfolg setzt lokalen Status und Dirty-State ohne Reload zurück.
- [ ] Fehler bewahren alle Änderungen.
- [ ] Leere und ungültige Eingaben werden verständlich behandelt.
- [ ] Der Produktions-Build enthält keine Beispieldaten und ist ASCII-sicher für WebDirect.

## Verifikation

- `npm run type-check`
- `npm run lint`
- `npm test` mit Vertrags-, Bridge-, Sortier-, Summen- und Änderungssatztests
- `npm run build`
- Sichtprüfung von `dist/index.html` auf Fixture-Werte
- manuelle FileMaker-Checkliste aus `docs/FM-INTEGRATION.md`

## Annahmen und spätere Fragen

- Pro Ladevorgang werden höchstens einige Hundert Rechnungen geliefert; Pagination und
  Virtualisierung sind nicht erforderlich.
- Der konkrete Web-Viewer-Objektname und die FileMaker-Geschäftslogik zur Datensatzsuche werden in
  FileMaker festgelegt.
- Das Widget ändert ausschließlich den Status vorhandener Datensätze auf `paid`.
