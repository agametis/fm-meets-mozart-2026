export const fmConfig = {
	server: "$",
	file: "Offene Rechnungen",
	uploadScript: "fmWidget_upload",
	widgetName: "offeneRechnungen",
};
