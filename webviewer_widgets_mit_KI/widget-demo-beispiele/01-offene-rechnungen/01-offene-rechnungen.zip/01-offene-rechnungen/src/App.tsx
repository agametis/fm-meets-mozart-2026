import { useEffect, useMemo, useRef, useState } from "react";

import { installFMWidgetApi, isMockMode } from "./fm/bridge";
import type { InvoiceRecord, WidgetPayload } from "./fm/types";
import {
	createInvoiceChangeSet,
	sortInvoicesByDueDate,
	summarizeOpenInvoices,
} from "./invoiceLogic";

type ViewStatus =
	| "waiting"
	| "loading"
	| "ready"
	| "processing"
	| "success"
	| "error";

function App() {
	const mockMode = isMockMode();
	const [meta, setMeta] = useState<WidgetPayload["meta"] | null>(null);
	const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
	const [baseline, setBaseline] = useState<InvoiceRecord[]>([]);
	const [status, setStatus] = useState<ViewStatus>("waiting");
	const [feedback, setFeedback] = useState("");
	const [error, setError] = useState("");
	const [mockRequest, setMockRequest] = useState<{
		script: string;
		parameter: unknown;
	} | null>(null);
	const invoicesRef = useRef(invoices);
	const baselineRef = useRef(baseline);
	const dirtyRef = useRef(false);
	const initialLoadStartedRef = useRef(false);

	const changes = useMemo(
		() => createInvoiceChangeSet(invoices, baseline),
		[invoices, baseline],
	);
	const dirty = changes.updated.length > 0;
	const sortedInvoices = useMemo(
		() => sortInvoicesByDueDate(invoices),
		[invoices],
	);
	const summary = useMemo(
		() => summarizeOpenInvoices(invoices),
		[invoices],
	);

	invoicesRef.current = invoices;
	baselineRef.current = baseline;
	dirtyRef.current = dirty;

	useEffect(() => {
		const applyPayload = (nextPayload: WidgetPayload) => {
			const nextInvoices = nextPayload.data.map((invoice) => ({ ...invoice }));
			setMeta(nextPayload.meta);
			setInvoices(nextInvoices);
			setBaseline(nextInvoices.map((invoice) => ({ ...invoice })));
			invoicesRef.current = nextInvoices;
			baselineRef.current = nextInvoices;
			dirtyRef.current = false;
			setError("");
			setFeedback("");
			setStatus("ready");
		};

		const uninstall = installFMWidgetApi({
			getData: () =>
				createInvoiceChangeSet(invoicesRef.current, baselineRef.current),
			getDirty: () => dirtyRef.current,
			onLoad: applyPayload,
			onError: (nextError) => {
				setError(nextError.message);
				setFeedback("");
				setStatus("error");
			},
			onRefreshStart: () => {
				setError("");
				setFeedback("");
				setStatus("loading");
			},
			onRequestStart: (request, preview) => {
				if (mockMode) setMockRequest(preview);
				setError("");
				setFeedback(
					request === "data"
						? "FileMaker verarbeitet den aktuellen Änderungssatz …"
						: request === "state"
							? "FileMaker verarbeitet den Widget-Status …"
							: "Änderungen werden in FileMaker gespeichert …",
				);
				setStatus("processing");
			},
			onRequestSuccess: (request, message) => {
				if (request === "event") {
					const savedInvoices = invoicesRef.current.map((invoice) => ({
						...invoice,
					}));
					setBaseline(savedInvoices);
					baselineRef.current = savedInvoices;
					dirtyRef.current = false;
				}
				setError("");
				setFeedback(message);
				setStatus("success");
			},
		});

		if (!initialLoadStartedRef.current) {
			initialLoadStartedRef.current = true;
			void window.fmWidget?.refresh();
		}

		return uninstall;
	}, [mockMode]);

	const locale = meta?.locale ?? "de-DE";
	const currency = meta?.currency ?? "EUR";
	const currencyFormatter = useMemo(
		() => new Intl.NumberFormat(locale, { style: "currency", currency }),
		[locale, currency],
	);
	const dateFormatter = useMemo(
		() => new Intl.DateTimeFormat(locale),
		[locale],
	);
	const busy = status === "loading" || status === "processing";

	const togglePaid = (recordId: string) => {
		const baselineInvoice = baselineRef.current.find(
			(invoice) => invoice.recordId === recordId,
		);
		if (!baselineInvoice || baselineInvoice.status === "paid") return;

		setInvoices((current) =>
			current.map((invoice) =>
				invoice.recordId === recordId
					? {
							...invoice,
							status:
								invoice.status === "paid"
									? baselineInvoice.status
									: "paid",
						}
					: invoice,
			),
		);
		setError("");
		setFeedback("");
		setStatus("ready");
	};

	return (
		<main className="app-shell">
			<header className="app-header">
				<div>
					<p className="eyebrow">Rechnungsübersicht</p>
					<h1>{meta?.title ?? "Offene Rechnungen"}</h1>
				</div>
				<p className="status" data-status={status} aria-live="polite">
					{status === "waiting" && "Warten auf Daten aus FileMaker …"}
					{status === "loading" && "Rechnungen werden geladen …"}
					{status === "ready" &&
						(mockMode ? "Expliziter Testmodus" : "Mit FileMaker verbunden")}
					{status === "processing" && feedback}
					{status === "success" && feedback}
					{status === "error" && "FileMaker konnte die Anfrage nicht verarbeiten."}
				</p>
			</header>

			{error && (
				<p className="message message-error" role="alert">
					{error}
				</p>
			)}

			<section className="summary" aria-label="Zusammenfassung">
				<div className="summary-card">
					<span>Noch offen</span>
					<strong>{summary.count}</strong>
					<small>{summary.count === 1 ? "Rechnung" : "Rechnungen"}</small>
				</div>
				<div className="summary-card summary-card-total">
					<span>Offene Gesamtsumme</span>
					<strong>{currencyFormatter.format(summary.total)}</strong>
					<small>inklusive überfälliger Beträge</small>
				</div>
			</section>

			<section className="invoice-panel" aria-labelledby="invoice-list-title">
				<div className="toolbar">
					<div>
						<h2 id="invoice-list-title">Rechnungen</h2>
						<p>
							Nach Fälligkeit sortiert
							{dirty && ` · ${changes.updated.length} geändert`}
						</p>
					</div>
					<div className="actions">
						<button
							type="button"
							className="button-secondary"
							disabled={busy}
							onClick={() => void window.fmWidget?.refresh()}
						>
							Aktualisieren
						</button>
						<button
							type="button"
							disabled={!dirty || busy}
							onClick={() => void window.fmWidget?.save()}
						>
							{status === "processing"
								? "Wird gespeichert …"
								: "Änderungen speichern"}
						</button>
					</div>
				</div>

				{sortedInvoices.length === 0 && status !== "loading" ? (
					<div className="empty-state">
						<strong>Keine Rechnungen vorhanden</strong>
						<p>FileMaker hat aktuell keine Datensätze geliefert.</p>
					</div>
				) : (
					<div className="table-wrap" aria-busy={busy}>
						<table>
							<thead>
								<tr>
									<th scope="col">Rechnung</th>
									<th scope="col">Kunde</th>
									<th scope="col">Fällig</th>
									<th scope="col" className="numeric">Betrag</th>
									<th scope="col">Status</th>
									<th scope="col" className="action-column">Aktion</th>
								</tr>
							</thead>
							<tbody>
								{sortedInvoices.map((invoice) => {
									const baselineStatus = baseline.find(
										(item) => item.recordId === invoice.recordId,
									)?.status;
									const pending =
										invoice.status === "paid" && baselineStatus !== "paid";
									const savedPaid =
										invoice.status === "paid" && baselineStatus === "paid";

									return (
										<tr
											key={invoice.recordId}
											className={
												invoice.status === "overdue"
													? "invoice-overdue"
													: pending
														? "invoice-pending"
														: ""
											}
										>
											<td data-label="Rechnung">
												<strong>{invoice.invoiceNumber}</strong>
											</td>
											<td data-label="Kunde">{invoice.customer}</td>
											<td data-label="Fällig">
												<time dateTime={invoice.dueDate}>
													{formatIsoDate(invoice.dueDate, dateFormatter)}
												</time>
											</td>
											<td data-label="Betrag" className="numeric amount">
												{currencyFormatter.format(invoice.amount)}
											</td>
											<td data-label="Status">
												<span className={`badge badge-${invoice.status}`}>
													{pending
														? "Als bezahlt markiert"
														: statusLabel(invoice.status)}
												</span>
											</td>
											<td data-label="Aktion" className="row-action">
												<button
													type="button"
													className="button-row"
													disabled={busy || savedPaid}
													onClick={() => togglePaid(invoice.recordId)}
												>
													{savedPaid
														? "Bezahlt"
														: pending
															? "Zurücknehmen"
															: "Als bezahlt markieren"}
												</button>
											</td>
										</tr>
									);
								})}
							</tbody>
						</table>
					</div>
				)}

				<footer className="panel-footer">
					<span className={`dirty-indicator ${dirty ? "is-dirty" : ""}`}>
						<span aria-hidden="true" />
						{dirty ? "Ungespeicherte Änderungen" : "Alle Änderungen gespeichert"}
					</span>
				</footer>
			</section>

			{mockMode && (
				<section className="mock-request" aria-live="polite">
					<p className="eyebrow">Testmodus</p>
					<h2>FileMaker-Anfragevorschau</h2>
					{mockRequest ? (
						<>
							<p>
								Zielscript: <code>{mockRequest.script}</code>
							</p>
							<pre>{JSON.stringify(mockRequest.parameter, null, 2)}</pre>
						</>
					) : (
						<p>
							Markiere eine Rechnung und speichere sie, um den Parameter zu
							prüfen.
						</p>
					)}
				</section>
			)}
		</main>
	);
}

function statusLabel(status: InvoiceRecord["status"]): string {
	if (status === "overdue") return "Überfällig";
	if (status === "paid") return "Bezahlt";
	return "Offen";
}

function formatIsoDate(date: string, formatter: Intl.DateTimeFormat): string {
	const [year, month, day] = date.split("-").map(Number);
	return formatter.format(new Date(year, month - 1, day));
}

export default App;
