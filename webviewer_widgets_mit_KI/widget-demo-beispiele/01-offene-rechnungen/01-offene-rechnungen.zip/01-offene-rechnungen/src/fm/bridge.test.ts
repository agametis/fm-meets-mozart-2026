import { afterEach, describe, expect, it, vi } from "vitest";

import type { InvoiceChangeSet, WidgetPayload } from "./types";

const { performScriptMock } = vi.hoisted(() => ({
	performScriptMock: vi.fn(),
}));

vi.mock("fm-gofer", () => ({
	default: { PerformScript: performScriptMock },
}));

import {
	createDirtyStatePayload,
	installFMWidgetApi,
	isMockMode,
	parseWidgetPayload,
} from "./bridge";

const documentedPayload: WidgetPayload = {
	meta: {
		title: "Offene Rechnungen",
		currency: "EUR",
		locale: "de-DE",
	},
	data: [
		{
			recordId: "42",
			invoiceNumber: "RE-2026-1042",
			customer: "Muster AG",
			amount: 125.5,
			dueDate: "2026-09-15",
			status: "open",
		},
	],
};

afterEach(() => {
	performScriptMock.mockReset();
	vi.unstubAllGlobals();
});

describe("parseWidgetPayload", () => {
	it("accepts the complete invoice contract", () => {
		expect(parseWidgetPayload(JSON.stringify(documentedPayload))).toEqual(
			documentedPayload,
		);
	});

	it("preserves German interface and customer text end to end", () => {
		const payload = {
			...documentedPayload,
			meta: { ...documentedPayload.meta, title: "Überfällige Rechnungen" },
			data: [
				{
					...documentedPayload.data[0],
					customer: "Müller & Söhne",
				},
			],
		};

		expect(parseWidgetPayload(payload)).toEqual(payload);
	});

	it("rejects missing fields because every contract value is required", () => {
		expect(() =>
			parseWidgetPayload({
				meta: documentedPayload.meta,
				data: [{ ...documentedPayload.data[0], customer: "" }],
			}),
		).toThrow('"data[0].customer"');
	});

	it("rejects invalid calendar dates and duplicate FileMaker record IDs", () => {
		expect(() =>
			parseWidgetPayload({
				...documentedPayload,
				data: [{ ...documentedPayload.data[0], dueDate: "2026-02-30" }],
			}),
		).toThrow('"data[0].dueDate"');

		expect(() =>
			parseWidgetPayload({
				...documentedPayload,
				data: [documentedPayload.data[0], documentedPayload.data[0]],
			}),
		).toThrow('"data[1].recordId" must be unique');
	});
});

describe("isMockMode", () => {
	it("enables mock data only for the explicit data=test URL parameter", () => {
		expect(isMockMode("?data=test")).toBe(true);
		expect(isMockMode("?data=production")).toBe(false);
		expect(isMockMode("?view=test")).toBe(false);
	});
});

describe("FM processing feedback", () => {
	it("fetches the current invoice payload through fmWidget_getData", async () => {
		const callbacks = installApi(emptyChangeSet());
		const json = vi.fn().mockResolvedValue(documentedPayload);
		performScriptMock.mockReturnValue({ json });

		await window.fmWidget?.refresh();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_getData");
		expect(json).toHaveBeenCalledOnce();
		expect(callbacks.onLoad).toHaveBeenCalledWith(documentedPayload);
	});

	it("reports only the current unsaved change set when FileMaker asks", async () => {
		const changes = onePaidChange();
		const callbacks = installApi(changes, true);
		mockFMResult("Änderungen empfangen");

		const adapterResult = window.fmWidgetRequestData?.();

		expect(adapterResult).toBeUndefined();
		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportData", {
			data: changes,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("data", {
			script: "fmWidget_reportData",
			parameter: { data: changes },
		});
		await vi.waitFor(() => {
			expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
				"data",
				"Änderungen empfangen",
			);
		});
	});

	it("reports only the dirty flag when FileMaker asks for state", async () => {
		const callbacks = installApi(onePaidChange(), true);
		mockFMResult("Status empfangen");

		await window.fmWidget?.requestState();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportState", {
			dirty: true,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("state", {
			script: "fmWidget_reportState",
			parameter: { dirty: true },
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"state",
			"Status empfangen",
		);
	});

	it("sends only approved changes and awaits FileMaker when saving", async () => {
		const changes = onePaidChange();
		const callbacks = installApi(changes, true);
		mockFMResult("Änderungen gespeichert");

		await window.fmWidget?.save();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_handleEvent", {
			event: "save-changes",
			data: changes,
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"event",
			"Änderungen gespeichert",
		);
	});

	it("does not send an empty save when nothing changed", async () => {
		installApi(emptyChangeSet(), false);

		await window.fmWidget?.save();

		expect(performScriptMock).not.toHaveBeenCalled();
	});

	it("reports an FM rejection without treating the save as successful", async () => {
		const callbacks = installApi(onePaidChange(), true);
		mockFMError("Datensatz konnte nicht aktualisiert werden");

		await window.fmWidget?.save();

		expect(callbacks.onError).toHaveBeenCalledWith(
			expect.objectContaining({
				message: "Datensatz konnte nicht aktualisiert werden",
			}),
		);
		expect(callbacks.onRequestSuccess).not.toHaveBeenCalled();
	});
});

describe("createDirtyStatePayload", () => {
	it("serializes only the dirty flag required by FileMaker", () => {
		expect(createDirtyStatePayload(true)).toBe('{"dirty":true}');
	});
});

function installApi(data: InvoiceChangeSet, dirty = false) {
	vi.stubGlobal("window", {
		FileMaker: { PerformScriptWithOption: vi.fn() },
		location: { search: "" },
	});

	const callbacks = {
		onError: vi.fn(),
		onLoad: vi.fn(),
		onRefreshStart: vi.fn(),
		onRequestStart: vi.fn(),
		onRequestSuccess: vi.fn(),
	};

	installFMWidgetApi({
		getData: () => data,
		getDirty: () => dirty,
		...callbacks,
	});

	return callbacks;
}

function emptyChangeSet(): InvoiceChangeSet {
	return { updated: [], created: [], deleted: [] };
}

function onePaidChange(): InvoiceChangeSet {
	return {
		updated: [{ recordId: "42", changes: { status: "paid" } }],
		created: [],
		deleted: [],
	};
}

function mockFMResult(message: string) {
	performScriptMock.mockReturnValue(Promise.resolve(message));
}

function mockFMError(message: string) {
	performScriptMock.mockReturnValue(Promise.reject(message));
}
