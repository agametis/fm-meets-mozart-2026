import FMGofer from "fm-gofer";

import type {
	InvoiceChangeSet,
	InvoiceRecord,
	InvoiceStatus,
	SaveChangesPayload,
	WidgetPayload,
} from "./types";

const FM_SCRIPTS = {
	getData: "fmWidget_getData",
	handleEvent: "fmWidget_handleEvent",
	reportData: "fmWidget_reportData",
	reportState: "fmWidget_reportState",
} as const;

type FMRequestKind = "data" | "state" | "event";

interface FMRequestPreview {
	script: string;
	parameter: unknown;
}

interface FMWidgetApi {
	load: (payload: string | WidgetPayload) => void;
	refresh: () => Promise<void>;
	requestData: () => Promise<void>;
	requestState: () => Promise<void>;
	save: () => Promise<void>;
}

interface InstallApiOptions {
	getData: () => InvoiceChangeSet;
	getDirty: () => boolean;
	onLoad: (payload: WidgetPayload) => void;
	onError: (error: Error) => void;
	onRefreshStart: () => void;
	onRequestStart: (request: FMRequestKind, preview: FMRequestPreview) => void;
	onRequestSuccess: (request: FMRequestKind, message: string) => void;
}

declare global {
	interface Window {
		fmWidget?: FMWidgetApi;
		fmWidgetLoad?: FMWidgetApi["load"];
		fmWidgetRefresh?: () => void;
		fmWidgetRequestData?: () => void;
		fmWidgetRequestState?: () => void;
	}
}

export function isMockMode(search = window.location.search): boolean {
	return (
		import.meta.env.DEV && new URLSearchParams(search).get("data") === "test"
	);
}

export function parseWidgetPayload(
	input: string | WidgetPayload,
): WidgetPayload {
	let parsed: unknown = input;
	if (typeof input === "string") {
		try {
			parsed = JSON.parse(input);
		} catch {
			throw new Error("The widget payload must contain valid JSON.");
		}
	}

	if (!parsed || typeof parsed !== "object") {
		throw new Error("The widget payload must be a JSON object.");
	}

	const candidate = parsed as { meta?: unknown; data?: unknown };
	if (
		!candidate.meta ||
		typeof candidate.meta !== "object" ||
		Array.isArray(candidate.meta)
	) {
		throw new Error('"meta" must be an object.');
	}

	const rawMeta = candidate.meta as Record<string, unknown>;
	const title = requireNonEmptyString(rawMeta.title, "meta.title");
	const currency = requireNonEmptyString(rawMeta.currency, "meta.currency");
	const locale = requireNonEmptyString(rawMeta.locale, "meta.locale");
	validateFormattingOptions(locale, currency);

	if (!Array.isArray(candidate.data)) {
		throw new Error('"data" must be an array.');
	}

	const recordIds = new Set<string>();
	const data = candidate.data.map((row, index): InvoiceRecord => {
		if (!row || typeof row !== "object" || Array.isArray(row)) {
			throw new Error(`"data[${index}]" must be an object.`);
		}

		const invoice = row as Record<string, unknown>;
		const recordId = requireNonEmptyString(
			invoice.recordId,
			`data[${index}].recordId`,
		);
		if (recordIds.has(recordId)) {
			throw new Error(`"data[${index}].recordId" must be unique.`);
		}
		recordIds.add(recordId);

		const amount = invoice.amount;
		if (typeof amount !== "number" || !Number.isFinite(amount)) {
			throw new Error(`"data[${index}].amount" must be a finite number.`);
		}

		const dueDate = requireNonEmptyString(
			invoice.dueDate,
			`data[${index}].dueDate`,
		);
		if (!isIsoDate(dueDate)) {
			throw new Error(
				`"data[${index}].dueDate" must use the YYYY-MM-DD format.`,
			);
		}

		const status = invoice.status;
		if (!isInvoiceStatus(status)) {
			throw new Error(
				`"data[${index}].status" must be "open", "overdue", or "paid".`,
			);
		}

		return {
			recordId,
			invoiceNumber: requireNonEmptyString(
				invoice.invoiceNumber,
				`data[${index}].invoiceNumber`,
			),
			customer: requireNonEmptyString(
				invoice.customer,
				`data[${index}].customer`,
			),
			amount,
			dueDate,
			status,
		};
	});

	return { meta: { title, currency, locale }, data };
}

export function createDirtyStatePayload(dirty: boolean): string {
	return JSON.stringify({ dirty });
}

async function fetchWidgetPayload(): Promise<WidgetPayload> {
	if (import.meta.env.DEV && isMockMode()) {
		const { samplePayload } = await import("../sampleData");
		return samplePayload;
	}

	return FMGofer.PerformScript(FM_SCRIPTS.getData).json<WidgetPayload>();
}

function processInFM(script: string, parameter: unknown): Promise<string> {
	if (!window.FileMaker) {
		return Promise.reject(new Error("FileMaker is unavailable."));
	}

	return FMGofer.PerformScript(script, parameter);
}

export function installFMWidgetApi(options: InstallApiOptions): () => void {
	const api: FMWidgetApi = {
		load(payload) {
			try {
				options.onLoad(parseWidgetPayload(payload));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async refresh() {
			options.onRefreshStart();
			try {
				options.onLoad(parseWidgetPayload(await fetchWidgetPayload()));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestData() {
			const parameter = { data: options.getData() };
			options.onRequestStart("data", {
				script: FM_SCRIPTS.reportData,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportData, parameter);
				options.onRequestSuccess("data", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestState() {
			const parameter = { dirty: options.getDirty() };
			options.onRequestStart("state", {
				script: FM_SCRIPTS.reportState,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportState, parameter);
				options.onRequestSuccess("state", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async save() {
			if (!options.getDirty()) return;

			const parameter: SaveChangesPayload = {
				event: "save-changes",
				data: options.getData(),
			};
			options.onRequestStart("event", {
				script: FM_SCRIPTS.handleEvent,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.handleEvent, parameter);
				options.onRequestSuccess("event", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
	};

	window.fmWidget = api;
	window.fmWidgetLoad = api.load;
	window.fmWidgetRefresh = () => {
		void api.refresh();
	};
	window.fmWidgetRequestData = () => {
		void api.requestData();
	};
	window.fmWidgetRequestState = () => {
		void api.requestState();
	};

	return () => {
		if (window.fmWidget === api) {
			window.fmWidget = undefined;
			window.fmWidgetLoad = undefined;
			window.fmWidgetRefresh = undefined;
			window.fmWidgetRequestData = undefined;
			window.fmWidgetRequestState = undefined;
		}
	};
}

function requireNonEmptyString(value: unknown, path: string): string {
	if (typeof value !== "string" || value.trim() === "") {
		throw new Error(`"${path}" must be a non-empty string.`);
	}
	return value;
}

function isInvoiceStatus(value: unknown): value is InvoiceStatus {
	return value === "open" || value === "overdue" || value === "paid";
}

function isIsoDate(value: string): boolean {
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
	if (!match) return false;

	const year = Number(match[1]);
	const month = Number(match[2]);
	const day = Number(match[3]);
	const date = new Date(Date.UTC(year, month - 1, day));
	return (
		date.getUTCFullYear() === year &&
		date.getUTCMonth() === month - 1 &&
		date.getUTCDate() === day
	);
}

function validateFormattingOptions(locale: string, currency: string): void {
	try {
		new Intl.NumberFormat(locale);
	} catch {
		throw new Error('"meta.locale" must be a supported locale.');
	}

	try {
		new Intl.NumberFormat(locale, { style: "currency", currency });
	} catch {
		throw new Error('"meta.currency" must be a supported currency code.');
	}
}

function normalizeError(error: unknown): Error {
	return error instanceof Error ? error : new Error(String(error));
}
