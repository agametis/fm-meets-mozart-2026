export type InvoiceStatus = "open" | "overdue" | "paid";

export interface InvoiceRecord {
	recordId: string;
	invoiceNumber: string;
	customer: string;
	amount: number;
	dueDate: string;
	status: InvoiceStatus;
}

export interface WidgetPayload {
	meta: {
		title: string;
		currency: string;
		locale: string;
	};
	data: InvoiceRecord[];
}

export interface InvoiceUpdate {
	recordId: string;
	changes: {
		status: "paid";
	};
}

export interface InvoiceChangeSet {
	updated: InvoiceUpdate[];
	created: [];
	deleted: [];
}

export interface SaveChangesPayload {
	event: "save-changes";
	data: InvoiceChangeSet;
}
