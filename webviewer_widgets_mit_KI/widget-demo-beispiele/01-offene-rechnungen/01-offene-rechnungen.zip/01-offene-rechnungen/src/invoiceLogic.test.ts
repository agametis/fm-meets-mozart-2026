import { describe, expect, it } from "vitest";

import type { InvoiceRecord } from "./fm/types";
import {
	createInvoiceChangeSet,
	sortInvoicesByDueDate,
	summarizeOpenInvoices,
} from "./invoiceLogic";

const invoices: InvoiceRecord[] = [
	{
		recordId: "57",
		invoiceNumber: "RE-2026-1057",
		customer: "Beispiel GmbH",
		amount: 89.9,
		dueDate: "2026-09-20",
		status: "open",
	},
	{
		recordId: "63",
		invoiceNumber: "RE-2026-1063",
		customer: "Mozart & Partner",
		amount: 460,
		dueDate: "2026-09-08",
		status: "overdue",
	},
];

describe("invoice list logic", () => {
	it("sorts ISO due dates without mutating FileMaker's input order", () => {
		const sorted = sortInvoicesByDueDate(invoices);

		expect(sorted.map((invoice) => invoice.recordId)).toEqual(["63", "57"]);
		expect(invoices.map((invoice) => invoice.recordId)).toEqual(["57", "63"]);
	});

	it("counts and totals only invoices that are not paid", () => {
		const withPaidInvoice: InvoiceRecord[] = [
			...invoices,
			{ ...invoices[0], recordId: "99", amount: 25, status: "paid" },
		];

		expect(summarizeOpenInvoices(withPaidInvoice)).toEqual({
			count: 2,
			total: 549.9,
		});
	});

	it("creates only paid status updates against the loaded baseline", () => {
		const edited = invoices.map((invoice) =>
			invoice.recordId === "63" ? { ...invoice, status: "paid" as const } : invoice,
		);

		expect(createInvoiceChangeSet(edited, invoices)).toEqual({
			updated: [{ recordId: "63", changes: { status: "paid" } }],
			created: [],
			deleted: [],
		});
		expect(createInvoiceChangeSet(invoices, invoices)).toEqual({
			updated: [],
			created: [],
			deleted: [],
		});
	});
});
