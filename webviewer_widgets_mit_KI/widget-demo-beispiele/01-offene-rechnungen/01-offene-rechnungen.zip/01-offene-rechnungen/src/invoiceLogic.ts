import type { InvoiceChangeSet, InvoiceRecord } from "./fm/types";

export function sortInvoicesByDueDate(
	invoices: InvoiceRecord[],
): InvoiceRecord[] {
	return [...invoices].sort(
		(left, right) =>
			left.dueDate.localeCompare(right.dueDate) ||
			left.invoiceNumber.localeCompare(right.invoiceNumber),
	);
}

export function summarizeOpenInvoices(invoices: InvoiceRecord[]): {
	count: number;
	total: number;
} {
	return invoices.reduce(
		(summary, invoice) => {
			if (invoice.status !== "paid") {
				summary.count += 1;
				summary.total += invoice.amount;
			}
			return summary;
		},
		{ count: 0, total: 0 },
	);
}

export function createInvoiceChangeSet(
	invoices: InvoiceRecord[],
	baseline: InvoiceRecord[],
): InvoiceChangeSet {
	const baselineStatuses = new Map(
		baseline.map((invoice) => [invoice.recordId, invoice.status]),
	);

	return {
		updated: invoices
			.filter(
				(invoice) =>
					invoice.status === "paid" &&
					baselineStatuses.has(invoice.recordId) &&
					baselineStatuses.get(invoice.recordId) !== "paid",
			)
			.map((invoice) => ({
				recordId: invoice.recordId,
				changes: { status: "paid" },
			})),
		created: [],
		deleted: [],
	};
}
