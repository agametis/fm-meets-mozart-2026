import type { WidgetPayload } from "./fm/types";

export const samplePayload: WidgetPayload & {
	__sampleDataModule: true;
} = {
	__sampleDataModule: true,
	meta: {
		title: "Offene Rechnungen",
		currency: "EUR",
		locale: "de-DE",
	},
	data: [
		{
			recordId: "42",
			invoiceNumber: "RE-2026-1042",
			customer: "Muster AG",
			amount: 125.5,
			dueDate: "2026-09-15",
			status: "open",
		},
		{
			recordId: "57",
			invoiceNumber: "RE-2026-1057",
			customer: "Beispiel GmbH",
			amount: 89.9,
			dueDate: "2026-09-20",
			status: "open",
		},
		{
			recordId: "63",
			invoiceNumber: "RE-2026-1063",
			customer: "Mozart & Partner",
			amount: 460,
			dueDate: "2026-09-08",
			status: "overdue",
		},
	],
};
