# FileMaker-Integration — Projektzeitstrahl

Diese Datei beschreibt nur, was dieses Widget benötigt. Die `.fmp12`-Datei wird
nicht automatisch bearbeitet; die Schritte sind in FileMaker Pro anzulegen.

## Web-Viewer-Einrichtung

- Objektname vergeben, zum Beispiel `wvProjektzeitstrahl`. Dieser Name wird in
  jedem Schritt **JavaScript in Web Viewer ausführen** gebraucht.
- **JavaScript darf FileMaker-Scripts ausführen** muss aktiviert sein.
- FileMaker kann JavaScript erst aufrufen, wenn Seite und Funktion geladen sind.
  Das Widget ruft beim Start selbst `fmWidget_getData` auf; ein Push mit
  `fmWidgetLoad` direkt beim Layoutwechsel kann deshalb zu früh kommen.

## JavaScript-Einstiegspunkte

Im Schritt **JavaScript in Web Viewer ausführen** ausschließlich diese globalen
Funktionsnamen verwenden, niemals einen Namen mit Punkt:

| Funktion | Parameter | Zweck |
| --- | --- | --- |
| `fmWidgetLoad` | JSON-Text der Nutzlast | Daten aktiv ins Widget schieben |
| `fmWidgetRefresh` | keiner | Widget holt sich die Daten neu |
| `fmWidgetRequestData` | keiner | Widget meldet die aktuelle Auswahl |
| `fmWidgetRequestState` | keiner | Widget meldet den Änderungszustand |

Die drei Anfrage-Adapter kehren sofort zurück. Das aufrufende FileMaker-Script
darf keinen Rückgabewert erwarten und muss enden.

## Script-Verträge

### `fmWidget_getData`

- Richtung: Widget → FileMaker, Antwort als JSON
- Wird beim Start automatisch und bei „Aktualisieren" aufgerufen
- Ergebnis: die Nutzlast aus [PLAN.md](PLAN.md), Abschnitt Datenvertrag

```text
Set Variable [ $scriptParameter ; Value: Get ( ScriptParameter ) ]
Set Variable [ $callbackName ; Value: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Set Variable [ $promiseID ; Value: JSONGetElement ( $scriptParameter ; "promiseID" ) ]

# Gesamtzeitraum und Kopfdaten des aktuellen Projekts.
Set Variable [ $meta ; Value:
  JSONSetElement ( "{}" ;
    [ "title"      ; Projekt::Bezeichnung        ; JSONString ] ;
    [ "projectId"  ; Projekt::ID                 ; JSONString ] ;
    [ "rangeStart" ; Projekt::Startdatum         ; JSONString ] ;
    [ "rangeEnd"   ; Projekt::Enddatum           ; JSONString ] ;
    [ "locale"     ; "de-DE"                     ; JSONString ]
  )
]

# Aufgaben des Projekts durchlaufen und $items als JSON-Array aufbauen.
# Datumsfelder mit einer Formel im Format YYYY-MM-DD ausgeben, zum Beispiel:
#   Year ( Aufgabe::Start ) & "-" &
#   Right ( "0" & Month ( Aufgabe::Start ) ; 2 ) & "-" &
#   Right ( "0" & Day   ( Aufgabe::Start ) ; 2 )
# Je Aufgabe:
#   JSONSetElement ( "{}" ;
#     [ "recordId"  ; Aufgabe::ID          ; JSONString ] ;
#     [ "title"     ; Aufgabe::Bezeichnung ; JSONString ] ;
#     [ "phase"     ; Aufgabe::Phase       ; JSONString ] ;
#     [ "startDate" ; $isoStart            ; JSONString ] ;
#     [ "endDate"   ; $isoEnde             ; JSONString ] ;
#     [ "status"    ; Aufgabe::Status      ; JSONString ] ;
#     [ "type"      ; $typ                 ; JSONString ]
#   )
# und mit JSONSetElement ( $items ; "[" & $index & "]" ; $item ; JSONObject ) anhaengen.

Set Variable [ $payload ; Value:
  JSONSetElement (
    JSONSetElement ( "{}" ; "meta" ; $meta ; JSONObject ) ;
    "data" ; $items ; JSONArray
  )
]

Perform JavaScript in Web Viewer [
  Object Name: "wvProjektzeitstrahl" ;
  Function Name: $callbackName ;
  Parameters: $promiseID, $payload, False
]
```

Bei einem Fehler stattdessen mit Meldung und `True` zurückweisen; der Text
erscheint als Fehlermeldung im Widget.

Wichtig: `phase` muss in der gewünschten Reihenfolge geliefert werden. Die
Zeilenreihenfolge des Zeitstrahls ergibt sich aus dem ersten Vorkommen einer
Phase im Array — also die Aufgaben nach Phasenreihenfolge sortieren.

`type` ist `"milestone"`, wenn Start- und Enddatum identisch sind oder die
Aufgabe in FileMaker als Meilenstein gekennzeichnet ist, sonst `"task"`.

### `fmWidget_handleEvent`

- Richtung: Widget → FileMaker, erwidert über FMGofer
- Einziges Ereignis dieses Widgets: `select-record`

Parameter unterhalb des Umschlags:

```json
{
  "event": "select-record",
  "data": { "projectId": "P-1007", "recordId": "A-101" }
}
```

```text
Set Variable [ $scriptParameter ; Value: Get ( ScriptParameter ) ]
Set Variable [ $parameter    ; Value: JSONGetElement ( $scriptParameter ; "parameter" ) ]
Set Variable [ $callbackName ; Value: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Set Variable [ $promiseID    ; Value: JSONGetElement ( $scriptParameter ; "promiseID" ) ]

Set Variable [ $event     ; Value: JSONGetElement ( $parameter ; "event" ) ]
Set Variable [ $projectId ; Value: JSONGetElement ( $parameter ; "data.projectId" ) ]
Set Variable [ $recordId  ; Value: JSONGetElement ( $parameter ; "data.recordId" ) ]

If [ $event = "select-record" ]
  # Datensatz suchen oder merken. Kein Fensterwechsel, der den Web Viewer neu aufbaut,
  # solange die Antwort noch aussteht.
  Perform JavaScript in Web Viewer [
    Object Name: "wvProjektzeitstrahl" ;
    Function Name: $callbackName ;
    Parameters: $promiseID, "Datensatz " & $recordId & " ausgewählt.", False
  ]
Else
  Perform JavaScript in Web Viewer [
    Object Name: "wvProjektzeitstrahl" ;
    Function Name: $callbackName ;
    Parameters: $promiseID, "Unbekanntes Ereignis: " & $event, True
  ]
End If
```

### `fmWidget_reportData`

- Richtung: FileMaker fragt an über `fmWidgetRequestData`, das Widget antwortet
- Parameter: `{ "data": { "projectId": "P-1007", "recordId": "A-101" } }`
- Beide Werte sind `null`, wenn nichts ausgewählt ist

```text
Set Variable [ $recordId ; Value: JSONGetElement ( $parameter ; "data.recordId" ) ]
# Auswahl verarbeiten, dann mit Meldung und False aufloesen bzw. mit True zurueckweisen.
```

Das Script, das `fmWidgetRequestData` aufgerufen hat, muss danach enden.

### `fmWidget_reportState`

- Richtung: FileMaker fragt an über `fmWidgetRequestState`
- Parameter: **immer** `{ "dirty": false }`

Das Widget bearbeitet keine fachlichen Daten und meldet deshalb nie ungespeicherte
Änderungen. Ein Schließen-Ablauf kann sich darauf verlassen und braucht keine
Rückfrage. Der Aufruf bleibt erhalten, damit ein gemeinsamer Schließen-Ablauf für
alle Widgets unverändert funktioniert.

```text
Set Variable [ $dirty ; Value: JSONGetElement ( $parameter ; "dirty" ) ]
# Ist hier stets "false": Schliessen oder Navigation fortsetzen.
# Mit Meldung und False aufloesen.
```

### `fmWidget_upload`

Unverändert aus der Vorlage. Erhält von `fm/fmUpload.js`:

```json
{ "thePath": "/absoluter/pfad/zu/dist/index.html", "widgetName": "projektzeitstrahl" }
```

## Manuelle Prüfliste in FileMaker

- [ ] Web Viewer hat einen Objektnamen und **JavaScript darf FileMaker-Scripts ausführen** ist aktiv
- [ ] Beim Öffnen des Layouts lädt der Zeitstrahl ohne weiteres Zutun
- [ ] „Aktualisieren" lädt die Daten erneut
- [ ] `fmWidgetLoad` mit einer neuen Projekt-Nutzlast tauscht den Zeitstrahl aus und setzt die Auswahl zurück
- [ ] Klick auf eine Aufgabe hebt sie hervor und erreicht `fmWidget_handleEvent` mit `select-record`
- [ ] Klick auf einen Meilenstein liefert dieselbe Struktur
- [ ] Ein zurückgewiesener Callback zeigt die Fehlermeldung im Widget, der Zeitstrahl bleibt sichtbar
- [ ] `fmWidgetRequestData` meldet die aktuelle Auswahl, auch `null` wenn nichts gewählt ist
- [ ] `fmWidgetRequestState` meldet `dirty: false`
- [ ] Ein Datensatz mit leerem Start- oder Enddatum erscheint in der Hinweisliste, der übrige Zeitstrahl bleibt vollständig
- [ ] Umlaute in Aufgabentiteln erscheinen im Web Viewer korrekt, auch in WebDirect
