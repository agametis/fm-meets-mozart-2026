# Projektzeitstrahl — Umsetzungsplan

Freigegeben am 2026-09-09.

## Ziel

Die Aufgaben und Meilensteine eines kleinen Projekts (bis etwa 30 Einträge) als
waagerechten Zeitstrahl im FileMaker Web Viewer darstellen, gruppiert nach Phase.
Ein Klick meldet den gewählten Datensatz an FileMaker zurück. Das Widget zeigt
nur an und bearbeitet keine fachlichen Daten.

## Bestätigte Benennung

- FileMaker-Datei: `Projektzeitstrahl.fmp12`
- npm-Paket: `projektzeitstrahl`
- Widget-Kennung: `projektzeitstrahl`
- `fmConfig.server` bleibt `"$"` (lokale Datei)

## Ablauf

1. Der Web Viewer lädt das Widget; es ruft automatisch `window.fmWidget.refresh()`
   auf und holt die Daten über `fmWidget_getData`.
2. Wechselt der Projektkontext, schiebt FileMaker die Daten mit
   `fmWidgetLoad( $json )` nach.
3. Das Widget zeichnet je Phase eine Zeile. Position und Breite ergeben sich aus
   Start- und Enddatum im Gesamtzeitraum.
4. Der Benutzer wechselt zwischen Tages- und Wochenansicht und scrollt waagerecht.
5. Ein Klick auf eine Aufgabe oder einen Meilenstein hebt den Eintrag sofort
   hervor und sendet `select-record` an `fmWidget_handleEvent`.
6. Die Rückmeldung von FileMaker erscheint in der Statuszeile.

## Datenvertrag

Richtung: FileMaker → Widget, als JSON-Text oder Objekt.

```json
{
  "meta": {
    "title": "Website Relaunch",
    "projectId": "P-1007",
    "rangeStart": "2026-09-01",
    "rangeEnd": "2026-10-15",
    "locale": "de-DE"
  },
  "data": [
    {
      "recordId": "A-101",
      "title": "Anforderungen abstimmen",
      "phase": "Planung",
      "startDate": "2026-09-01",
      "endDate": "2026-09-05",
      "status": "done",
      "type": "task"
    },
    {
      "recordId": "M-105",
      "title": "Go-live",
      "phase": "Abschluss",
      "startDate": "2026-10-12",
      "endDate": "2026-10-12",
      "status": "open",
      "type": "milestone"
    }
  ]
}
```

- Identifikatoren: `meta.projectId` und `recordId`. Beide gehen unverändert im
  Ereignis an FileMaker zurück.
- `data` ist ein Array. `meta` ist optional.
- `phase` ist ein Klartextname. Die Reihenfolge der Zeilen ergibt sich aus dem
  ersten Vorkommen einer Phase im Array.
- `status` darf leer oder unbekannt sein und wird dann neutral dargestellt.
- Bei `type: "milestone"` wird `endDate` ignoriert; gezeichnet wird `startDate`.
- Datumsformat ist ausschließlich `YYYY-MM-DD`.

### Zweistufige Prüfung

`parseWidgetPayload` in `src/fm/bridge.ts` prüft nur die **Struktur** und wirft
einen Fehler mit dem betroffenen JSON-Pfad, wenn `data` kein Array ist, wenn
`recordId`, `title` oder `phase` fehlen oder wenn `type` unbekannt ist. Dann wird
nichts dargestellt.

Datumswerte werden dort bewusst **nicht** hart geprüft. Die fachliche Prüfung
erfolgt in `buildTimeline` in `src/timeline.ts`, damit ein einzelner kaputter
Eintrag nicht den gesamten Zeitstrahl verwirft:

| Fall | Verhalten |
| --- | --- |
| `startDate` leer, unparsbar oder ein Rolldatum wie `2026-02-31` | nicht gezeichnet, Hinweis |
| `endDate` einer Aufgabe unbrauchbar | nicht gezeichnet, Hinweis |
| `endDate` vor `startDate` | nicht gezeichnet, Hinweis |
| vollständig außerhalb `rangeStart`..`rangeEnd` | nicht gezeichnet, Hinweis mit beiden Daten |
| teilweise außerhalb | auf den Rand beschnitten, Schnittkante markiert, gezeichnet |

Fehlen `meta.rangeStart` und `meta.rangeEnd` oder sind sie unbrauchbar, wird der
Zeitraum aus den gültigen Daten berechnet und ein Hinweis angezeigt.

## Ausgabe und Zustand

Das Widget ist ein reines Anzeige-Widget: kein Speichern-Button, keine
Bearbeitung, `dirty` ist konstant `false`.

Ereignis an `fmWidget_handleEvent`:

```json
{
  "event": "select-record",
  "data": { "projectId": "P-1007", "recordId": "A-101" }
}
```

Der Aufruf wird über FMGofer erwidert. Die Hervorhebung erfolgt sofort und lokal,
unabhängig von der Antwort; die Antwort erscheint in der Statuszeile.

`fmWidget_reportData` erhält die aktuelle Auswahl in derselben Form
(`{ "data": { "projectId", "recordId" } }`, beide `null` wenn nichts gewählt ist).
`fmWidget_reportState` erhält immer `{ "dirty": false }`.

## Stack

Keine neuen Abhängigkeiten. React, TypeScript und Vite genügen: Der Zeitstrahl
ist CSS Grid mit absolut positionierten Balken, das Scrollen ist nativ
(`overflow-x: auto`), und die Phasenspalte bleibt über `position: sticky` stehen —
Achse und Balken scrollen dadurch ohne eine Zeile JavaScript synchron. Keine
Zeitstrahl-Bibliothek, kein Icon-Paket, kein Tailwind, kein Runtime-Schema.

## FileMaker-Änderungen

Siehe [FM-INTEGRATION.md](FM-INTEGRATION.md). Die `.fmp12`-Datei wird nicht
automatisch bearbeitet.

## Abnahmekriterien

- [ ] `?data=test` zeigt den Zeitstrahl mit allen Phasenzeilen; ohne diesen Parameter
      und in jedem Produktions-Build wird ausschließlich die FM-Bridge benutzt
- [ ] Der Wechsel zwischen Tages- und Wochenansicht ändert die Skalierung, die
      Auswahl bleibt erhalten
- [ ] Waagerechtes Scrollen bewegt Achse und Balken gemeinsam, die Phasenspalte
      bleibt stehen
- [ ] Ein Klick hebt den Eintrag hervor und sendet `select-record` mit
      `projectId` und `recordId`
- [ ] Ein Meilenstein wird als Zeitpunkt gezeichnet, nicht als Balken
- [ ] Ein Eintrag mit ungültigem Datum erscheint in der Hinweisliste, alle
      übrigen werden normal dargestellt
- [ ] Leeres `data` zeigt den Leerzustand, keinen Fehler
- [ ] `fmWidget_reportState` meldet `dirty: false`
- [ ] `dist/index.html` enthält keine Fixture-Werte, die Ausgabe ist reines ASCII

## Prüfung

```bash
npm run type-check
npm run lint
npm test
npm run build
```

Der Build führt zusätzlich `forbid-dev-only-modules` und
`scripts/verify-build-encoding.js` aus. Die FileMaker-Prüfliste steht in
[FM-INTEGRATION.md](FM-INTEGRATION.md).

## Annahmen und offene Punkte

1. Die Phasenreihenfolge ergibt sich aus dem ersten Vorkommen in `data`.
   FileMaker muss das Array entsprechend sortiert liefern.
2. Unbekannte `status`-Werte werden neutral dargestellt, nicht als Fehler.
3. Überlappende Aufgaben derselben Phase werden auf Unterzeilen verteilt
   (Greedy, erste freie Unterzeile).
4. Die Auswahl wird bei jedem Neuladen zurückgesetzt.
5. Fehlt `meta.locale`, gilt `de-DE`.
6. Die Fixture in `src/sampleData.ts` erweitert die fünf gelieferten
   Beispieleinträge auf 26, damit Unterzeilen, Scrollen, Wochenansicht und die
   Hinweisliste real geprüft werden können.
7. Offen: ob FileMaker nach `select-record` selbst navigiert oder nur den
   gewählten Datensatz merkt. Das Widget ändert daran nichts.
