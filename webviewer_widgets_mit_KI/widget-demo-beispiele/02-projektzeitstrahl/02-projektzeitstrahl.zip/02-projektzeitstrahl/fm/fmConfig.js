export const fmConfig = {
	server: "$",
	file: "Projektzeitstrahl",
	uploadScript: "fmWidget_upload",
	widgetName: "projektzeitstrahl",
};
