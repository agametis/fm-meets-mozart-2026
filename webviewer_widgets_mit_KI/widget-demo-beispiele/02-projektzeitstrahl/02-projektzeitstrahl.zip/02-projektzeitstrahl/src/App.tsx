import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";

import { installFMWidgetApi, isMockMode } from "./fm/bridge";
import type { SelectRecordData, TimelineItem, WidgetPayload } from "./fm/types";
import {
	buildTicks,
	buildTimeline,
	formatDate,
	toDayNumber,
	type TimelineView,
} from "./timeline";

/** Spaltenbreite je Tag in Pixeln, je Ansicht. */
const PX_PER_DAY: Record<TimelineView, number> = { day: 32, week: 12 };

const STATUS_LABELS: Record<string, string> = {
	done: "erledigt",
	active: "laufend",
	open: "offen",
};

function App() {
	const mockMode = isMockMode();
	const [payload, setPayload] = useState<WidgetPayload | null>(null);
	const [view, setView] = useState<TimelineView>("day");
	const [selected, setSelected] = useState<string | null>(null);
	const [status, setStatus] = useState<
		"waiting" | "loading" | "ready" | "processing" | "success" | "error"
	>("waiting");
	const [feedback, setFeedback] = useState("");
	const [error, setError] = useState("");
	const [mockRequest, setMockRequest] = useState<{
		script: string;
		parameter: unknown;
	} | null>(null);

	const selectionRef = useRef<SelectRecordData>({
		projectId: null,
		recordId: null,
	});
	const initialLoadStartedRef = useRef(false);

	selectionRef.current = {
		projectId: payload?.meta?.projectId ?? null,
		recordId: selected,
	};

	useEffect(() => {
		const uninstall = installFMWidgetApi({
			getData: () => selectionRef.current,
			// Das Widget bearbeitet keine fachlichen Daten, daher nie ungespeichert.
			getDirty: () => false,
			onLoad: (nextPayload) => {
				setPayload(nextPayload);
				setSelected(null);
				setError("");
				setFeedback("");
				setStatus("ready");
			},
			onError: (nextError) => {
				setError(nextError.message);
				setFeedback("");
				setStatus("error");
			},
			onRefreshStart: () => {
				setError("");
				setFeedback("");
				setStatus("loading");
			},
			onRequestStart: (request, preview) => {
				if (mockMode) {
					setMockRequest(preview);
				}
				setError("");
				setFeedback(
					request === "event"
						? "FileMaker verarbeitet die Auswahl..."
						: request === "state"
							? "FileMaker verarbeitet den Widget-Zustand..."
							: "FileMaker verarbeitet die aktuellen Daten...",
				);
				setStatus("processing");
			},
			onRequestSuccess: (_request, message) => {
				setError("");
				setFeedback(message);
				setStatus("success");
			},
		});

		if (!initialLoadStartedRef.current) {
			initialLoadStartedRef.current = true;
			void window.fmWidget?.refresh();
		}

		return uninstall;
	}, [mockMode]);

	const model = useMemo(
		() => (payload ? buildTimeline(payload) : null),
		[payload],
	);
	const ticks = useMemo(
		() => (model ? buildTicks(model, view) : []),
		[model, view],
	);

	const pxPerDay = PX_PER_DAY[view];
	const title = payload?.meta?.title ?? "Projektzeitstrahl";
	const todayOffset =
		model?.rangeStart == null
			? null
			: offsetIfInside(
					toDayNumber(new Date().toISOString().slice(0, 10)),
					model.rangeStart,
					model.dayCount,
				);

	const selectItem = (item: TimelineItem) => {
		setSelected(item.recordId);
		void window.fmWidget?.sendEvent("select-record", {
			projectId: payload?.meta?.projectId ?? null,
			recordId: item.recordId,
		});
	};

	return (
		<main className="app-shell">
			<header>
				<p className="eyebrow">Projektzeitstrahl</p>
				<h1>{title}</h1>
				<p className="status" data-status={status}>
					{status === "waiting" && "Warte auf Daten aus FileMaker."}
					{status === "loading" && "Daten werden geladen..."}
					{status === "ready" &&
						(mockMode
							? "Expliziter Mock-Modus"
							: "Mit FileMaker verbunden")}
					{(status === "processing" || status === "success") && feedback}
					{status === "error" &&
						"FileMaker konnte die Anfrage nicht verarbeiten."}
				</p>
			</header>

			{error && <p className="error-message">{error}</p>}

			<section className="card">
				<div className="actions">
					<div className="view-switch" role="group" aria-label="Ansicht">
						<button
							type="button"
							aria-pressed={view === "day"}
							onClick={() => setView("day")}
						>
							Tage
						</button>
						<button
							type="button"
							aria-pressed={view === "week"}
							onClick={() => setView("week")}
						>
							Wochen
						</button>
					</div>
					<button type="button" onClick={() => void window.fmWidget?.refresh()}>
						Aktualisieren
					</button>
				</div>

				{model === null ? (
					<p className="empty-state">
						Noch keine Daten geladen.
						{mockMode
							? ""
							: " FileMaker liefert sie über fmWidget_getData oder fmWidgetLoad."}
					</p>
				) : model.phases.length === 0 ? (
					<p className="empty-state">
						Keine darstellbaren Aufgaben im Projektzeitraum.
					</p>
				) : (
					<>
						<div className="timeline-scroll">
							<div
								className="timeline-grid"
								style={{
									"--px-per-day": `${pxPerDay}px`,
									"--day-count": model.dayCount,
								} as CSSProperties}
							>
								<div className="phase-label header-cell" />
								<div className="track header-track">
									{ticks.map((tick) => (
										<span
											key={tick.offset}
											className="tick"
											data-major={tick.major || undefined}
											style={{ left: `calc(${tick.offset} * var(--px-per-day))` }}
										>
											{tick.label}
										</span>
									))}
								</div>

								{model.phases.map((phase) => (
									<Fragment key={phase.phase}>
										<div className="phase-label">{phase.phase}</div>
										<div
											className="track"
											style={{ "--lane-count": phase.laneCount } as CSSProperties}
										>
											{phase.items.map((placed) => {
												const isMilestone = placed.item.type === "milestone";
												const left = `calc(${placed.offset} * var(--px-per-day))`;

												return (
													<button
														key={placed.item.recordId}
														type="button"
														className={isMilestone ? "milestone" : "bar"}
														data-status={placed.item.status || "unknown"}
														data-clipped-start={placed.clippedStart || undefined}
														data-clipped-end={placed.clippedEnd || undefined}
														aria-pressed={selected === placed.item.recordId}
														title={describe(placed, model.locale)}
														style={{
															left,
															top: `calc(${placed.lane} * var(--lane-height))`,
															...(isMilestone
																? {}
																: {
																		width: `calc(${placed.span} * var(--px-per-day))`,
																	}),
														}}
														onClick={() => selectItem(placed.item)}
													>
														<span>{placed.item.title}</span>
													</button>
												);
											})}
										</div>
									</Fragment>
								))}

								{todayOffset !== null && (
									<div
										className="today-line"
										aria-hidden="true"
										style={{ left: `calc(${todayOffset} * var(--px-per-day))` }}
									/>
								)}
							</div>
						</div>

						<ul className="legend">
							{Object.entries(STATUS_LABELS).map(([key, label]) => (
								<li key={key}>
									<span className="swatch" data-status={key} />
									{label}
								</li>
							))}
							<li>
								<span className="swatch" data-status="unknown" />
								ohne Status
							</li>
							<li>
								<span className="swatch swatch-milestone" />
								Meilenstein
							</li>
						</ul>
					</>
				)}

				{model?.rangeFromData && (
					<p className="notice">
						Kein Zeitraum in meta.rangeStart / meta.rangeEnd gefunden. Der
						Zeitstrahl wurde aus den Aufgabendaten berechnet.
					</p>
				)}

				{model !== null && model.issues.length > 0 && (
					<details className="issues" open>
						<summary>
							{model.issues.length === 1
								? "1 Eintrag wird nicht dargestellt"
								: `${model.issues.length} Einträge werden nicht dargestellt`}
						</summary>
						<ul>
							{model.issues.map((issue) => (
								<li key={issue.recordId}>
									<code>{issue.recordId}</code> {issue.title} &ndash;{" "}
									{issue.reason}
								</li>
							))}
						</ul>
					</details>
				)}

				<output className="dirty-state" aria-live="polite">
					Ungespeicherte Änderungen: <strong>nein</strong> (Anzeige-Widget)
				</output>
			</section>

			{mockMode && (
				<section className="mock-request" aria-live="polite">
					<p className="eyebrow">Mock-Modus</p>
					<h2>FileMaker-Anfrage</h2>
					{mockRequest ? (
						<>
							<p>
								Zielscript: <code>{mockRequest.script}</code>
							</p>
							<pre>{JSON.stringify(mockRequest.parameter, null, 2)}</pre>
						</>
					) : (
						<p>
							Klicke einen Eintrag an, oder lass FileMaker
							<code>fmWidgetRequestData</code> beziehungsweise
							<code>fmWidgetRequestState</code> aufrufen, um den Parameter zu
							sehen.
						</p>
					)}
				</section>
			)}
		</main>
	);
}

function offsetIfInside(
	day: number | null,
	rangeStart: number,
	dayCount: number,
): number | null {
	if (day === null) return null;
	const offset = day - rangeStart;
	return offset >= 0 && offset < dayCount ? offset : null;
}

function describe(
	placed: { item: TimelineItem; clippedStart: boolean; clippedEnd: boolean },
	locale: string,
): string {
	const start = toDayNumber(placed.item.startDate);
	const startText = start === null ? placed.item.startDate : formatDate(start, locale);

	if (placed.item.type === "milestone") {
		return `${placed.item.title} - Meilenstein am ${startText}`;
	}

	const end = toDayNumber(placed.item.endDate);
	const endText = end === null ? placed.item.endDate : formatDate(end, locale);
	const statusText = STATUS_LABELS[placed.item.status] ?? placed.item.status;
	const clipped =
		placed.clippedStart || placed.clippedEnd
			? " (auf den Projektzeitraum beschnitten)"
			: "";

	return `${placed.item.title} - ${startText} bis ${endText}${statusText ? ` - ${statusText}` : ""}${clipped}`;
}

export default App;
