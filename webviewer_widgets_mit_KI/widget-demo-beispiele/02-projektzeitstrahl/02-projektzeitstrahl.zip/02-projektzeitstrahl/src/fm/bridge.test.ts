import { afterEach, describe, expect, it, vi } from "vitest";

const { performScriptMock } = vi.hoisted(() => ({
	performScriptMock: vi.fn(),
}));

vi.mock("fm-gofer", () => ({
	default: { PerformScript: performScriptMock },
}));

import {
	createDirtyStatePayload,
	installFMWidgetApi,
	isMockMode,
	parseWidgetPayload,
} from "./bridge";
import type { SelectRecordData } from "./types";

const TASK = {
	recordId: "A-101",
	title: "Anforderungen abstimmen",
	phase: "Planung",
	startDate: "2026-09-01",
	endDate: "2026-09-05",
	status: "done",
	type: "task" as const,
};

afterEach(() => {
	performScriptMock.mockReset();
	vi.unstubAllGlobals();
});

describe("parseWidgetPayload", () => {
	it("accepts the documented meta and data contract", () => {
		expect(
			parseWidgetPayload(
				JSON.stringify({
					meta: { title: "Website Relaunch", projectId: "P-1007" },
					data: [TASK],
				}),
			),
		).toEqual({
			meta: { title: "Website Relaunch", projectId: "P-1007" },
			data: [TASK],
		});
	});

	it("preserves German umlauts in interface data", () => {
		const title = "Barrierefreiheit prüfen, Größe messen, Straße";

		expect(
			parseWidgetPayload({ data: [{ ...TASK, title }] }).data[0].title,
		).toBe(title);
	});

	it("rejects payloads that cannot drive the widget", () => {
		expect(() => parseWidgetPayload('{"data":{}}')).toThrow('"data"');
		expect(() =>
			parseWidgetPayload({ data: [{ ...TASK, recordId: "" }] }),
		).toThrow('"data[0].recordId"');
		expect(() =>
			parseWidgetPayload({
				data: [{ ...TASK, type: "note" as unknown as "task" }],
			}),
		).toThrow('"data[0].type"');
	});

	it("keeps unusable dates instead of rejecting the whole payload", () => {
		// Die fachliche Datumsprüfung gehört in buildTimeline, damit ein einzelner
		// kaputter Eintrag nicht den gesamten Zeitstrahl verwirft.
		const parsed = parseWidgetPayload({
			data: [{ ...TASK, startDate: "", endDate: "" }],
		});

		expect(parsed.data[0].startDate).toBe("");
	});

	it("defaults an absent status to an empty string", () => {
		const { status, ...withoutStatus } = TASK;
		void status;

		expect(
			parseWidgetPayload({
				data: [withoutStatus as unknown as typeof TASK],
			}).data[0].status,
		).toBe("");
	});
});

describe("isMockMode", () => {
	it("enables mock data only for the data=test URL parameter", () => {
		expect(isMockMode("?data=test")).toBe(true);
		expect(isMockMode("?data=production")).toBe(false);
		expect(isMockMode("?view=test")).toBe(false);
	});
});

describe("FM processing feedback", () => {
	it("awaits FM processing when FileMaker requests current widget data", async () => {
		const selection = { projectId: "P-1007", recordId: "A-101" };
		const callbacks = installApi(selection);
		mockFMResult("Data processed");

		const adapterResult = window.fmWidgetRequestData?.();

		expect(adapterResult).toBeUndefined();
		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportData", {
			data: selection,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("data", {
			script: "fmWidget_reportData",
			parameter: { data: selection },
		});
		await vi.waitFor(() => {
			expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
				"data",
				"Data processed",
			);
		});
	});

	it("always reports dirty false, because the widget never edits data", async () => {
		const callbacks = installApi({ projectId: "P-1007", recordId: null });
		mockFMResult("State processed");

		await window.fmWidget?.requestState();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportState", {
			dirty: false,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("state", {
			script: "fmWidget_reportState",
			parameter: { dirty: false },
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"state",
			"State processed",
		);
	});

	it("sends select-record as event and data to fmWidget_handleEvent", async () => {
		const callbacks = installApi({ projectId: "P-1007", recordId: null });
		mockFMResult("Record selected");

		await window.fmWidget?.sendEvent("select-record", {
			projectId: "P-1007",
			recordId: "A-103",
		});

		const parameter = {
			event: "select-record",
			data: { projectId: "P-1007", recordId: "A-103" },
		};
		expect(performScriptMock).toHaveBeenCalledWith(
			"fmWidget_handleEvent",
			parameter,
		);
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("event", {
			script: "fmWidget_handleEvent",
			parameter,
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"event",
			"Record selected",
		);
	});

	it("reports an FM processing failure to the interface", async () => {
		const callbacks = installApi({ projectId: "P-1007", recordId: "A-101" });
		mockFMError("Validation failed");

		await window.fmWidget?.requestData();

		expect(callbacks.onError).toHaveBeenCalledWith(
			expect.objectContaining({ message: "Validation failed" }),
		);
		expect(callbacks.onRequestSuccess).not.toHaveBeenCalled();
	});
});

describe("createDirtyStatePayload", () => {
	it("reports only the dirty flag required by FM", () => {
		expect(createDirtyStatePayload(false)).toBe('{"dirty":false}');
	});
});

function installApi(selection: SelectRecordData) {
	vi.stubGlobal("window", {
		FileMaker: { PerformScriptWithOption: vi.fn() },
	});

	const callbacks = {
		onError: vi.fn(),
		onLoad: vi.fn(),
		onRefreshStart: vi.fn(),
		onRequestStart: vi.fn(),
		onRequestSuccess: vi.fn(),
	};

	installFMWidgetApi({
		getData: () => selection,
		getDirty: () => false,
		...callbacks,
	});

	return callbacks;
}

function mockFMResult(message: string) {
	performScriptMock.mockReturnValue(Promise.resolve(message));
}

function mockFMError(message: string) {
	performScriptMock.mockReturnValue(Promise.reject(message));
}
