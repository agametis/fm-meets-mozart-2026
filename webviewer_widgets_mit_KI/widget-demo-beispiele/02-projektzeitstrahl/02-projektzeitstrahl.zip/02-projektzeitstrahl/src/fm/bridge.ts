import FMGofer from "fm-gofer";

import type { SelectRecordData, TimelineItem, WidgetPayload } from "./types";

const FM_SCRIPTS = {
	getData: "fmWidget_getData",
	handleEvent: "fmWidget_handleEvent",
	reportData: "fmWidget_reportData",
	reportState: "fmWidget_reportState",
} as const;

type FMRequestKind = "data" | "state" | "event";

interface FMRequestPreview {
	script: string;
	parameter: unknown;
}

interface FMWidgetApi {
	load: (payload: string | WidgetPayload) => void;
	refresh: () => Promise<void>;
	requestData: () => Promise<void>;
	requestState: () => Promise<void>;
	/** Sendet ein Ereignis als { event, data } an fmWidget_handleEvent. */
	sendEvent: (event: string, data: unknown) => Promise<void>;
}

interface InstallApiOptions {
	getData: () => SelectRecordData;
	getDirty: () => boolean;
	onLoad: (payload: WidgetPayload) => void;
	onError: (error: Error) => void;
	onRefreshStart: () => void;
	onRequestStart: (request: FMRequestKind, preview: FMRequestPreview) => void;
	onRequestSuccess: (request: FMRequestKind, message: string) => void;
}

declare global {
	interface Window {
		fmWidget?: FMWidgetApi;
		fmWidgetLoad?: FMWidgetApi["load"];
		fmWidgetRefresh?: () => void;
		fmWidgetRequestData?: () => void;
		fmWidgetRequestState?: () => void;
	}
}

export function isMockMode(search = window.location.search): boolean {
	return (
		import.meta.env.DEV && new URLSearchParams(search).get("data") === "test"
	);
}

/**
 * Prüft die Struktur der Nutzlast. Datumswerte werden hier bewusst nur als
 * Zeichenkette geprüft: Ein einzelnes ungültiges Datum darf nicht den gesamten
 * Zeitstrahl verwerfen. Die fachliche Datumsprüfung erfolgt in buildTimeline
 * und erscheint als Hinweisliste in der Oberfläche.
 */
export function parseWidgetPayload(
	input: string | WidgetPayload,
): WidgetPayload {
	let parsed: unknown = input;
	if (typeof input === "string") {
		try {
			parsed = JSON.parse(input);
		} catch {
			throw new Error("The widget payload must contain valid JSON.");
		}
	}

	if (!parsed || typeof parsed !== "object") {
		throw new Error("The widget payload must be a JSON object.");
	}

	const candidate = parsed as Partial<WidgetPayload>;
	if (!Array.isArray(candidate.data)) {
		throw new Error('The widget payload must contain an array at "data".');
	}

	const data = candidate.data.map((row, index) => {
		const item = (row ?? {}) as Partial<TimelineItem>;

		if (typeof item.recordId !== "string" || item.recordId === "") {
			throw new Error(`"data[${index}].recordId" must be a non-empty string.`);
		}
		if (typeof item.title !== "string") {
			throw new Error(`"data[${index}].title" must be a string.`);
		}
		if (typeof item.phase !== "string" || item.phase === "") {
			throw new Error(`"data[${index}].phase" must be a non-empty string.`);
		}
		if (item.type !== "task" && item.type !== "milestone") {
			throw new Error(`"data[${index}].type" must be "task" or "milestone".`);
		}

		return {
			recordId: item.recordId,
			title: item.title,
			phase: item.phase,
			startDate: typeof item.startDate === "string" ? item.startDate : "",
			endDate: typeof item.endDate === "string" ? item.endDate : "",
			status: typeof item.status === "string" ? item.status : "",
			type: item.type,
		};
	});

	return { meta: candidate.meta, data };
}

export function createDirtyStatePayload(dirty: boolean): string {
	return JSON.stringify({ dirty });
}

async function fetchWidgetPayload(): Promise<WidgetPayload> {
	if (import.meta.env.DEV && isMockMode()) {
		const { samplePayload } = await import("../sampleData");
		return samplePayload;
	}

	return FMGofer.PerformScript(FM_SCRIPTS.getData).json<WidgetPayload>();
}

function processInFM(script: string, parameter: unknown): Promise<string> {
	if (!window.FileMaker) {
		return Promise.reject(new Error("FileMaker is unavailable."));
	}

	return FMGofer.PerformScript(script, parameter);
}

export function installFMWidgetApi(options: InstallApiOptions): () => void {
	const api: FMWidgetApi = {
		load(payload) {
			try {
				options.onLoad(parseWidgetPayload(payload));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async refresh() {
			options.onRefreshStart();
			try {
				options.onLoad(parseWidgetPayload(await fetchWidgetPayload()));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestData() {
			const parameter = { data: options.getData() };
			options.onRequestStart("data", {
				script: FM_SCRIPTS.reportData,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportData, parameter);
				options.onRequestSuccess("data", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestState() {
			const parameter = { dirty: options.getDirty() };
			options.onRequestStart("state", {
				script: FM_SCRIPTS.reportState,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportState, parameter);
				options.onRequestSuccess("state", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async sendEvent(event, data) {
			const parameter = { event, data };
			options.onRequestStart("event", {
				script: FM_SCRIPTS.handleEvent,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.handleEvent, parameter);
				options.onRequestSuccess("event", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
	};

	window.fmWidget = api;
	window.fmWidgetLoad = api.load;
	window.fmWidgetRefresh = () => {
		void api.refresh();
	};
	window.fmWidgetRequestData = () => {
		void api.requestData();
	};
	window.fmWidgetRequestState = () => {
		void api.requestState();
	};

	return () => {
		if (window.fmWidget === api) {
			window.fmWidget = undefined;
			window.fmWidgetLoad = undefined;
			window.fmWidgetRefresh = undefined;
			window.fmWidgetRequestData = undefined;
			window.fmWidgetRequestState = undefined;
		}
	};
}

function normalizeError(error: unknown): Error {
	return error instanceof Error ? error : new Error(String(error));
}
