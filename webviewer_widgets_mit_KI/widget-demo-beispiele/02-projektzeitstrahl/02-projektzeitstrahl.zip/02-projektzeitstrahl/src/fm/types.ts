/** Eintrag auf dem Zeitstrahl: Aufgabe oder Meilenstein. */
export interface TimelineItem {
	recordId: string;
	title: string;
	phase: string;
	/** ISO-Datum YYYY-MM-DD. Fachliche Prüfung erfolgt in timeline.ts. */
	startDate: string;
	/** ISO-Datum YYYY-MM-DD. Bei type "milestone" ohne Bedeutung. */
	endDate: string;
	/** "done", "active", "open" oder ein projektspezifischer Wert. */
	status: string;
	type: "task" | "milestone";
}

export interface WidgetPayload {
	meta?: {
		title?: string;
		projectId?: string;
		/** Gesamtzeitraum des Zeitstrahls, ISO-Datum. */
		rangeStart?: string;
		rangeEnd?: string;
		locale?: string;
	};
	data: TimelineItem[];
}

/** Nutzlast des Ereignisses "select-record" an fmWidget_handleEvent. */
export interface SelectRecordData {
	projectId: string | null;
	recordId: string | null;
}
