import type { WidgetPayload } from "./fm/types";

/**
 * Entwicklungs-Fixture. Nur über den dynamischen Import hinter
 * import.meta.env.DEV erreichbar; das Plugin forbid-dev-only-modules in
 * vite.config.ts lässt den Produktions-Build fehlschlagen, falls dieses Modul
 * doch Code beiträgt.
 */
export const samplePayload: WidgetPayload & {
	__sampleDataModule: true;
} = {
	__sampleDataModule: true,
	meta: {
		title: "Website Relaunch",
		projectId: "P-1007",
		rangeStart: "2026-09-01",
		rangeEnd: "2026-10-15",
		locale: "de-DE",
	},
	data: [
		// Planung: überlappende Aufgaben erzwingen mehrere Unterzeilen.
		{ recordId: "M-108", title: "Projektstart", phase: "Planung", startDate: "2026-09-01", endDate: "2026-09-01", status: "done", type: "milestone" },
		{ recordId: "A-101", title: "Anforderungen abstimmen", phase: "Planung", startDate: "2026-09-01", endDate: "2026-09-05", status: "done", type: "task" },
		{ recordId: "A-109", title: "Altsystem sichten", phase: "Planung", startDate: "2026-08-25", endDate: "2026-09-03", status: "done", type: "task" },
		{ recordId: "A-106", title: "Gespräche mit Beteiligten", phase: "Planung", startDate: "2026-09-02", endDate: "2026-09-08", status: "done", type: "task" },
		{ recordId: "A-107", title: "Budget freigeben", phase: "Planung", startDate: "2026-09-03", endDate: "2026-09-04", status: "done", type: "task" },

		{ recordId: "A-110", title: "Informationsarchitektur", phase: "Konzeption", startDate: "2026-09-07", endDate: "2026-09-12", status: "done", type: "task" },
		{ recordId: "A-102", title: "Gestaltung freigeben", phase: "Konzeption", startDate: "2026-09-08", endDate: "2026-09-16", status: "active", type: "task" },
		{ recordId: "A-111", title: "Inhaltsinventar erstellen", phase: "Konzeption", startDate: "2026-09-09", endDate: "2026-09-18", status: "active", type: "task" },
		{ recordId: "M-112", title: "Konzept abgenommen", phase: "Konzeption", startDate: "2026-09-18", endDate: "2026-09-18", status: "open", type: "milestone" },

		{ recordId: "A-103", title: "Widget umsetzen", phase: "Umsetzung", startDate: "2026-09-17", endDate: "2026-10-02", status: "open", type: "task" },
		{ recordId: "A-113", title: "Vorlagen bauen", phase: "Umsetzung", startDate: "2026-09-18", endDate: "2026-09-30", status: "active", type: "task" },
		{ recordId: "A-114", title: "Inhalte migrieren", phase: "Umsetzung", startDate: "2026-09-22", endDate: "2026-10-06", status: "open", type: "task" },
		{ recordId: "A-115", title: "Schnittstelle anbinden", phase: "Umsetzung", startDate: "2026-09-25", endDate: "2026-10-01", status: "open", type: "task" },
		{ recordId: "A-116", title: "Barrierefreiheit prüfen", phase: "Umsetzung", startDate: "2026-09-28", endDate: "2026-10-05", status: "open", type: "task" },
		{ recordId: "M-117", title: "Funktionsumfang steht", phase: "Umsetzung", startDate: "2026-10-02", endDate: "2026-10-02", status: "open", type: "milestone" },

		{ recordId: "A-118", title: "Testfälle schreiben", phase: "Test", startDate: "2026-09-29", endDate: "2026-10-03", status: "open", type: "task" },
		{ recordId: "A-119", title: "Systemtest", phase: "Test", startDate: "2026-10-05", endDate: "2026-10-09", status: "open", type: "task" },
		{ recordId: "A-120", title: "Fehler beheben", phase: "Test", startDate: "2026-10-07", endDate: "2026-10-12", status: "open", type: "task" },
		// Leerer Status: muss neutral dargestellt werden, nicht als Fehler.
		{ recordId: "A-121", title: "Lasttest", phase: "Test", startDate: "2026-10-08", endDate: "2026-10-10", status: "", type: "task" },

		{ recordId: "A-104", title: "Abnahme durchführen", phase: "Abschluss", startDate: "2026-10-05", endDate: "2026-10-09", status: "open", type: "task" },
		{ recordId: "A-122", title: "Schulung vorbereiten", phase: "Abschluss", startDate: "2026-10-06", endDate: "2026-10-11", status: "open", type: "task" },
		{ recordId: "A-123", title: "Dokumentation abschließen", phase: "Abschluss", startDate: "2026-10-09", endDate: "2026-10-14", status: "open", type: "task" },
		{ recordId: "M-105", title: "Go-live", phase: "Abschluss", startDate: "2026-10-12", endDate: "2026-10-12", status: "open", type: "milestone" },

		// Absichtliche Fehlerfälle für die Hinweisliste.
		{ recordId: "A-124", title: "Nachbetreuung", phase: "Abschluss", startDate: "2026-10-20", endDate: "2026-10-25", status: "open", type: "task" },
		{ recordId: "A-125", title: "Abschlussbericht", phase: "Abschluss", startDate: "2026-10-14", endDate: "2026-10-10", status: "open", type: "task" },
		{ recordId: "A-126", title: "Übergabe an den Betrieb", phase: "Abschluss", startDate: "", endDate: "", status: "open", type: "task" },
	],
};
