import { describe, expect, it } from "vitest";

import type { TimelineItem, WidgetPayload } from "./fm/types";
import { buildTicks, buildTimeline, isoWeek, toDayNumber } from "./timeline";

function task(overrides: Partial<TimelineItem>): TimelineItem {
	return {
		recordId: "A-1",
		title: "Aufgabe",
		phase: "Planung",
		startDate: "2026-09-01",
		endDate: "2026-09-05",
		status: "open",
		type: "task",
		...overrides,
	};
}

function payload(
	data: TimelineItem[],
	meta: WidgetPayload["meta"] = {
		rangeStart: "2026-09-01",
		rangeEnd: "2026-10-15",
	},
): WidgetPayload {
	return { meta, data };
}

describe("toDayNumber", () => {
	it("parses ISO dates as UTC day numbers", () => {
		const first = toDayNumber("2026-09-01");
		const second = toDayNumber("2026-09-02");

		expect(first).not.toBeNull();
		expect((second as number) - (first as number)).toBe(1);
	});

	it("rejects unusable values instead of rolling them over", () => {
		expect(toDayNumber("")).toBeNull();
		expect(toDayNumber("01.09.2026")).toBeNull();
		expect(toDayNumber("2026-02-31")).toBeNull();
		expect(toDayNumber("2026-13-01")).toBeNull();
	});
});

describe("isoWeek", () => {
	it("follows ISO 8601 across the year boundary", () => {
		// 2026-01-01 ist ein Donnerstag, gehoert daher zu KW 1 -
		// ebenso der Montag davor, 2025-12-29.
		expect(isoWeek(toDayNumber("2026-01-01") as number)).toBe(1);
		expect(isoWeek(toDayNumber("2025-12-29") as number)).toBe(1);
		expect(isoWeek(toDayNumber("2020-12-31") as number)).toBe(53);
	});
});

describe("buildTimeline", () => {
	it("positions a task relative to the range start", () => {
		const model = buildTimeline(
			payload([task({ startDate: "2026-09-03", endDate: "2026-09-05" })]),
		);

		expect(model.dayCount).toBe(45);
		expect(model.phases[0].items[0]).toMatchObject({
			offset: 2,
			span: 3,
			clippedStart: false,
			clippedEnd: false,
		});
	});

	it("keeps phases in first-appearance order", () => {
		const model = buildTimeline(
			payload([
				task({ recordId: "A-1", phase: "Planung" }),
				task({ recordId: "A-2", phase: "Umsetzung" }),
				task({ recordId: "A-3", phase: "Planung" }),
			]),
		);

		expect(model.phases.map((phase) => phase.phase)).toEqual([
			"Planung",
			"Umsetzung",
		]);
	});

	it("treats a milestone as a single point and ignores its end date", () => {
		const model = buildTimeline(
			payload([
				task({
					type: "milestone",
					startDate: "2026-09-10",
					endDate: "2026-09-30",
				}),
			]),
		);

		expect(model.phases[0].items[0]).toMatchObject({ offset: 9, span: 1 });
	});

	it("moves overlapping tasks of one phase into separate lanes", () => {
		const model = buildTimeline(
			payload([
				task({ recordId: "A-1", startDate: "2026-09-01", endDate: "2026-09-10" }),
				task({ recordId: "A-2", startDate: "2026-09-05", endDate: "2026-09-12" }),
				task({ recordId: "A-3", startDate: "2026-09-20", endDate: "2026-09-22" }),
			]),
		);

		expect(model.phases[0].laneCount).toBe(2);
		expect(model.phases[0].items.map((placed) => placed.lane)).toEqual([
			0, 1, 0,
		]);
	});

	it("clips a task that reaches beyond the range and marks the cut", () => {
		const model = buildTimeline(
			payload([task({ startDate: "2026-08-25", endDate: "2026-09-03" })]),
		);

		expect(model.phases[0].items[0]).toMatchObject({
			offset: 0,
			span: 3,
			clippedStart: true,
			clippedEnd: false,
		});
		expect(model.issues).toHaveLength(0);
	});

	it("reports unusable and out-of-range entries without dropping the rest", () => {
		const model = buildTimeline(
			payload([
				task({ recordId: "A-1" }),
				task({ recordId: "A-2", startDate: "", endDate: "" }),
				task({ recordId: "A-3", startDate: "2026-10-14", endDate: "2026-10-10" }),
				task({ recordId: "A-4", startDate: "2026-10-20", endDate: "2026-10-25" }),
			]),
		);

		expect(model.phases[0].items).toHaveLength(1);
		expect(model.issues.map((issue) => issue.recordId)).toEqual([
			"A-2",
			"A-3",
			"A-4",
		]);
		expect(model.issues[1].reason).toContain("Enddatum");
		expect(model.issues[2].reason).toContain("außerhalb");
	});

	it("falls back to the data range when meta has none", () => {
		const model = buildTimeline(
			payload(
				[task({ startDate: "2026-09-10", endDate: "2026-09-12" })],
				{ title: "Ohne Zeitraum" },
			),
		);

		expect(model.rangeFromData).toBe(true);
		expect(model.dayCount).toBe(3);
	});

	it("returns an empty model when no range can be determined", () => {
		const model = buildTimeline(
			payload([task({ startDate: "", endDate: "" })], {}),
		);

		expect(model.rangeStart).toBeNull();
		expect(model.phases).toHaveLength(0);
		expect(model.issues).toHaveLength(1);
	});
});

describe("buildTicks", () => {
	it("labels every day in the day view", () => {
		const model = buildTimeline(payload([task({})]));
		const ticks = buildTicks(model, "day");

		expect(ticks).toHaveLength(45);
		expect(ticks[0].label).toBe("1.9.");
	});

	it("labels calendar weeks in the week view", () => {
		const model = buildTimeline(payload([task({})]));
		const ticks = buildTicks(model, "week");

		// 2026-09-01 ist ein Dienstag: erst der Rangbeginn, dann jeder Montag.
		expect(ticks[0].offset).toBe(0);
		expect(ticks[1].offset).toBe(6);
		expect(ticks.every((tick) => tick.label.startsWith("KW "))).toBe(true);
	});
});
