import type { TimelineItem, WidgetPayload } from "./fm/types";

const MS_PER_DAY = 86_400_000;
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

export type TimelineView = "day" | "week";

/** Ein Eintrag mit fertiger, auf den Zeitraum beschnittener Position. */
export interface PlacedItem {
	item: TimelineItem;
	/** Tage seit Zeitraumbeginn, bereits beschnitten. */
	offset: number;
	/** Dauer in Tagen, mindestens 1. */
	span: number;
	clippedStart: boolean;
	clippedEnd: boolean;
	/** Unterzeile innerhalb der Phase, damit sich Balken nicht überdecken. */
	lane: number;
}

export interface PhaseLane {
	phase: string;
	laneCount: number;
	items: PlacedItem[];
}

export interface TimelineIssue {
	recordId: string;
	title: string;
	reason: string;
}

export interface TimelineTick {
	offset: number;
	label: string;
	major: boolean;
}

export interface TimelineModel {
	/** Zeitraumbeginn als Tagesnummer, oder null wenn nicht bestimmbar. */
	rangeStart: number | null;
	dayCount: number;
	phases: PhaseLane[];
	issues: TimelineIssue[];
	/** true, wenn meta.rangeStart/rangeEnd fehlten und der Zeitraum aus den Daten stammt. */
	rangeFromData: boolean;
	locale: string;
}

/** Wandelt ein ISO-Datum in eine fortlaufende Tagesnummer (UTC) um. */
export function toDayNumber(value: string): number | null {
	const match = ISO_DATE.exec(value.trim());
	if (!match) return null;

	const year = Number(match[1]);
	const month = Number(match[2]);
	const day = Number(match[3]);
	const utc = Date.UTC(year, month - 1, day);
	const date = new Date(utc);

	// Fängt Rolldaten wie 2026-02-31 ab, die Date.UTC stillschweigend verschiebt.
	if (date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
		return null;
	}

	return Math.round(utc / MS_PER_DAY);
}

export function fromDayNumber(day: number): Date {
	return new Date(day * MS_PER_DAY);
}

/** Kalenderwoche nach ISO 8601. */
export function isoWeek(day: number): number {
	const date = fromDayNumber(day);
	const thursday = new Date(date.getTime());
	thursday.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7) + 3);

	const firstThursday = new Date(Date.UTC(thursday.getUTCFullYear(), 0, 4));
	firstThursday.setUTCDate(
		firstThursday.getUTCDate() - ((firstThursday.getUTCDay() + 6) % 7) + 3,
	);

	return (
		1 +
		Math.round((thursday.getTime() - firstThursday.getTime()) / (7 * MS_PER_DAY))
	);
}

export function formatDate(day: number, locale: string): string {
	return new Intl.DateTimeFormat(locale, {
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
		timeZone: "UTC",
	}).format(fromDayNumber(day));
}

/**
 * Baut aus der geprüften Nutzlast das darstellbare Modell.
 *
 * Einträge mit unbrauchbaren Datumswerten werden nicht gezeichnet, sondern als
 * Hinweis gemeldet. Teilweise außerhalb des Zeitraums liegende Einträge werden
 * beschnitten und behalten eine Schnittmarkierung.
 */
export function buildTimeline(payload: WidgetPayload): TimelineModel {
	const locale = payload.meta?.locale || "de-DE";
	const issues: TimelineIssue[] = [];

	const resolved = payload.data.map((item) => ({
		item,
		...resolveDates(item),
	}));

	const range = resolveRange(payload, resolved);
	if (range === null) {
		for (const { item, reason } of resolved) {
			issues.push(toIssue(item, reason ?? "Kein gültiger Projektzeitraum."));
		}
		return {
			rangeStart: null,
			dayCount: 0,
			phases: [],
			issues,
			rangeFromData: true,
			locale,
		};
	}

	const dayCount = range.end - range.start + 1;
	const byPhase = new Map<string, PlacedItem[]>();

	for (const entry of resolved) {
		const { item, start, end, reason } = entry;

		if (reason !== null || start === null || end === null) {
			issues.push(toIssue(item, reason ?? "Datum fehlt."));
			continue;
		}
		if (end < range.start || start > range.end) {
			issues.push(
				toIssue(
					item,
					`Liegt vollständig außerhalb des Projektzeitraums (${formatDate(start, locale)} bis ${formatDate(end, locale)}).`,
				),
			);
			continue;
		}

		const clampedStart = Math.max(start, range.start);
		const clampedEnd = Math.min(end, range.end);

		const placed: PlacedItem = {
			item,
			offset: clampedStart - range.start,
			span: clampedEnd - clampedStart + 1,
			clippedStart: start < range.start,
			clippedEnd: end > range.end,
			lane: 0,
		};

		const bucket = byPhase.get(item.phase);
		if (bucket) {
			bucket.push(placed);
		} else {
			byPhase.set(item.phase, [placed]);
		}
	}

	const phases = [...byPhase.entries()].map(([phase, items]) =>
		packLanes(phase, items),
	);

	return {
		rangeStart: range.start,
		dayCount,
		phases,
		issues,
		rangeFromData: range.fromData,
		locale,
	};
}

/** Achsenbeschriftung: jeder Tag, oder jeder Montag als Kalenderwoche. */
export function buildTicks(
	model: TimelineModel,
	view: TimelineView,
): TimelineTick[] {
	if (model.rangeStart === null) return [];

	const ticks: TimelineTick[] = [];

	for (let offset = 0; offset < model.dayCount; offset += 1) {
		const day = model.rangeStart + offset;
		const date = fromDayNumber(day);
		const isMonday = date.getUTCDay() === 1;

		if (view === "day") {
			ticks.push({
				offset,
				label: `${date.getUTCDate()}.${date.getUTCMonth() + 1}.`,
				major: isMonday,
			});
		} else if (isMonday || offset === 0) {
			ticks.push({ offset, label: `KW ${isoWeek(day)}`, major: isMonday });
		}
	}

	return ticks;
}

function resolveDates(item: TimelineItem): {
	start: number | null;
	end: number | null;
	reason: string | null;
} {
	const start = toDayNumber(item.startDate);
	if (start === null) {
		return { start: null, end: null, reason: "Startdatum fehlt oder ist ungültig." };
	}

	// Ein Meilenstein ist ein Zeitpunkt; endDate wird bewusst ignoriert.
	if (item.type === "milestone") {
		return { start, end: start, reason: null };
	}

	const end = toDayNumber(item.endDate);
	if (end === null) {
		return { start, end: null, reason: "Enddatum fehlt oder ist ungültig." };
	}
	if (end < start) {
		return { start, end, reason: "Enddatum liegt vor dem Startdatum." };
	}

	return { start, end, reason: null };
}

function resolveRange(
	payload: WidgetPayload,
	resolved: { start: number | null; end: number | null; reason: string | null }[],
): { start: number; end: number; fromData: boolean } | null {
	const metaStart = toDayNumber(payload.meta?.rangeStart ?? "");
	const metaEnd = toDayNumber(payload.meta?.rangeEnd ?? "");

	if (metaStart !== null && metaEnd !== null && metaEnd >= metaStart) {
		return { start: metaStart, end: metaEnd, fromData: false };
	}

	const usable = resolved.filter(
		(entry) => entry.reason === null && entry.start !== null && entry.end !== null,
	);
	if (usable.length === 0) return null;

	return {
		start: Math.min(...usable.map((entry) => entry.start as number)),
		end: Math.max(...usable.map((entry) => entry.end as number)),
		fromData: true,
	};
}

/** Greedy: erste Unterzeile, in der kein Balken überlappt. */
function packLanes(phase: string, items: PlacedItem[]): PhaseLane {
	const sorted = [...items].sort((a, b) => a.offset - b.offset);
	const laneEnds: number[] = [];

	for (const placed of sorted) {
		let lane = laneEnds.findIndex((end) => end < placed.offset);
		if (lane === -1) {
			lane = laneEnds.length;
		}
		laneEnds[lane] = placed.offset + placed.span - 1;
		placed.lane = lane;
	}

	return { phase, laneCount: Math.max(laneEnds.length, 1), items: sorted };
}

function toIssue(item: TimelineItem, reason: string): TimelineIssue {
	return { recordId: item.recordId, title: item.title, reason };
}
