# FileMaker-Integration

Alle Skriptnamen und JavaScript-Funktionsnamen sind fest und bleiben englisch. Die `.fmp12` wurde
nur umbenannt; die Skripte darin müssen in FileMaker Pro selbst angelegt werden.

## Web-Viewer-Einrichtung

- Objektname des Web Viewers vergeben, zum Beispiel `wvBeziehungsnetz`. Alle
  `Perform JavaScript in Web Viewer`-Schritte brauchen ihn.
- **JavaScript darf FileMaker-Skripte ausführen** muss aktiviert sein.
- FileMaker kann JavaScript nicht aufrufen, bevor die Seite geladen und die Funktion vorhanden ist.
  Skripte, die von FileMaker aus in das Widget rufen, müssen die Bereitschaft des Web Viewers
  berücksichtigen.
- Das Widget ruft beim Öffnen von sich aus `fmWidget_getData` auf. Ein FileMaker-Skript, das nach
  dem Layoutwechsel Daten hineinschiebt, ist nicht nötig, aber über `fmWidgetLoad` möglich.

## Gemeinsamer FMGofer-Umschlag

Jedes über FMGofer aufgerufene Skript erhält:

```text
Variable setzen [ $scriptParameter ; Wert: Hole ( Skriptparameter ) ]
Variable setzen [ $parameter ; Wert: JSONGetElement ( $scriptParameter ; "parameter" ) ]
Variable setzen [ $callbackName ; Wert: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Variable setzen [ $promiseID ; Wert: JSONGetElement ( $scriptParameter ; "promiseID" ) ]
```

Auflösen und Zurückweisen entscheidet der dritte Callback-Parameter:

```text
# Auflösen:
Perform JavaScript in Web Viewer [ Objektname: wvBeziehungsnetz ; Funktionsname: $callbackName ;
  Parameter: $promiseID, "Datensatz angezeigt.", False ]

# Zurückweisen:
Perform JavaScript in Web Viewer [ Objektname: wvBeziehungsnetz ; Funktionsname: $callbackName ;
  Parameter: $promiseID, "Datensatz nicht gefunden.", True ]
```

Der zweite Parameter ist der Text, den das Widget in der Statuszeile anzeigt — als Erfolgs- oder
als Fehlermeldung. Ein eigener `{ "ok": ... }`-Umschlag ist nicht nötig.

## Skriptvertrag

### `fmWidget_getData`

- Richtung: Widget fragt, FileMaker antwortet.
- Parameter: keiner unterhalb von `parameter`.
- Ergebnis: der vollständige Startgraph als JSON-Text im zweiten Callback-Parameter.

```json
{
  "meta": { "title": "Beziehungsnetz", "rootId": "company:1001", "locale": "de-DE" },
  "nodes": [
    {
      "id": "company:1001",
      "recordId": "1001",
      "type": "company",
      "label": "Muster AG",
      "subtitle": "Kunde",
      "status": "active",
      "expandable": true
    }
  ],
  "edges": [
    {
      "id": "edge:1",
      "source": "company:1001",
      "target": "contact:2101",
      "type": "employs",
      "label": "Ansprechpartnerin"
    }
  ]
}
```

Relevante Schritte:

```text
# Umschlag lesen (siehe oben).
# $payload aus den Datensätzen des aktuellen Kunden aufbauen.
# nodes[].id muss über alle Abrufe hinweg stabil sein, etwa "<tabelle>:<recordId>".
Perform JavaScript in Web Viewer [ Objektname: wvBeziehungsnetz ; Funktionsname: $callbackName ;
  Parameter: $promiseID, $payload, False ]
```

Pflichtfelder je Knoten: `id`, `recordId`, `type`, `label` — jeweils nicht-leerer Text.
Pflichtfelder je Kante: `id`, `source`, `target`. Alles Übrige ist optional.
`expandable: true` setzen, wenn FileMaker zu diesem Knoten weitere Beziehungen liefern kann.

Wird `$payload` zurückgewiesen oder ist er kein gültiges JSON, zeigt das Widget den Fehlertext und
lässt einen erneuten Versuch über „Aktualisieren“ zu.

### `fmWidget_handleEvent`

- Richtung: Widget meldet ein Ereignis, FileMaker antwortet.
- Parameter: `{ "event": ..., "data": { "nodeId": ..., "recordId": ..., "type": ... } }`
- Ergebnis: je nach Ereignis ein Meldungstext oder ein JSON-Text.

```text
Variable setzen [ $event ; Wert: JSONGetElement ( $parameter ; "event" ) ]
Variable setzen [ $nodeId ; Wert: JSONGetElement ( $parameter ; "data.nodeId" ) ]
Variable setzen [ $recordId ; Wert: JSONGetElement ( $parameter ; "data.recordId" ) ]
Variable setzen [ $type ; Wert: JSONGetElement ( $parameter ; "data.type" ) ]

Wenn [ $event = "select-record" ]
  # Zum Datensatz $recordId in der zu $type passenden Tabelle navigieren.
  # Auflösen mit einem Meldungstext und False, oder zurückweisen mit Fehlertext und True.

Sonst wenn [ $event = "expand-node" ]
  # Die Nachbarn von $recordId ermitteln und als JSON-Text $fragment aufbauen:
  #   { "nodes": [...], "edges": [...] }
  # Gleiche Knoten- und Kantenform wie bei fmWidget_getData, ohne "meta".
  # $fragment als zweiten Callback-Parameter mit False auflösen.
  # Gibt es keine weiteren Beziehungen: { "nodes": [], "edges": [] } auflösen.

Ende (wenn)
```

Zwei Punkte sind für `expand-node` wichtig:

- Kanten dürfen auf Knoten zeigen, die bereits im Widget liegen und nicht noch einmal
  mitgeliefert werden. Das ist der Normalfall — die Kante wird an den vorhandenen Knoten geheftet.
- IDs müssen stabil sein. Das Widget führt anhand von `id` zusammen; ein bereits vorhandener Knoten
  wird nicht überschrieben, ein neuer angehängt. Wechselnde IDs erzeugen Dubletten.

Ein Zurückweisen ist ein regulärer Fall: der Graph bleibt unverändert, der Fehlertext erscheint und
derselbe Knoten kann erneut geladen werden.

### `fmWidget_reportData`

- Richtung: FileMaker fragt über den Adapter `fmWidgetRequestData`, das Widget meldet.
- Parameter: `{ "data": { ... Ansichtszustand ... } }`

```json
{
  "parameter": {
    "data": {
      "selectedNodeId": "contact:2101",
      "selectedRecordId": "2101",
      "selectedType": "contact",
      "visibleTypes": ["company", "contact", "project", "invoice"],
      "nodeCount": 7,
      "edgeCount": 8
    }
  }
}
```

```text
Variable setzen [ $selectedRecordId ; Wert: JSONGetElement ( $parameter ; "data.selectedRecordId" ) ]
Variable setzen [ $selectedType ; Wert: JSONGetElement ( $parameter ; "data.selectedType" ) ]
# Weiterverarbeiten. Die drei Auswahlfelder sind null, solange nichts ausgewählt ist.
# Auflösen mit Meldungstext und False, oder zurückweisen mit Fehlertext und True.
```

Das FileMaker-Skript, das `fmWidgetRequestData` aufruft, muss anschließend enden. Es darf keinen
Rückgabewert von JavaScript erwarten.

### `fmWidget_reportState`

- Richtung: FileMaker fragt über den Adapter `fmWidgetRequestState`, das Widget meldet.
- Parameter: `{ "dirty": false }` — konstant.

```text
Variable setzen [ $dirty ; Wert: JSONGetElement ( $parameter ; "dirty" ) ]
# $dirty ist bei diesem Widget immer false: es bearbeitet keine fachlichen Daten.
# Das Schließen oder die Navigation kann ohne Rückfrage fortgesetzt werden.
# Auflösen mit Meldungstext und False.
```

Kein Wartezyklus bauen, in dem FileMaker auf JavaScript wartet, während JavaScript auf dasselbe
FileMaker-Skript wartet.

### `fmWidget_upload`

Erhält Pfad und Widgetnamen von `fm/fmUpload.js`:

```json
{ "thePath": "/absoluter/pfad/zu/dist/index.html", "widgetName": "beziehungsnetz" }
```

Der Widgetname stammt aus `fm/fmConfig.js`. Upload-Mechanik von den Laufzeitskripten getrennt
halten.

## JavaScript-Einsprungpunkte

Für `Perform JavaScript in Web Viewer` nur diese globalen Funktionsnamen verwenden, nie einen
Namen mit Punkt:

- `fmWidgetLoad` mit dem Graphen als JSON-Text — schiebt einen Graphen ins Widget.
- `fmWidgetRefresh` ohne Parameter — löst einen neuen `fmWidget_getData`-Abruf aus.
- `fmWidgetRequestData` ohne Parameter — startet `fmWidget_reportData`.
- `fmWidgetRequestState` ohne Parameter — startet `fmWidget_reportState`.

Die beiden Request-Adapter kehren sofort zurück, damit das aufrufende FileMaker-Skript enden kann.

## Manuelle Prüfung

- [ ] Der Web Viewer trägt einen Objektnamen und **JavaScript darf FileMaker-Skripte ausführen**
      ist aktiviert.
- [ ] Beim Öffnen des Layouts erscheint der Startgraph ohne weiteres Zutun.
- [ ] „Aktualisieren“ holt den Graphen erneut; nach einem Kundenwechsel zeigt er den neuen Kunden.
- [ ] Ein Klick auf einen Knoten zentriert ihn und öffnet die Detailkarte mit der richtigen
      Datensatzkennung.
- [ ] „In FileMaker anzeigen“ springt zum richtigen Datensatz und die Statuszeile zeigt die
      Rückmeldung.
- [ ] „Beziehungen laden“ zeigt am Knoten einen Ladezustand und fügt die Nachbarn ein.
- [ ] Derselbe Knoten zweimal geladen erzeugt keine doppelten Knoten oder Kanten.
- [ ] Ein zurückgewiesenes `expand-node` lässt den Graphen stehen, zeigt den Fehlertext und der
      Knoten ist erneut ladbar.
- [ ] Die Legende blendet Typen aus und ein; die zugehörigen Kanten verschwinden mit.
- [ ] `fmWidgetRequestData` liefert den Ansichtszustand mit der aktuellen Auswahl.
- [ ] `fmWidgetRequestState` liefert `{ "dirty": false }` und das Schließen läuft ungehindert durch.
- [ ] Umlaute in Beschriftungen erscheinen korrekt, auch in WebDirect.
