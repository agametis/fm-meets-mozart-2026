# Beziehungsnetz — Umsetzungsplan

## Ziel

Ein FileMaker-Web-Viewer-Widget, das einen vom aktuellen Kunden ausgehenden Startgraphen als
interaktives Netz darstellt und auf Wunsch weitere Beziehungen aus FileMaker nachlädt.

## Bestätigte Namen

- FileMaker-Datei: `Beziehungsnetz.fmp12`
- npm-Paket: `beziehungsnetz`
- Widget-Bezeichner: `beziehungsnetz`

## Hauptablauf

1. Das Widget startet und ruft von sich aus `fmWidget_getData` auf.
2. Der Graph wird mit dem `cose`-Layout angeordnet und in die Fläche eingepasst.
3. Der Benutzer zoomt, verschiebt und blendet Knotentypen über die Legende aus und ein.
4. Ein Klick auf einen Knoten zentriert ihn und öffnet die kompakte Detailkarte.
5. In der Detailkarte sendet „In FileMaker anzeigen“ das Ereignis `select-record`.
6. Bei `expandable: true` lädt „Beziehungen laden“ über das Ereignis `expand-node` weitere Knoten
   und Kanten nach. Sie werden anhand ihrer stabilen IDs duplikatfrei eingefügt; das Layout läuft
   mit `randomize: false` nach, damit vorhandene Knoten kaum springen.

## Datenvertrag

Eingang, unverändert wie vom Auftraggeber geliefert — ohne `data`-Envelope:

```json
{
  "meta": { "title": "Beziehungsnetz", "rootId": "company:1001", "locale": "de-DE" },
  "nodes": [
    {
      "id": "company:1001",
      "recordId": "1001",
      "type": "company",
      "label": "Muster AG",
      "subtitle": "Kunde",
      "status": "active",
      "expandable": true
    }
  ],
  "edges": [
    {
      "id": "edge:1",
      "source": "company:1001",
      "target": "contact:2101",
      "type": "employs",
      "label": "Ansprechpartnerin"
    }
  ]
}
```

Pflichtfelder, jeweils nicht-leerer Text: `nodes[].id`, `nodes[].recordId`, `nodes[].type`,
`nodes[].label`, `edges[].id`, `edges[].source`, `edges[].target`.

Optional: `meta` samt aller Unterfelder, `nodes[].subtitle`, `nodes[].status`,
`nodes[].expandable` (Vorgabe `false`), `edges[].type`, `edges[].label`.

`nodes[].id` ist der Schlüssel für die Duplikatfreiheit beim Nachladen und muss über alle
Abrufe hinweg stabil bleiben. `recordId` ist die FileMaker-Datensatzkennung und wird ausschließlich
in Ereignissen zurückgemeldet.

Bekannte Knotentypen mit eigener Farbe und festem Legendeneintrag: `company`, `contact`, `project`,
`invoice`. Unbekannte Werte in `type` oder `status` werden toleriert: der Typ erscheint neutral
eingefärbt mit eigenem Legendeneintrag, der Status wird unverändert als Text angezeigt. FileMaker
kann Typen also ergänzen, ohne das Widget zu brechen.

Kanten, deren `source` oder `target` nach dem Zusammenführen unbekannt bleibt, werden verworfen —
Cytoscape lehnt eine Kante ohne beide Knoten ab. Eine Kante, die auf einen bereits vorhandenen
Knoten zeigt, ist davon nicht betroffen; das ist der Normalfall beim Nachladen.

Laderichtung: automatischer `fmWidget_getData`-Abruf beim Öffnen, zusätzlich jederzeit manuell
über „Aktualisieren“. FileMaker kann unabhängig davon per `fmWidgetLoad` einen Graphen pushen.

## Ausgabe und Zustand

Beide Ereignisse laufen über `fmWidget_handleEvent` und warten auf die Antwort von FileMaker:

```json
{ "event": "select-record", "data": { "nodeId": "contact:2101", "recordId": "2101", "type": "contact" } }
{ "event": "expand-node",   "data": { "nodeId": "project:3101", "recordId": "3101", "type": "project" } }
```

`select-record` wird mit einem Erfolgstext aufgelöst, der in der Statuszeile erscheint.
`expand-node` wird mit einem JSON-Text `{ "nodes": [...], "edges": [...] }` aufgelöst — dieselbe
Knoten- und Kantenform wie beim Laden, deshalb prüft derselbe Parser beides.

Nach dem Ereignis: kein Zurücksetzen, kein Neuladen, keine Navigation. Bei `select-record` bleibt
die Ansicht unverändert und zeigt die Rückmeldung. Bei `expand-node` wächst der Graph und die
Statuszeile nennt die Zahl der neuen Verknüpfungen. Schlägt ein Ereignis fehl, bleibt der bisherige
Graph vollständig erhalten, der Fehlertext erscheint und derselbe Knoten ist erneut ladbar.

`fmWidget_reportData` meldet den Ansichtszustand aus dem aktuellen React-State:

```json
{
  "data": {
    "selectedNodeId": "contact:2101",
    "selectedRecordId": "2101",
    "selectedType": "contact",
    "visibleTypes": ["company", "contact", "project", "invoice"],
    "nodeCount": 7,
    "edgeCount": 8
  }
}
```

Die drei Auswahlfelder sind `null`, solange nichts ausgewählt ist.

`fmWidget_reportState` meldet konstant `{ "dirty": false }`. Das Widget bearbeitet keine fachlichen
Daten; Filter, Auswahl, Zoom und Knotenpositionen sind reine Darstellungszustände. FileMaker darf
also jederzeit ohne Rückfrage schließen.

## Stack

- React, TypeScript und Vite — Vorgabe des Templates.
- `cytoscape@3.34.3` (MIT) als einzige neue Abhängigkeit, nur der Kern, keine Plugins. Sie liefert
  Layout, Zoom, Verschieben, Auswahl-Events, Styling per Typ-Selektor und das duplikatfreie
  Einfügen über stabile IDs. Ein Eigenbau hätte ein kräftebasiertes Layout, eine
  Transformationsmatrix für Pan und Zoom, Kantenrouting mit Labelplatzierung und Trefferbehandlung
  bedeutet — deutlich mehr Code, mit der Layoutqualität als eigentlichem Risiko. Preis: die
  ESM-Minified-Datei ist 434 KB und landet unkomprimiert im Single-File-Build.
- Keine Icon-Bibliothek. Die Leiste braucht vier Textschaltflächen.
- `@types/cytoscape` ist nicht nötig — Cytoscape liefert eigene Typen mit.

## FileMaker-Änderungen

Siehe [FM-INTEGRATION.md](FM-INTEGRATION.md). Kurz: `fmWidget_getData` liefert den Startgraphen,
`fmWidget_handleEvent` verzweigt auf `parameter.event`, `fmWidget_reportData` und
`fmWidget_reportState` nehmen die Meldungen entgegen. Die `.fmp12` wurde nur umbenannt, ihr Inhalt
nicht angetastet.

## Abnahmekriterien

- [x] Das Widget lädt beim Öffnen selbstständig und zeigt die 5 Knoten und 5 Kanten des Beispiels.
- [x] Zoomen, Verschieben und Einpassen funktionieren; ein Klick zentriert den Knoten und öffnet
      die Detailkarte.
- [x] Die Legende blendet Typen aus und ein; Kanten zu ausgeblendeten Knoten verschwinden mit.
- [x] „Beziehungen laden“ zeigt am betroffenen Knoten einen Ladezustand, fügt die Antwort
      duplikatfrei ein und erzeugt beim zweiten Laden desselben Knotens keine doppelten Elemente.
- [x] Ein Fehler bei `expand-node` lässt den Graphen unverändert stehen und erlaubt einen erneuten
      Versuch.
- [x] „In FileMaker anzeigen“ sendet `select-record` und zeigt FileMakers Antwort in der
      Statuszeile.
- [x] `fmWidget_reportState` meldet `{ "dirty": false }`.
- [x] `dist/index.html` ist reines ASCII und enthält keine Werte aus der Testdaten-Fixture.

## Prüfung

- `npm run type-check`
- `npm run lint`
- `npm test` — Vertragsprüfungen der Brücke und die Zusammenführungslogik in `src/graph.test.ts`
- `npm run build` — enthält die Encoding-, Marker- und Escape-Prüfungen
- Manuelle Prüfung im Browser unter `?data=test` sowie die FileMaker-Checkliste in
  [FM-INTEGRATION.md](FM-INTEGRATION.md)

## Annahmen und offene Punkte

- Die `cose`-Parameter sind Startwerte. Sie lassen sich nach dem ersten Blick auf echte Daten
  nachjustieren, ohne den Datenvertrag zu berühren.
- Sehr große Graphen jenseits von rund 500 Knoten sind nicht erprobt. Wird das relevant, wäre eine
  Begrenzung der Expansionstiefe oder ein Grenzwert für die Knotenzahl der nächste Schritt.
- Die Farbzuordnung der vier Typen ist gesetzt und auf Zuruf änderbar (`TYPE_COLORS` in
  `src/graph.ts`).
- Die Detailkarte speist sich aus `label`, `subtitle`, `type`, `status`, `recordId` und der Zahl der
  Verbindungen. Ein eigenes `details`-Feld gibt es im Vertrag nicht; kämen weitere Felder dazu,
  wäre das eine Vertragserweiterung.
- Die Knotenliste unter dem Netz ist visuell versteckt und wird beim Tabben sichtbar. Sie ist die
  Tastatur- und Screenreader-Entsprechung zum Canvas, der für sich genommen nicht bedienbar wäre.
