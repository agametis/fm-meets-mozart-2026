export const fmConfig = {
	server: "$",
	file: "Beziehungsnetz",
	uploadScript: "fmWidget_upload",
	widgetName: "beziehungsnetz",
};
