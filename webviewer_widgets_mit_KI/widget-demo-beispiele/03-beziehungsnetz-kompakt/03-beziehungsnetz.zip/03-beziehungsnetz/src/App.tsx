import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { installFMWidgetApi, isMockMode, parseGraphFragment } from "./fm/bridge";
import type { GraphFragment, ViewState, WidgetPayload } from "./fm/types";
import { colorForType, EMPTY_GRAPH, legendTypes, mergeGraph } from "./graph";
import { GraphView } from "./GraphView";
import type { GraphControls } from "./GraphView";

const TYPE_LABELS: Record<string, string> = {
	company: "Unternehmen",
	contact: "Kontakt",
	project: "Projekt",
	invoice: "Rechnung",
};

const STATUS_LABELS: Record<string, string> = {
	active: "aktiv",
	planned: "geplant",
	open: "offen",
	paid: "bezahlt",
};

function typeLabel(type: string): string {
	return TYPE_LABELS[type] ?? type;
}

function statusLabel(status: string): string {
	return STATUS_LABELS[status] ?? status;
}

function App() {
	const mockMode = isMockMode();
	const [meta, setMeta] = useState<WidgetPayload["meta"]>(undefined);
	const [graph, setGraph] = useState<GraphFragment>(EMPTY_GRAPH);
	const [hiddenTypes, setHiddenTypes] = useState<ReadonlySet<string>>(
		() => new Set<string>(),
	);
	const [selectedId, setSelectedId] = useState<string | null>(null);
	const [expandingId, setExpandingId] = useState<string | null>(null);
	const [status, setStatus] = useState<
		"waiting" | "loading" | "ready" | "processing" | "success" | "error"
	>("waiting");
	const [feedback, setFeedback] = useState("");
	const [error, setError] = useState("");
	const [mockRequest, setMockRequest] = useState<{
		script: string;
		parameter: unknown;
	} | null>(null);

	const controlsRef = useRef<GraphControls | null>(null);
	const initialLoadStartedRef = useRef(false);
	const viewStateRef = useRef<ViewState>({
		selectedNodeId: null,
		selectedRecordId: null,
		selectedType: null,
		visibleTypes: [],
		nodeCount: 0,
		edgeCount: 0,
	});

	const selectedNode = useMemo(
		() => graph.nodes.find((node) => node.id === selectedId) ?? null,
		[graph.nodes, selectedId],
	);

	const types = useMemo(() => legendTypes(graph.nodes), [graph.nodes]);

	const typeCounts = useMemo(() => {
		const counts = new Map<string, number>();
		for (const node of graph.nodes) {
			counts.set(node.type, (counts.get(node.type) ?? 0) + 1);
		}
		return counts;
	}, [graph.nodes]);

	const connectionCount = useMemo(
		() =>
			selectedId === null
				? 0
				: graph.edges.filter(
						(edge) => edge.source === selectedId || edge.target === selectedId,
					).length,
		[graph.edges, selectedId],
	);

	viewStateRef.current = {
		selectedNodeId: selectedNode?.id ?? null,
		selectedRecordId: selectedNode?.recordId ?? null,
		selectedType: selectedNode?.type ?? null,
		visibleTypes: types.filter((type) => !hiddenTypes.has(type)),
		nodeCount: graph.nodes.length,
		edgeCount: graph.edges.length,
	};

	useEffect(() => {
		const uninstall = installFMWidgetApi({
			// The widget never edits business data, so FM may always close.
			getDirty: () => false,
			getData: () => viewStateRef.current,
			onLoad: (payload) => {
				setMeta(payload.meta);
				setGraph(mergeGraph(EMPTY_GRAPH, payload));
				setSelectedId(null);
				setExpandingId(null);
				setError("");
				setFeedback("");
				setStatus("ready");
			},
			onError: (nextError) => {
				setError(nextError.message);
				setFeedback("");
				setExpandingId(null);
				setStatus("error");
			},
			onRefreshStart: () => {
				setError("");
				setFeedback("");
				setStatus("loading");
			},
			onRequestStart: (request, preview) => {
				if (mockMode) {
					setMockRequest(preview);
				}
				setError("");
				setFeedback(
					request === "data"
						? "FileMaker verarbeitet den Ansichtszustand..."
						: request === "state"
							? "FileMaker verarbeitet den Widget-Zustand..."
							: "FileMaker verarbeitet das Ereignis...",
				);
				setStatus("processing");
			},
			onRequestSuccess: (_request, message) => {
				setError("");
				setFeedback(message);
				setStatus("success");
			},
		});

		if (!initialLoadStartedRef.current) {
			initialLoadStartedRef.current = true;
			void window.fmWidget?.refresh();
		}

		return uninstall;
	}, [mockMode]);

	const handleReady = useCallback((controls: GraphControls) => {
		controlsRef.current = controls;
	}, []);

	const handleSelect = useCallback((nodeId: string | null) => {
		setSelectedId(nodeId);
		if (nodeId) {
			controlsRef.current?.focus(nodeId);
		}
	}, []);

	const toggleType = (type: string) => {
		setHiddenTypes((current) => {
			const next = new Set(current);
			if (next.has(type)) {
				next.delete(type);
			} else {
				next.add(type);
			}
			return next;
		});
	};

	const selectRecord = async () => {
		if (!selectedNode) return;
		const result = await window.fmWidget?.sendEvent("select-record", {
			nodeId: selectedNode.id,
			recordId: selectedNode.recordId,
			type: selectedNode.type,
		});
		if (typeof result === "string") {
			setFeedback(result);
			setStatus("success");
		}
	};

	const expandNode = async () => {
		if (!selectedNode || expandingId !== null) return;

		setExpandingId(selectedNode.id);
		const result = await window.fmWidget?.sendEvent("expand-node", {
			nodeId: selectedNode.id,
			recordId: selectedNode.recordId,
			type: selectedNode.type,
		});
		setExpandingId(null);

		// A rejected event already reported itself through onError, and the
		// graph is untouched, so the same node stays expandable.
		if (typeof result !== "string") return;

		try {
			const merged = mergeGraph(graph, parseGraphFragment(result));
			const added = merged.nodes.length - graph.nodes.length;
			setGraph(merged);
			setFeedback(
				added === 0
					? "Keine weiteren Beziehungen gefunden."
					: `${added} neue Verknüpfung${added === 1 ? "" : "en"} geladen.`,
			);
			setStatus("success");
		} catch (parseError) {
			setError(
				parseError instanceof Error ? parseError.message : String(parseError),
			);
			setStatus("error");
		}
	};

	const title = meta?.title ?? "Beziehungsnetz";
	const hasGraph = graph.nodes.length > 0;

	return (
		<main className="app-shell">
			<header>
				<p className="eyebrow">Beziehungsnetz</p>
				<h1>{title}</h1>
				<p className="status" data-status={status}>
					{status === "waiting" && "Warte auf Daten aus FileMaker."}
					{status === "loading" && "Lade Daten aus FileMaker..."}
					{status === "ready" &&
						(mockMode
							? `Expliziter Testmodus - ${graph.nodes.length} Knoten, ${graph.edges.length} Kanten`
							: `${graph.nodes.length} Knoten, ${graph.edges.length} Kanten`)}
					{status === "processing" && feedback}
					{status === "success" && feedback}
					{status === "error" && "FileMaker konnte die Anfrage nicht bearbeiten."}
				</p>
			</header>

			{error && <p className="error-message">{error}</p>}

			<section className="graph-card">
				<div className="actions">
					<button type="button" onClick={() => void window.fmWidget?.refresh()}>
						Aktualisieren
					</button>
					<button type="button" onClick={() => controlsRef.current?.fit()}>
						Einpassen
					</button>
					<button
						type="button"
						aria-label="Vergrößern"
						onClick={() => controlsRef.current?.zoomBy(1.25)}
					>
						Zoom +
					</button>
					<button
						type="button"
						aria-label="Verkleinern"
						onClick={() => controlsRef.current?.zoomBy(0.8)}
					>
						Zoom -
					</button>
				</div>

				<div className="graph-stage">
					<GraphView
						graph={graph}
						hiddenTypes={hiddenTypes}
						expandingId={expandingId}
						selectedId={selectedId}
						onSelect={handleSelect}
						onReady={handleReady}
					/>

					{!hasGraph && status !== "loading" && (
						<p className="graph-empty">
							Noch keine Beziehungen geladen. Aktualisieren startet einen neuen
							Abruf aus FileMaker.
						</p>
					)}

					{/* The canvas is unreachable by keyboard and screen reader, so the
					    same nodes are offered as an off-screen list that drives the
					    identical selection path. */}
					<ul className="node-list">
						{graph.nodes
							.filter((node) => !hiddenTypes.has(node.type))
							.map((node) => (
								<li key={node.id}>
									<button
										type="button"
										aria-pressed={node.id === selectedId}
										onClick={() => handleSelect(node.id)}
									>
										{node.label} ({typeLabel(node.type)})
									</button>
								</li>
							))}
					</ul>

					{selectedNode && (
						<aside className="detail-card" aria-live="polite">
							<p
								className="detail-type"
								style={{ color: colorForType(selectedNode.type) }}
							>
								{typeLabel(selectedNode.type)}
							</p>
							<h2>{selectedNode.label}</h2>
							{selectedNode.subtitle && <p>{selectedNode.subtitle}</p>}
							<dl>
								{selectedNode.status && (
									<>
										<dt>Status</dt>
										<dd>{statusLabel(selectedNode.status)}</dd>
									</>
								)}
								<dt>Datensatz</dt>
								<dd>{selectedNode.recordId}</dd>
								<dt>Verbindungen</dt>
								<dd>{connectionCount}</dd>
							</dl>
							<div className="actions">
								<button type="button" onClick={() => void selectRecord()}>
									In FileMaker anzeigen
								</button>
								{selectedNode.expandable && (
									<button
										type="button"
										disabled={expandingId !== null}
										onClick={() => void expandNode()}
									>
										{expandingId === selectedNode.id
											? "Lade Beziehungen..."
											: "Beziehungen laden"}
									</button>
								)}
								<button
									type="button"
									className="ghost"
									onClick={() => setSelectedId(null)}
								>
									Schließen
								</button>
							</div>
						</aside>
					)}
				</div>

				<ul className="legend">
					{types.map((type) => {
						const hidden = hiddenTypes.has(type);
						return (
							<li key={type}>
								<button
									type="button"
									className="legend-entry"
									aria-pressed={!hidden}
									data-hidden={hidden}
									onClick={() => toggleType(type)}
								>
									<span
										className="legend-dot"
										style={{ background: colorForType(type) }}
									/>
									{typeLabel(type)}
									<span className="legend-count">
										{typeCounts.get(type) ?? 0}
									</span>
								</button>
							</li>
						);
					})}
				</ul>
			</section>

			{mockMode && (
				<section className="mock-request" aria-live="polite">
					<p className="eyebrow">Testmodus</p>
					<h2>Vorschau der FileMaker-Anfrage</h2>
					{mockRequest ? (
						<>
							<p>
								Zielskript: <code>{mockRequest.script}</code>
							</p>
							<pre>{JSON.stringify(mockRequest.parameter, null, 2)}</pre>
						</>
					) : (
						<p>
							Report Data meldet den Ansichtszustand an{" "}
							<code>fmWidget_reportData</code>, Report State meldet{" "}
							<code>dirty: false</code> an <code>fmWidget_reportState</code>.
							Auswahl oder Beziehungen laden zeigt hier die Nutzlast für{" "}
							<code>fmWidget_handleEvent</code>.
						</p>
					)}
					<div className="actions">
						<button
							type="button"
							onClick={() => void window.fmWidget?.requestData()}
						>
							Report data
						</button>
						<button
							type="button"
							onClick={() => void window.fmWidget?.requestState()}
						>
							Report state
						</button>
					</div>
				</section>
			)}
		</main>
	);
}

export default App;
