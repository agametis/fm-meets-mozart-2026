import cytoscape from "cytoscape";
import { useEffect, useRef } from "react";

import type { GraphFragment } from "./fm/types";
import { colorForType } from "./graph";

const STYLE: cytoscape.StylesheetJson = [
	{
		selector: "node",
		style: {
			"background-color": (node: cytoscape.NodeSingular) =>
				colorForType(String(node.data("type"))),
			label: "data(label)",
			color: "#0f172a",
			"font-size": "11px",
			"font-weight": 600,
			"text-valign": "bottom",
			"text-margin-y": 6,
			"text-background-color": "#f8fafc",
			"text-background-opacity": 0.85,
			"text-background-padding": "2px",
			"text-background-shape": "roundrectangle",
			width: 34,
			height: 34,
			"border-width": 2,
			"border-color": "#f8fafc",
		},
	},
	{
		// A ring marks nodes FM can still supply relations for.
		selector: "node[?expandable]",
		style: {
			"border-width": 4,
			"border-color": "#94a3b8",
			"border-style": "double",
		},
	},
	{
		selector: "node.selected-node",
		style: {
			"border-width": 5,
			"border-color": "#0f172a",
			"border-style": "solid",
		},
	},
	{
		selector: "node.expanding",
		style: {
			"border-width": 6,
			"border-color": "#f59e0b",
			"border-style": "dashed",
			opacity: 0.65,
		},
	},
	{
		selector: "node.type-hidden",
		style: { display: "none" },
	},
	{
		selector: "edge",
		style: {
			width: 1.5,
			"line-color": "#cbd5e1",
			"target-arrow-color": "#cbd5e1",
			"target-arrow-shape": "triangle",
			"curve-style": "bezier",
			label: "data(label)",
			"font-size": "9px",
			color: "#64748b",
			"text-rotation": "autorotate",
			"text-background-color": "#f8fafc",
			"text-background-opacity": 0.85,
			"text-background-padding": "2px",
		},
	},
];

const LAYOUT: cytoscape.CoseLayoutOptions = {
	name: "cose",
	animate: true,
	animationDuration: 400,
	// Seeds the simulation with current positions so an expansion nudges the
	// existing net instead of scattering it.
	randomize: false,
	nodeDimensionsIncludeLabels: true,
	padding: 40,
	fit: true,
};

interface GraphViewProps {
	graph: GraphFragment;
	hiddenTypes: ReadonlySet<string>;
	expandingId: string | null;
	selectedId: string | null;
	onSelect: (nodeId: string | null) => void;
	/** Receives zoom/fit controls once Cytoscape is ready. */
	onReady: (controls: GraphControls) => void;
}

export interface GraphControls {
	fit: () => void;
	zoomBy: (factor: number) => void;
	focus: (nodeId: string) => void;
}

export function GraphView({
	graph,
	hiddenTypes,
	expandingId,
	selectedId,
	onSelect,
	onReady,
}: GraphViewProps) {
	const containerRef = useRef<HTMLDivElement | null>(null);
	const cyRef = useRef<cytoscape.Core | null>(null);
	const onSelectRef = useRef(onSelect);
	const onReadyRef = useRef(onReady);
	onSelectRef.current = onSelect;
	onReadyRef.current = onReady;

	useEffect(() => {
		const container = containerRef.current;
		if (!container) return;

		const cy = cytoscape({
			container,
			style: STYLE,
			minZoom: 0.2,
			// A five node graph would otherwise fill the canvas at a cartoonish
			// zoom, because fitting has nothing else to scale against.
			maxZoom: 2,
		});
		cyRef.current = cy;

		cy.on("tap", "node", (event) => {
			onSelectRef.current(String(event.target.id()));
		});
		cy.on("tap", (event) => {
			if (event.target === cy) onSelectRef.current(null);
		});

		onReadyRef.current({
			fit: () => cy.animate({ fit: { eles: cy.elements(), padding: 40 } }, { duration: 250 }),
			zoomBy: (factor) =>
				cy.zoom({
					level: cy.zoom() * factor,
					renderedPosition: { x: cy.width() / 2, y: cy.height() / 2 },
				}),
			focus: (nodeId) => {
				const node = cy.getElementById(nodeId);
				if (node.nonempty()) {
					cy.animate(
						{ center: { eles: node }, zoom: Math.max(cy.zoom(), 1) },
						{ duration: 250 },
					);
				}
			},
		});

		// Cytoscape measures its container once. The stage grows after mount and
		// the FM Web Viewer can be resized at runtime, so both need a re-measure
		// followed by a fit - otherwise the net stays a dot in a large canvas.
		const observer = new ResizeObserver(() => {
			cy.resize();
			if (cy.elements().nonempty()) {
				cy.fit(cy.elements(), 40);
			}
		});
		observer.observe(container);

		return () => {
			observer.disconnect();
			cy.destroy();
			cyRef.current = null;
		};
		// Created once: the callbacks above read through refs, so a re-render
		// never tears down the canvas and loses node positions.
	}, []);

	// Elements: add what is new, keep positions of what is already there.
	useEffect(() => {
		const cy = cyRef.current;
		if (!cy) return;

		const added = cy.collection();
		for (const node of graph.nodes) {
			if (cy.getElementById(node.id).nonempty()) continue;
			added.merge(cy.add({ group: "nodes", data: { ...node } }));
		}
		for (const edge of graph.edges) {
			if (cy.getElementById(edge.id).nonempty()) continue;
			added.merge(
				cy.add({
					group: "edges",
					data: { ...edge, label: edge.label ?? "" },
				}),
			);
		}

		const nodeIds = new Set(graph.nodes.map((node) => node.id));
		const edgeIds = new Set(graph.edges.map((edge) => edge.id));
		const removed = cy
			.elements()
			.filter((element) =>
				element.isNode()
					? !nodeIds.has(element.id())
					: !edgeIds.has(element.id()),
			);
		removed.remove();

		if (added.nonempty() || removed.nonempty()) {
			const layout = cy.layout(LAYOUT);
			layout.one("layoutstop", () => {
				cy.fit(cy.elements(), 40);
			});
			layout.run();
		}
	}, [graph]);

	useEffect(() => {
		const cy = cyRef.current;
		if (!cy) return;

		cy.batch(() => {
			cy.nodes().forEach((node) => {
				node.toggleClass(
					"type-hidden",
					hiddenTypes.has(String(node.data("type"))),
				);
				node.toggleClass("expanding", node.id() === expandingId);
				node.toggleClass("selected-node", node.id() === selectedId);
			});
		});
	}, [hiddenTypes, expandingId, selectedId]);

	return <div className="graph-canvas" ref={containerRef} role="application" aria-label="Beziehungsnetz" />;
}
