import { afterEach, describe, expect, it, vi } from "vitest";

const { performScriptMock } = vi.hoisted(() => ({
	performScriptMock: vi.fn(),
}));

vi.mock("fm-gofer", () => ({
	default: { PerformScript: performScriptMock },
}));

import {
	createDirtyStatePayload,
	installFMWidgetApi,
	isMockMode,
	parseGraphFragment,
	parseWidgetPayload,
} from "./bridge";
import type { ViewState } from "./types";

afterEach(() => {
	performScriptMock.mockReset();
	vi.unstubAllGlobals();
});

const NODE = {
	id: "company:1001",
	recordId: "1001",
	type: "company",
	label: "Muster AG",
	subtitle: "Kunde",
	status: "active",
	expandable: true,
};

const EDGE = {
	id: "edge:1",
	source: "company:1001",
	target: "contact:2101",
	type: "employs",
	label: "Ansprechpartnerin",
};

describe("parseWidgetPayload", () => {
	it("accepts the documented meta, nodes and edges contract", () => {
		expect(
			parseWidgetPayload(
				JSON.stringify({
					meta: { title: "Beziehungsnetz", rootId: "company:1001" },
					nodes: [NODE],
					edges: [EDGE],
				}),
			),
		).toEqual({
			meta: {
				title: "Beziehungsnetz",
				rootId: "company:1001",
				locale: undefined,
			},
			nodes: [NODE],
			edges: [EDGE],
		});
	});

	it("preserves German umlauts in interface data", () => {
		const label = "Größe, Straße, Öl, Äpfel und Grüße";

		expect(
			parseWidgetPayload({
				nodes: [{ ...NODE, label }],
				edges: [],
			}).nodes[0].label,
		).toBe(label);
	});

	it("defaults optional node fields instead of inventing values", () => {
		const [node] = parseWidgetPayload({
			nodes: [{ id: "a", recordId: "1", type: "company", label: "A" }],
			edges: [],
		}).nodes;

		expect(node.expandable).toBe(false);
		expect(node.subtitle).toBeUndefined();
		expect(node.status).toBeUndefined();
	});

	it("rejects payloads that cannot drive the widget", () => {
		expect(() => parseWidgetPayload('{"edges":[]}')).toThrow('"nodes"');
		expect(() =>
			parseWidgetPayload({ nodes: [{ ...NODE, recordId: "" }], edges: [] }),
		).toThrow("nodes[0].recordId");
		expect(() =>
			parseWidgetPayload({
				nodes: [NODE],
				edges: [{ id: "e", source: "a" }],
			} as never),
		).toThrow("edges[0].target");
	});
});

describe("parseGraphFragment", () => {
	it("reads the same shape from an expand-node answer", () => {
		expect(
			parseGraphFragment('{"nodes":[],"edges":[]}'),
		).toEqual({ nodes: [], edges: [] });
	});

	it("keeps edges that point at nodes outside the fragment", () => {
		// The expansion attaches to a node that is already on the canvas.
		expect(parseGraphFragment({ nodes: [], edges: [EDGE] }).edges).toHaveLength(
			1,
		);
	});

	it("names the offending path when FM answers with something else", () => {
		expect(() => parseGraphFragment("not json")).toThrow("gültiges JSON");
	});
});

describe("isMockMode", () => {
	it("enables mock data only for the data=test URL parameter", () => {
		expect(isMockMode("?data=test")).toBe(true);
		expect(isMockMode("?data=production")).toBe(false);
		expect(isMockMode("?view=test")).toBe(false);
	});
});

describe("FM processing feedback", () => {
	it("awaits FM processing when FileMaker requests the current view state", async () => {
		const callbacks = installApi();
		mockFMResult("Ansicht verarbeitet");

		const adapterResult = window.fmWidgetRequestData?.();

		expect(adapterResult).toBeUndefined();
		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportData", {
			data: VIEW_STATE,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("data", {
			script: "fmWidget_reportData",
			parameter: { data: VIEW_STATE },
		});
		await vi.waitFor(() => {
			expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
				"data",
				"Ansicht verarbeitet",
			);
		});
	});

	it("reports the widget as never dirty, because it edits no business data", async () => {
		const callbacks = installApi();
		mockFMResult("Zustand verarbeitet");

		await window.fmWidget?.requestState();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportState", {
			dirty: false,
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"state",
			"Zustand verarbeitet",
		);
	});

	it("sends node events to fmWidget_handleEvent and returns FM's answer", async () => {
		const callbacks = installApi();
		mockFMResult('{"nodes":[],"edges":[]}');

		const result = await window.fmWidget?.sendEvent("expand-node", {
			nodeId: "company:1001",
			recordId: "1001",
			type: "company",
		});

		const parameter = {
			event: "expand-node",
			data: { nodeId: "company:1001", recordId: "1001", type: "company" },
		};
		expect(performScriptMock).toHaveBeenCalledWith(
			"fmWidget_handleEvent",
			parameter,
		);
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("event", {
			script: "fmWidget_handleEvent",
			parameter,
		});
		expect(result).toBe('{"nodes":[],"edges":[]}');
	});

	it("reports an FM processing failure to the interface", async () => {
		const callbacks = installApi();
		mockFMError("Datensatz nicht gefunden");

		const result = await window.fmWidget?.sendEvent("select-record", {
			nodeId: "company:1001",
			recordId: "1001",
			type: "company",
		});

		// null keeps the caller from merging anything, so the graph survives.
		expect(result).toBeNull();
		expect(callbacks.onError).toHaveBeenCalledWith(
			expect.objectContaining({ message: "Datensatz nicht gefunden" }),
		);
		expect(callbacks.onRequestSuccess).not.toHaveBeenCalled();
	});
});

describe("createDirtyStatePayload", () => {
	it("reports only the dirty flag required by FM", () => {
		expect(createDirtyStatePayload(false)).toBe('{"dirty":false}');
	});
});

const VIEW_STATE: ViewState = {
	selectedNodeId: "company:1001",
	selectedRecordId: "1001",
	selectedType: "company",
	visibleTypes: ["company", "contact"],
	nodeCount: 5,
	edgeCount: 5,
};

function installApi() {
	vi.stubGlobal("window", {
		FileMaker: { PerformScriptWithOption: vi.fn() },
		// isMockMode reads the query string on every event, so the stub has to
		// carry a location just like a real Web Viewer window does.
		location: { search: "" },
	});

	const callbacks = {
		onError: vi.fn(),
		onLoad: vi.fn(),
		onRefreshStart: vi.fn(),
		onRequestStart: vi.fn(),
		onRequestSuccess: vi.fn(),
	};

	installFMWidgetApi({
		getData: () => VIEW_STATE,
		getDirty: () => false,
		...callbacks,
	});

	return callbacks;
}

function mockFMResult(message: string) {
	performScriptMock.mockReturnValue(Promise.resolve(message));
}

function mockFMError(message: string) {
	performScriptMock.mockReturnValue(Promise.reject(message));
}
