import FMGofer from "fm-gofer";

import type {
	GraphEdge,
	GraphFragment,
	GraphNode,
	NodeEventData,
	ViewState,
	WidgetPayload,
} from "./types";

const FM_SCRIPTS = {
	getData: "fmWidget_getData",
	handleEvent: "fmWidget_handleEvent",
	reportData: "fmWidget_reportData",
	reportState: "fmWidget_reportState",
} as const;

type FMRequestKind = "data" | "state" | "event";

interface FMRequestPreview {
	script: string;
	parameter: unknown;
}

interface FMWidgetApi {
	load: (payload: string | WidgetPayload) => void;
	refresh: () => Promise<void>;
	requestData: () => Promise<void>;
	requestState: () => Promise<void>;
	/** Resolves with FM's raw result text, or null when FM rejected. */
	sendEvent: (event: string, data: NodeEventData) => Promise<string | null>;
}

interface InstallApiOptions {
	getData: () => ViewState;
	getDirty: () => boolean;
	onLoad: (payload: WidgetPayload) => void;
	onError: (error: Error) => void;
	onRefreshStart: () => void;
	onRequestStart: (request: FMRequestKind, preview: FMRequestPreview) => void;
	onRequestSuccess: (request: FMRequestKind, message: string) => void;
}

declare global {
	interface Window {
		fmWidget?: FMWidgetApi;
		fmWidgetLoad?: FMWidgetApi["load"];
		fmWidgetRefresh?: () => void;
		fmWidgetRequestData?: () => void;
		fmWidgetRequestState?: () => void;
	}
}

export function isMockMode(search = window.location.search): boolean {
	return (
		import.meta.env.DEV && new URLSearchParams(search).get("data") === "test"
	);
}

function toObject(input: unknown, subject: string): Record<string, unknown> {
	let parsed: unknown = input;
	if (typeof input === "string") {
		try {
			parsed = JSON.parse(input);
		} catch {
			throw new Error(`${subject} muss gültiges JSON enthalten.`);
		}
	}

	if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
		throw new Error(`${subject} muss ein JSON-Objekt sein.`);
	}

	return parsed as Record<string, unknown>;
}

function requireText(value: unknown, path: string): string {
	if (typeof value !== "string" || value === "") {
		throw new Error(`"${path}" muss ein nicht-leerer Text sein.`);
	}
	return value;
}

function optionalText(value: unknown): string | undefined {
	return typeof value === "string" && value !== "" ? value : undefined;
}

/**
 * Validates the node and edge shape shared by the initial payload and by the
 * answer to an expand-node event. Edges pointing at unknown nodes are not
 * rejected here: an expansion legitimately references nodes that are already on
 * the canvas. `mergeGraph` drops the ones that stay unresolved.
 */
export function parseGraphFragment(
	input: string | GraphFragment,
): GraphFragment {
	const candidate = toObject(input, "Die Graphdaten");

	if (!Array.isArray(candidate.nodes)) {
		throw new Error('"nodes" muss eine Liste sein.');
	}
	if (!Array.isArray(candidate.edges)) {
		throw new Error('"edges" muss eine Liste sein.');
	}

	const nodes: GraphNode[] = candidate.nodes.map((entry, index) => {
		const node = toObject(entry, `"nodes[${index}]"`);
		return {
			id: requireText(node.id, `nodes[${index}].id`),
			recordId: requireText(node.recordId, `nodes[${index}].recordId`),
			type: requireText(node.type, `nodes[${index}].type`),
			label: requireText(node.label, `nodes[${index}].label`),
			subtitle: optionalText(node.subtitle),
			status: optionalText(node.status),
			expandable: node.expandable === true,
		};
	});

	const edges: GraphEdge[] = candidate.edges.map((entry, index) => {
		const edge = toObject(entry, `"edges[${index}]"`);
		return {
			id: requireText(edge.id, `edges[${index}].id`),
			source: requireText(edge.source, `edges[${index}].source`),
			target: requireText(edge.target, `edges[${index}].target`),
			type: optionalText(edge.type),
			label: optionalText(edge.label),
		};
	});

	return { nodes, edges };
}

export function parseWidgetPayload(
	input: string | WidgetPayload,
): WidgetPayload {
	const candidate = toObject(input, "Die Nutzlast des Widgets");
	const fragment = parseGraphFragment(candidate as unknown as GraphFragment);
	const meta = candidate.meta;

	if (meta === undefined || meta === null) {
		return fragment;
	}

	const metaObject = toObject(meta, '"meta"');
	return {
		...fragment,
		meta: {
			title: optionalText(metaObject.title),
			rootId: optionalText(metaObject.rootId),
			locale: optionalText(metaObject.locale),
		},
	};
}

export function createDirtyStatePayload(dirty: boolean): string {
	return JSON.stringify({ dirty });
}

async function fetchWidgetPayload(): Promise<WidgetPayload> {
	if (import.meta.env.DEV && isMockMode()) {
		const { samplePayload } = await import("../sampleData");
		return samplePayload;
	}

	return FMGofer.PerformScript(FM_SCRIPTS.getData).json<WidgetPayload>();
}

async function performEvent(parameter: {
	event: string;
	data: NodeEventData;
}): Promise<string> {
	if (import.meta.env.DEV && isMockMode()) {
		const { mockEventResult } = await import("../sampleData");
		return mockEventResult(parameter.event, parameter.data);
	}

	return processInFM(FM_SCRIPTS.handleEvent, parameter);
}

function processInFM(script: string, parameter: unknown): Promise<string> {
	if (!window.FileMaker) {
		return Promise.reject(new Error("FileMaker ist nicht verfügbar."));
	}

	return FMGofer.PerformScript(script, parameter);
}

export function installFMWidgetApi(options: InstallApiOptions): () => void {
	const api: FMWidgetApi = {
		load(payload) {
			try {
				options.onLoad(parseWidgetPayload(payload));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async refresh() {
			options.onRefreshStart();
			try {
				options.onLoad(parseWidgetPayload(await fetchWidgetPayload()));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestData() {
			const parameter = { data: options.getData() };
			options.onRequestStart("data", {
				script: FM_SCRIPTS.reportData,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportData, parameter);
				options.onRequestSuccess("data", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestState() {
			const parameter = { dirty: options.getDirty() };
			options.onRequestStart("state", {
				script: FM_SCRIPTS.reportState,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportState, parameter);
				options.onRequestSuccess("state", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async sendEvent(event, data) {
			const parameter = { event, data };
			options.onRequestStart("event", {
				script: FM_SCRIPTS.handleEvent,
				parameter,
			});
			try {
				return await performEvent(parameter);
			} catch (error) {
				options.onError(normalizeError(error));
				return null;
			}
		},
	};

	window.fmWidget = api;
	window.fmWidgetLoad = api.load;
	window.fmWidgetRefresh = () => {
		void api.refresh();
	};
	window.fmWidgetRequestData = () => {
		void api.requestData();
	};
	window.fmWidgetRequestState = () => {
		void api.requestState();
	};

	return () => {
		if (window.fmWidget === api) {
			window.fmWidget = undefined;
			window.fmWidgetLoad = undefined;
			window.fmWidgetRefresh = undefined;
			window.fmWidgetRequestData = undefined;
			window.fmWidgetRequestState = undefined;
		}
	};
}

function normalizeError(error: unknown): Error {
	return error instanceof Error ? error : new Error(String(error));
}
