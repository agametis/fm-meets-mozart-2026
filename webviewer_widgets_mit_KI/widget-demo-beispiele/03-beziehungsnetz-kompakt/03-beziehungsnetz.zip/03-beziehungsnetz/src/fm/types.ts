/** Node types the widget styles and lists in the legend. */
export const KNOWN_NODE_TYPES = [
	"company",
	"contact",
	"project",
	"invoice",
] as const;

export type KnownNodeType = (typeof KNOWN_NODE_TYPES)[number];

export interface GraphNode {
	/** Stable identifier used for deduplication when relations are loaded. */
	id: string;
	/** FileMaker record identifier reported back with select-record. */
	recordId: string;
	/** A KnownNodeType, or any other string, which renders neutrally. */
	type: string;
	label: string;
	subtitle?: string;
	status?: string;
	/** True when FM can supply further relations for this node. */
	expandable?: boolean;
}

export interface GraphEdge {
	id: string;
	source: string;
	target: string;
	type?: string;
	label?: string;
}

export interface GraphFragment {
	nodes: GraphNode[];
	edges: GraphEdge[];
}

export interface WidgetPayload extends GraphFragment {
	meta?: {
		title?: string;
		rootId?: string;
		locale?: string;
	};
}

/** Reported to FM through fmWidget_reportData. Display state only. */
export interface ViewState {
	selectedNodeId: string | null;
	selectedRecordId: string | null;
	selectedType: string | null;
	visibleTypes: string[];
	nodeCount: number;
	edgeCount: number;
}

/** Business payload of an event sent to fmWidget_handleEvent. */
export interface NodeEventData {
	nodeId: string;
	recordId: string;
	type: string;
}
