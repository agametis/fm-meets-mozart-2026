import { describe, expect, it } from "vitest";

import type { GraphFragment } from "./fm/types";
import { EMPTY_GRAPH, legendTypes, mergeGraph } from "./graph";

const BASE: GraphFragment = {
	nodes: [
		{
			id: "company:1001",
			recordId: "1001",
			type: "company",
			label: "Muster AG",
			expandable: true,
		},
		{
			id: "contact:2101",
			recordId: "2101",
			type: "contact",
			label: "Anna Berger",
			expandable: false,
		},
	],
	edges: [
		{ id: "edge:1", source: "company:1001", target: "contact:2101" },
	],
};

const EXPANSION: GraphFragment = {
	nodes: [
		{
			id: "invoice:4101",
			recordId: "4101",
			type: "invoice",
			label: "RE-2026-0041",
			expandable: false,
		},
	],
	edges: [
		{ id: "edge:7", source: "company:1001", target: "invoice:4101" },
	],
};

describe("mergeGraph", () => {
	it("adds an expansion to the existing graph", () => {
		const merged = mergeGraph(BASE, EXPANSION);

		expect(merged.nodes).toHaveLength(3);
		expect(merged.edges).toHaveLength(2);
	});

	it("stays free of duplicates when the same node is expanded twice", () => {
		const once = mergeGraph(BASE, EXPANSION);
		const twice = mergeGraph(once, EXPANSION);

		expect(twice.nodes).toEqual(once.nodes);
		expect(twice.edges).toEqual(once.edges);
	});

	it("keeps the node already on the canvas when an id repeats", () => {
		const renamed: GraphFragment = {
			nodes: [{ ...BASE.nodes[0], label: "Anderer Name" }],
			edges: [],
		};

		expect(mergeGraph(BASE, renamed).nodes[0].label).toBe("Muster AG");
	});

	it("drops edges whose endpoints are missing, which Cytoscape would reject", () => {
		const dangling: GraphFragment = {
			nodes: [],
			edges: [{ id: "edge:99", source: "company:1001", target: "ghost:1" }],
		};

		expect(mergeGraph(BASE, dangling).edges).toHaveLength(1);
	});

	it("does not mutate the graph it was given", () => {
		mergeGraph(BASE, EXPANSION);

		expect(BASE.nodes).toHaveLength(2);
		expect(BASE.edges).toHaveLength(1);
	});

	it("loads an initial payload by merging into the empty graph", () => {
		expect(mergeGraph(EMPTY_GRAPH, BASE)).toEqual(BASE);
	});
});

describe("legendTypes", () => {
	it("always lists the known types, so invoice has an entry before the first expansion", () => {
		expect(legendTypes(BASE.nodes)).toEqual([
			"company",
			"contact",
			"project",
			"invoice",
		]);
	});

	it("appends unknown types instead of hiding those nodes from the legend", () => {
		const withUnknown = [
			...BASE.nodes,
			{ id: "x:1", recordId: "1", type: "asset", label: "Anlage" },
		];

		expect(legendTypes(withUnknown)).toEqual([
			"company",
			"contact",
			"project",
			"invoice",
			"asset",
		]);
	});
});
