import type { GraphFragment, GraphNode } from "./fm/types";
import { KNOWN_NODE_TYPES } from "./fm/types";

/** One colour per known node type; unknown types fall back to slate. */
const TYPE_COLORS: Record<string, string> = {
	company: "#1d4ed8",
	contact: "#0d9488",
	project: "#c2410c",
	invoice: "#7c3aed",
};

export function colorForType(type: string): string {
	return TYPE_COLORS[type] ?? "#64748b";
}

export const EMPTY_GRAPH: GraphFragment = { nodes: [], edges: [] };

/**
 * Adds a fragment to the current graph without creating duplicates. Nodes and
 * edges are identified by their stable `id`; the first occurrence wins, so
 * re-expanding a node cannot overwrite what is already on the canvas. Edges
 * whose endpoints are still unknown after the merge are dropped, because
 * Cytoscape refuses an edge without both of its nodes.
 */
export function mergeGraph(
	current: GraphFragment,
	fragment: GraphFragment,
): GraphFragment {
	const nodes = [...current.nodes];
	const nodeIds = new Set(nodes.map((node) => node.id));

	for (const node of fragment.nodes) {
		if (nodeIds.has(node.id)) continue;
		nodeIds.add(node.id);
		nodes.push(node);
	}

	const edges = [...current.edges];
	const edgeIds = new Set(edges.map((edge) => edge.id));

	for (const edge of fragment.edges) {
		if (edgeIds.has(edge.id)) continue;
		if (!nodeIds.has(edge.source) || !nodeIds.has(edge.target)) continue;
		edgeIds.add(edge.id);
		edges.push(edge);
	}

	return { nodes, edges };
}

/**
 * Legend order: every known type is always listed, so `invoice` already has its
 * colour and entry before the first expansion delivers one. Unknown types are
 * appended as they appear, which keeps the legend from reshuffling.
 */
export function legendTypes(nodes: GraphNode[]): string[] {
	const unknown = [
		...new Set(
			nodes
				.map((node) => node.type)
				.filter((type) => !KNOWN_NODE_TYPES.includes(type as never)),
		),
	].sort();

	return [...KNOWN_NODE_TYPES, ...unknown];
}
