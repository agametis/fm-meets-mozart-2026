import type { GraphFragment, NodeEventData, WidgetPayload } from "./fm/types";

/**
 * Development-only fixture for the explicit `?data=test` mock mode. This module
 * must stay reachable exclusively through the dynamic imports in
 * `src/fm/bridge.ts`; `forbid-dev-only-modules` in vite.config.ts fails the
 * production build if any of it reaches the bundle.
 */
export const samplePayload: WidgetPayload & {
	__sampleDataModule: true;
} = {
	__sampleDataModule: true,
	meta: {
		title: "Beziehungsnetz",
		rootId: "company:1001",
		locale: "de-DE",
	},
	nodes: [
		{
			id: "company:1001",
			recordId: "1001",
			type: "company",
			label: "Muster AG",
			subtitle: "Kunde",
			status: "active",
			expandable: true,
		},
		{
			id: "contact:2101",
			recordId: "2101",
			type: "contact",
			label: "Anna Berger",
			subtitle: "Projektleitung",
			status: "active",
			expandable: false,
		},
		{
			id: "contact:2102",
			recordId: "2102",
			type: "contact",
			label: "Lukas Kern",
			subtitle: "Einkauf",
			status: "active",
			expandable: false,
		},
		{
			id: "project:3101",
			recordId: "3101",
			type: "project",
			label: "Website Relaunch",
			subtitle: "in Umsetzung",
			status: "active",
			expandable: true,
		},
		{
			id: "project:3102",
			recordId: "3102",
			type: "project",
			label: "Serviceportal",
			subtitle: "geplant",
			status: "planned",
			expandable: true,
		},
	],
	edges: [
		{
			id: "edge:1",
			source: "company:1001",
			target: "contact:2101",
			type: "employs",
			label: "Ansprechpartnerin",
		},
		{
			id: "edge:2",
			source: "company:1001",
			target: "contact:2102",
			type: "employs",
			label: "Ansprechpartner",
		},
		{
			id: "edge:3",
			source: "company:1001",
			target: "project:3101",
			type: "owns",
			label: "Projekt",
		},
		{
			id: "edge:4",
			source: "company:1001",
			target: "project:3102",
			type: "owns",
			label: "Projekt",
		},
		{
			id: "edge:5",
			source: "contact:2101",
			target: "project:3101",
			type: "leads",
			label: "leitet",
		},
	],
};

/** What FM would answer to an expand-node event, keyed by node id. */
const sampleExpansions: Record<string, GraphFragment> = {
	"company:1001": {
		nodes: [
			{
				id: "contact:2103",
				recordId: "2103",
				type: "contact",
				label: "Sofia Mayr",
				subtitle: "Buchhaltung",
				status: "active",
				expandable: false,
			},
			{
				id: "invoice:4101",
				recordId: "4101",
				type: "invoice",
				label: "RE-2026-0041",
				subtitle: "12.500,00 EUR",
				status: "open",
				expandable: false,
			},
		],
		edges: [
			{
				id: "edge:6",
				source: "company:1001",
				target: "contact:2103",
				type: "employs",
				label: "Ansprechpartnerin",
			},
			{
				id: "edge:7",
				source: "company:1001",
				target: "invoice:4101",
				type: "billed",
				label: "Rechnung",
			},
		],
	},
	"project:3101": {
		nodes: [
			{
				id: "invoice:4102",
				recordId: "4102",
				type: "invoice",
				label: "RE-2026-0042",
				subtitle: "8.900,00 EUR",
				status: "paid",
				expandable: false,
			},
		],
		edges: [
			{
				id: "edge:8",
				source: "project:3101",
				target: "invoice:4102",
				type: "billed",
				label: "Teilrechnung",
			},
			// References a node that only exists after expanding the company.
			// Before that it is dropped, afterwards it completes the triangle.
			{
				id: "edge:9",
				source: "contact:2103",
				target: "project:3101",
				type: "supports",
				label: "unterstützt",
			},
		],
	},
};

/**
 * Stands in for `fmWidget_handleEvent` while in mock mode. `project:3102`
 * deliberately fails so the error path stays demonstrable without FileMaker.
 */
export function mockEventResult(
	event: string,
	data: NodeEventData,
): Promise<string> {
	if (event === "select-record") {
		return delayed(`Datensatz ${data.recordId} in FileMaker angezeigt.`);
	}

	if (event === "expand-node") {
		const expansion = sampleExpansions[data.nodeId];
		if (!expansion) {
			return delayed(
				Promise.reject(
					new Error(
						`Für "${data.nodeId}" konnten keine weiteren Beziehungen geladen werden.`,
					),
				),
			);
		}
		return delayed(JSON.stringify(expansion));
	}

	return Promise.reject(new Error(`Unbekanntes Ereignis "${event}".`));
}

function delayed<T>(value: T | Promise<T>): Promise<T> {
	return new Promise<T>((resolve, reject) => {
		setTimeout(() => {
			Promise.resolve(value).then(resolve, reject);
		}, 600);
	});
}
