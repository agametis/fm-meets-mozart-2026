# FileMaker-Integration – Auftragskarte

Diese Datei beschreibt nur, was das Widget von FileMaker braucht. Die Datei `Auftragskarte.fmp12` wird nicht automatisch bearbeitet; alle Schritte werden in FileMaker Pro von Hand umgesetzt.

## Web Viewer einrichten

- Objektname des Web Viewers festlegen, z. B. `wvAuftragskarte` (unten als `<Web Viewer>` bezeichnet).
- **„JavaScript darf FileMaker-Skripte ausführen“** (Allow JavaScript to perform FileMaker scripts) aktivieren.
- Das Widget wird mit `npm run deploy-to-fm` gebaut und über `fmWidget_upload` hochgeladen (`widgetName`: `auftragskarte`).
- **Bereitschaft:** FileMaker kann JavaScript erst aufrufen, wenn die Seite geladen ist. Skripte, die direkt nach dem Layoutwechsel `fmWidgetLoad` aufrufen, brauchen eine kurze Wartezeit oder einen erneuten Versuch. Beim Start ruft das Widget selbst `fmWidget_getData` auf; dafür ist keine Wartelogik nötig.

### Kartenkacheln

- Die Kacheln kommen aus `meta.tileUrl`; ohne Angabe von `https://tile.openstreetmap.org/{z}/{x}/{y}.png`. Die Attribution (`meta.attribution`) bleibt immer sichtbar.
- Die [OSM-Tile-Usage-Policy](https://operations.osmfoundation.org/policies/tiles/) verlangt einen gültigen HTTP-Referer. Ein FileMaker Web Viewer mit `data:`-URL sendet unter Umständen keinen; OSM liefert dann gesperrte Kacheln.
- Das zuerst in echtem FileMaker (Pro und ggf. WebDirect) prüfen. Werden Kacheln gesperrt oder sind hohe Zugriffszahlen zu erwarten, einen Kachelanbieter mit eigenem Schlüssel über `meta.tileUrl` und `meta.attribution` eintragen.
- Das Widget lädt nur sichtbare Kacheln; es gibt kein Vorladen und keinen Offline-Download.

## Skriptvertrag

### `fmWidget_getData`

- Richtung: Widget → FileMaker → Widget (FMGofer, mit Antwort). Wird beim Start und bei „Aktualisieren“ aufgerufen.
- Parameter: FMGofer-Hülle, kein fachlicher Parameter.
- Ergebnis: JSON-Text der Nutzlast.

```json
{
  "meta": {
    "title": "Auftragskarte Salzburg",
    "locale": "de-AT",
    "center": { "latitude": 47.8014, "longitude": 13.0448 },
    "zoom": 13,
    "fitMarkers": true,
    "tileUrl": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
    "attribution": "© OpenStreetMap contributors"
  },
  "data": [
    {
      "recordId": "5001",
      "orderNumber": "AU-2026-184",
      "jobType": "plumbing",
      "jobLabel": "Sanitär",
      "status": "urgent",
      "statusLabel": "Dringend",
      "customer": "Musterhaus Verwaltung",
      "address": {
        "street": "Getreidegasse 15",
        "postalCode": "5020",
        "city": "Salzburg",
        "latitude": 47.80039,
        "longitude": 13.04399
      },
      "appointment": { "date": "2026-09-15", "timeFrom": "09:00", "timeTo": "10:30" },
      "summary": "Wasserverlust unter dem Waschbecken prüfen",
      "contactName": "Maria Leitner",
      "contactPhone": "+43 662 555 0101"
    }
  ]
}
```

Regeln für den JSON-Aufbau:

- `meta` und alle Felder darin sind optional.
- `recordId` ist Pflicht und muss nicht leer sein.
- `address.latitude` und `address.longitude` sind Pflicht. Am besten mit `JSONNumber` setzen; Zahlen-Strings werden ebenfalls akzeptiert.
- Aufträge mit leeren oder ungültigen Koordinaten (auch `0/0`) oder ohne `recordId` werden ausgelassen und im Widget gezählt, führen aber nicht zu einem Fehler.
- Werte für `jobType`: `plumbing`, `electrical`, `heating`, `painting`, `carpentry`, `roofing`. Andere Werte erscheinen als „Sonstige“.
- Werte für `status`: `new`, `scheduled`, `in-progress`, `urgent`, `completed`, `cancelled`. Andere Werte erscheinen als „unbekannt“.
- Datum als `JJJJ-MM-TT`, Uhrzeiten als `hh:mm`, z. B. mit `GetAsText ( Year ( … ) )` o. Ä. selbst zusammensetzen, weil `GetAsText` auf Datumsfeldern vom Gebietsschema abhängt.

Relevante Schritte:

```text
Set Variable [ $scriptParameter ; Value: Get ( ScriptParameter ) ]
Set Variable [ $callbackName ; Value: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Set Variable [ $promiseID ; Value: JSONGetElement ( $scriptParameter ; "promiseID" ) ]
# $payload für den obigen Vertrag aufbauen (gefundene Menge der Aufträge durchlaufen).
Perform JavaScript in Web Viewer [ Object Name: "<Web Viewer>" ; Function Name: $callbackName ; Parameters: $promiseID, $payload, False ]
```

Bei einem Fehler in FileMaker stattdessen `Parameters: $promiseID, "Aufträge konnten nicht geladen werden.", True` – der Text erscheint im Widget.

### `fmWidget_handleEvent`

- Richtung: Widget → FileMaker, **ohne Rückmeldung** (`FileMaker.PerformScriptWithOption`, Option `0` = Fortsetzen).
- Auslöser: Schaltfläche „Mehr Details“ im Pop-up.
- Parameter: **direkt** in `Get ( ScriptParameter )`, ohne FMGofer-Hülle (kein `parameter`, kein `callbackName`):

```json
{ "event": "open-order", "data": { "recordId": "5002", "orderNumber": "AU-2026-185" } }
```

- Ergebnis: keines. Kein Callback aufrufen.

Relevante Schritte:

```text
Set Variable [ $event ; Value: JSONGetElement ( Get ( ScriptParameter ) ; "event" ) ]
Set Variable [ $recordId ; Value: JSONGetElement ( Get ( ScriptParameter ) ; "data.recordId" ) ]
Set Variable [ $orderNumber ; Value: JSONGetElement ( Get ( ScriptParameter ) ; "data.orderNumber" ) ]
If [ $event = "open-order" ]
  # Hier entscheidet FileMaker über die Navigation zum Auftrag mit $recordId.
End If
```

### `fmWidget_reportData`

- Richtung: FileMaker fragt per `fmWidgetRequestData` an → Widget ruft dieses Skript per FMGofer auf (mit Rückmeldung).
- Parameter (unter `parameter` in der Hülle) – nur Darstellungszustand, keine fachlichen Daten:

```json
{
  "data": {
    "selectedRecordId": "5002",
    "activeJobTypes": ["plumbing", "electrical"],
    "visibleRecordIds": ["5001", "5002"]
  }
}
```

  `selectedRecordId` ist `null`, wenn kein Pop-up offen ist. `activeJobTypes` kann `"other"` enthalten.
- Ergebnis: Meldungstext; `False` = erfolgreich, `True` = Fehler.

```text
Set Variable [ $scriptParameter ; Value: Get ( ScriptParameter ) ]
Set Variable [ $data ; Value: JSONGetElement ( $scriptParameter ; "parameter.data" ) ]
Set Variable [ $callbackName ; Value: JSONGetElement ( $scriptParameter ; "callbackName" ) ]
Set Variable [ $promiseID ; Value: JSONGetElement ( $scriptParameter ; "promiseID" ) ]
# $data verarbeiten, z. B. visibleRecordIds übernehmen.
Perform JavaScript in Web Viewer [ Object Name: "<Web Viewer>" ; Function Name: $callbackName ; Parameters: $promiseID, "Kartenzustand übernommen.", False ]
```

### `fmWidget_reportState`

- Richtung: FileMaker fragt per `fmWidgetRequestState` an → Widget ruft dieses Skript per FMGofer auf.
- Parameter: `{ "dirty": false }` – immer `false`, das Widget ändert keine fachlichen Daten. FileMaker muss beim Schließen nichts abfragen; das Skript wird nur für Vollständigkeit bereitgestellt.
- Ergebnis: Meldungstext mit `False`.

## JavaScript-Einstiegspunkte

In **Perform JavaScript in Web Viewer** nur diese Funktionsnamen verwenden (keine Punkt-Notation):

| Funktion | Parameter | Wirkung |
| --- | --- | --- |
| `fmWidgetLoad` | JSON-Text nach obigem Vertrag | Ersetzt die Aufträge, schließt das Pop-up, passt die Karte neu ein. Filter bleiben erhalten. |
| `fmWidgetRefresh` | – | Ruft `fmWidget_getData` erneut auf. |
| `fmWidgetRequestData` | – | Startet `fmWidget_reportData`. |
| `fmWidgetRequestState` | – | Startet `fmWidget_reportState`. |

Die Anfrage-Adapter kehren sofort zurück; das aufrufende FileMaker-Skript darf keinen Rückgabewert erwarten und sollte danach enden, damit kein Warte-Zyklus entsteht.

## Manuelle Prüfung

- [ ] Web Viewer lädt; Kartenkacheln erscheinen (nicht gesperrt), Attribution unten rechts sichtbar.
- [ ] Beim Öffnen werden die Aufträge automatisch geladen und alle Pins eingepasst.
- [ ] „Aktualisieren“ und `fmWidgetRefresh` laden neu; `fmWidgetLoad` ersetzt die Daten.
- [ ] Ein Auftrag ohne Koordinaten erscheint nicht und wird im Hinweis gezählt.
- [ ] Umlaute in Pop-up, Filtern und Hinweis sind korrekt – auch in WebDirect.
- [ ] „Mehr Details“ startet `fmWidget_handleEvent` mit `open-order`, `recordId` und `orderNumber`.
- [ ] Fehlerhaftes JSON aus `fmWidget_getData` zeigt eine Fehlermeldung; zuvor geladene Pins bleiben.
- [ ] `fmWidgetRequestData` liefert Auswahl, aktive Filter und sichtbare recordIds an `fmWidget_reportData`.
- [ ] `fmWidgetRequestState` liefert `{ "dirty": false }`.
- [ ] Größenänderung des Web Viewers passt die Karte ohne graue Ränder an.
