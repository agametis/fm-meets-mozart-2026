# Auftragskarte — Umsetzungsplan

Status: freigegeben am 2026-09-15.

## Ziel

Handwerkeraufträge aus FileMaker werden als unterscheidbare Pins auf einer Leaflet/OpenStreetMap-Karte angezeigt – mit Filter nach Auftragsart, Legende und Detail-Pop-up, aus dem „Mehr Details“ die Navigation an FileMaker übergibt.

## Bestätigte Namen

- FileMaker-Datei: `Auftragskarte.fmp12` (umbenannt aus `FM-Starter-AI.fmp12`)
- npm-Paket: `auftragskarte`
- Widget-Kennung (`fmConfig.widgetName`): `auftragskarte`
- Anzeigetitel / `<title>`: Auftragskarte, `lang="de"`

## Ablauf

1. Beim Öffnen ruft das Widget automatisch `fmWidget_getData` ab; FileMaker kann jederzeit per `fmWidgetLoad` neue Daten schieben. Schaltfläche „Aktualisieren“ lädt neu.
2. Das Widget validiert die Daten. Gültige Aufträge werden Pins. Bei `fitMarkers ≠ false` passt sich die Karte auf alle Pins ein (ein einzelner Pin: `meta.zoom`), sonst gelten `meta.center`/`meta.zoom`.
3. Aufträge ohne `recordId` oder ohne gültige Koordinaten werden ausgelassen; ein Hinweis zählt sie („2 Aufträge ohne gültige Koordinaten oder Datensatz-ID nicht angezeigt“).
4. Filterleiste: je Auftragsart ein Schalter mit Symbol, `jobLabel` und Anzahl; „Sonstige“ nur bei unbekannten `jobType`. Einklappbare Status-Legende unten links auf der Karte.
5. Klick auf einen Pin öffnet das Pop-up und markiert den Pin als ausgewählt: Auftragsnummer, Status, Kunde, vollständige Adresse, Terminfenster, Kurzbeschreibung, Ansprechpartner, Telefon.
6. „Mehr Details“ sendet ohne Rückmeldung an `fmWidget_handleEvent`; die Karte bleibt unverändert.

Zustände:

- Warten/Laden: Ladeanzeige.
- Bereit: Karte, Filter und Legende.
- Hinweisbanner für ausgelassene Aufträge.
- Leerzustand: Kein gültiger Auftrag → Karte bei `meta.center` mit „Keine Aufträge mit gültigen Koordinaten“.
- Alle Arten abgewählt: Hinweis statt Leerzustand.
- Fehler: Meldung mit JSON-Pfad; zuletzt gültige Daten bleiben sichtbar.

## Datenvertrag (Eingabe)

Richtung: Widget ruft `fmWidget_getData` ab oder FileMaker schiebt per `fmWidgetLoad`. Form wie das Beispiel in `src/sampleData.ts`: `meta` + `data[]`.

- `meta` ist optional. Standardwerte:
  - `title`: „Auftragskarte“
  - `locale`: `de-DE`
  - `center`: Salzburg aus dem Beispiel
  - `zoom`: 13
  - `fitMarkers`: `true`
  - `tileUrl`: `https://tile.openstreetmap.org/{z}/{x}/{y}.png`
  - `attribution`: „© OpenStreetMap contributors“
- Pflichtfelder je Auftrag:
  - `recordId`: nicht leerer String.
  - `address.latitude`: −90…90.
  - `address.longitude`: −180…180.
  - Koordinaten als Zahl oder Zahlen-String; die Kombination `0/0` gilt als leer.
- Alles andere ist optional. Leere Textfelder lässt das Pop-up weg; eine leere Überschrift wird „–“.
- `jobType`: `plumbing | electrical | heating | painting | carpentry | roofing`; alles andere gilt als „Sonstige“.
- `status`: `new | scheduled | in-progress | urgent | completed | cancelled`; alles andere gilt als „unbekannt“. Angezeigt wird `statusLabel`, ersatzweise der Schlüssel.
- Termin: `date` + `timeFrom`–`timeTo`, per `Intl` mit `meta.locale` formatiert, z. B. „Di., 15.09.2026, 09:00–10:30“. Ein ungültiges Datum wird roh angezeigt.
- Fehler nur, wenn die Nutzlast kein Objekt ist oder `data` kein Array ist. Einzelne kaputte Aufträge führen nie zu einem Fehler.

## Ausgabe und Zustand

Fachlich nur lesend.

- **open-order** (ohne Rückmeldung): `window.FileMaker.PerformScriptWithOption("fmWidget_handleEvent", <JSON>, "0")` mit
  `{ "event": "open-order", "data": { "recordId": "5002", "orderNumber": "AU-2026-185" } }`.
  Der Parameter kommt **ohne FMGofer-Hülle** an. Fehlt `window.FileMaker`, zeigt das Widget einen Fehler.
- **Report Data**: `fmWidgetRequestData` → `fmWidget_reportData` (mit Rückmeldung):
  `{ "data": { "selectedRecordId": "5002" | null, "activeJobTypes": [...], "visibleRecordIds": [...] } }`
- **Report State**: `fmWidgetRequestState` → `fmWidget_reportState` mit `{ "dirty": false }` – immer.
- Das `save` des Templates entfällt; die Brücke erhält `sendEvent(event, data)`. Keine neuen Skriptnamen, keine zweite Brücke.

## Pins und Legende

- Jeder Pin ist ein `L.divIcon` mit im Code eingebettetem SVG: Tropfenform mit Glyphe je Auftragsart:
  - Wassertropfen: Sanitär
  - Blitz: Elektro
  - Flamme: Heizung
  - Pinsel: Malerarbeiten
  - Säge: Tischlerei
  - Hausdach: Dacharbeiten
  - Punkt: Sonstige
- Status mit Farbe und farbunabhängigem Merkmal:
  - `new`: blau ★
  - `scheduled`: violett, normale Kontur
  - `in-progress`: orange ◐
  - `urgent`: rot, dicke Doppelkontur „!“
  - `completed`: grün ✓
  - `cancelled`: grau, gestrichelt, blass
  - unbekannt: grau „?“
- Der ausgewählte Pin ist größer.
- Das Icon-HTML entsteht ausschließlich aus Konstanten, nie aus FileMaker-Texten. `title` enthält die Auftragsnummer als reines Attribut.
- Das Pop-up wird mit `document.createElement` und `textContent` gebaut; kein HTML-String aus FileMaker-Texten.

## Stack

- `leaflet` 1.9.4 (Laufzeit, BSD-2-Clause): Karte, Kacheln, DivIcons, Pop-ups, Attribution. Das CSS wird importiert und in `dist/index.html` eingebettet.
- `@types/leaflet` (nur Entwicklung): Typdefinitionen.
- Bewusst weggelassen:
  - `react-leaflet`: ein Effekt genügt.
  - Clustering-Plugin.
  - `lucide-react`: bewusste Abweichung von der Icon-Regel wegen der Vorgabe eigener lokaler SVGs.
- Kacheln: kein Vorladen, kein Offline-Cache; die Attribution ist immer sichtbar.

## Dateien

- Vertrag:
  - `src/fm/types.ts`
  - `src/fm/bridge.ts`
  - `src/sampleData.ts`: 6 Aufträge + 2 Grenzfälle, Marker `__sampleDataModule` bleibt
  - `src/App.tsx`
  - `src/fm/bridge.test.ts`
- Neu:
  - `src/orders.ts`: Filter, Termin, Report-Data-Nutzlast
  - `src/orders.test.ts`
  - `src/markers.ts`: SVG, Icons, Pop-up-DOM
  - `src/OrderMap.tsx`: Leaflet-Effekt, Legende
- `src/index.css`.
- Identität:
  - `package.json`, `package-lock.json`
  - `fm/fmConfig.js`: `server: "$"` bleibt
  - `index.html`
  - `README.md`
  - `auftragskarte.code-workspace`
  - `Auftragskarte.fmp12`
- Unverändert: `vite.config.ts` und `scripts/verify-build-encoding.js`.
- Testmodus (`?data=test`, nur Entwicklung): Panel unter der Karte mit „Report Data“, „Report State“ und Vorschau von Zielskript und Parameter (auch für open-order).

## FileMaker-Änderungen

Nur dokumentiert in `docs/FM-INTEGRATION.md`; die `.fmp12` wird nicht bearbeitet.

- Web Viewer: JavaScript darf FileMaker-Skripte ausführen; Bereitschaft abwarten.
- `fmWidget_getData`: JSON aufbauen (Koordinaten als `JSONNumber`) und Callback aufrufen.
- `fmWidget_handleEvent`: ohne Hülle `event` und `data.recordId` lesen; die Navigation entscheidet FileMaker.
- `fmWidget_reportData` und `fmWidget_reportState` mit Callback.
- Adapter: `fmWidgetLoad`, `fmWidgetRefresh`, `fmWidgetRequestData`, `fmWidgetRequestState`.
- Hinweis zu Referer und OSM-Nutzungsregeln.

## Abnahmekriterien

- [ ] Mit `?data=test`: 6 Pins in Salzburg, Karte auf alle eingepasst, Hinweis „2 … nicht angezeigt“.
- [ ] Alle 6 Auftragsarten sind auch in Graustufen am Symbol unterscheidbar; jeder Status ist über Abzeichen oder Kontur erkennbar.
- [ ] Das Pop-up zeigt alle genannten Felder; Umlaute korrekt; `<b>` in einem Text erscheint als Text.
- [ ] „Mehr Details“ zeigt im Testmodus `fmWidget_handleEvent` mit `{event:"open-order", data:{recordId, orderNumber}}`.
- [ ] Filter blenden Pins aus und ein; das offene Pop-up eines ausgeblendeten Pins schließt sich; Report Data spiegelt das.
- [ ] Report State liefert immer `{ "dirty": false }`.
- [ ] `data: []` oder nur ungültige Aufträge → Leerzustand, kein Absturz.
- [ ] Die Attribution ist sichtbar; `tileUrl`/`attribution` aus `meta` werden verwendet.
- [ ] Ohne `data=test` und im Produktions-Build keine Beispieldaten; `dist/index.html` ist ASCII und enthält keine Fixture-Werte.

## Prüfung

- `npm run type-check`
- `npm run lint`
- `npm test`
- `npm run build`
- Gezielte Tests:
  - Validierung (gültig, ausgelassen, grober Fehler, Umlaute)
  - Termin
  - Filter / Report-Data-Nutzlast
  - `sendEvent` → `PerformScriptWithOption`
  - Report State
  - Testmodus
- Manuelle Sichtung von `dist/index.html` und die FileMaker-Checkliste in `docs/FM-INTEGRATION.md`.

## Annahmen und offene Punkte

- **OSM-Kacheln im Web Viewer:** Sie könnten ohne Referer gesperrt werden – nur in echtem FileMaker prüfbar. Abhilfe: anderer Anbieter per `tileUrl`.
- **Filterwechsel:** Er passt die Karte nicht neu ein; nur Laden und Aktualisieren tun das. Filter bleiben beim Neuladen erhalten; neu auftauchende Auftragsarten sind aktiv.
- **Neuladen:** Das offene Pop-up schließt sich.
- **Telefon:** reiner Text, kein `tel:`-Link.
- **Doppelte `recordId`:** Beide werden angezeigt, keine Deduplizierung.
- **Pop-up-DOM:** Es gibt keinen automatischen DOM-Test (kein jsdom). `textContent` wird im Testmodus manuell mit einem Grenzfall-Auftrag mit `<b>` im Text geprüft.
