export const fmConfig = {
	server: "$",
	file: "Auftragskarte",
	uploadScript: "fmWidget_upload",
	widgetName: "auftragskarte",
};
