import { useEffect, useMemo, useRef, useState } from "react";

import {
	DEFAULT_META,
	installFMWidgetApi,
	isMockMode,
	type FMRequestPreview,
} from "./fm/bridge";
import type { JobType, Order, Status, WidgetPayload } from "./fm/types";
import { glyphSvg, pinSvg } from "./markers";
import { OrderMap } from "./OrderMap";
import {
	createReportedViewState,
	filterOrders,
	skippedMessage,
	summarizeJobTypes,
} from "./orders";

const LEGEND: [Status, string][] = [
	["new", "Neu"],
	["scheduled", "Eingeplant"],
	["in-progress", "In Arbeit"],
	["urgent", "Dringend"],
	["completed", "Erledigt"],
	["cancelled", "Storniert"],
	["unknown", "Unbekannt"],
];

function App() {
	const mockMode = isMockMode();
	const [payload, setPayload] = useState<WidgetPayload | null>(null);
	// Abgewählte statt aktiver Arten: neu auftauchende Arten sind automatisch aktiv.
	const [hiddenJobTypes, setHiddenJobTypes] = useState<ReadonlySet<JobType>>(
		() => new Set(),
	);
	const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);
	const [fitKey, setFitKey] = useState(0);
	const [status, setStatus] = useState<
		"waiting" | "loading" | "ready" | "processing" | "success" | "error"
	>("waiting");
	const [feedback, setFeedback] = useState("");
	const [error, setError] = useState("");
	const [mockRequest, setMockRequest] = useState<FMRequestPreview | null>(null);
	const initialLoadStartedRef = useRef(false);

	const orders = useMemo(() => payload?.orders ?? [], [payload]);
	const jobTypes = useMemo(() => summarizeJobTypes(orders), [orders]);
	const activeJobTypes = useMemo(
		() =>
			new Set(
				jobTypes
					.map((summary) => summary.jobType)
					.filter((jobType) => !hiddenJobTypes.has(jobType)),
			),
		[jobTypes, hiddenJobTypes],
	);
	const visibleOrders = useMemo(
		() => filterOrders(orders, activeJobTypes),
		[orders, activeJobTypes],
	);
	const statusLabels = useMemo(() => {
		const labels = new Map<Status, string>();
		for (const order of orders) {
			if (order.status !== "unknown" && order.statusLabel && !labels.has(order.status)) {
				labels.set(order.status, order.statusLabel);
			}
		}
		return labels;
	}, [orders]);

	const viewState = createReportedViewState(
		orders,
		activeJobTypes,
		selectedRecordId,
	);
	const viewStateRef = useRef(viewState);
	viewStateRef.current = viewState;

	useEffect(() => {
		const uninstall = installFMWidgetApi({
			getData: () => viewStateRef.current,
			// Das Widget bearbeitet keine fachlichen Daten.
			getDirty: () => false,
			onLoad: (nextPayload) => {
				setPayload(nextPayload);
				setSelectedRecordId(null);
				setFitKey((key) => key + 1);
				setError("");
				setFeedback("");
				setStatus("ready");
			},
			onError: (nextError) => {
				setError(nextError.message);
				setFeedback("");
				setStatus("error");
			},
			onRefreshStart: () => {
				setError("");
				setFeedback("");
				setStatus("loading");
			},
			onRequestStart: (request, preview) => {
				if (mockMode) {
					setMockRequest(preview);
				}
				setError("");
				if (request === "event") return;
				setFeedback(
					request === "data"
						? "FileMaker verarbeitet den Kartenzustand …"
						: "FileMaker verarbeitet den Widget-Status …",
				);
				setStatus("processing");
			},
			onRequestSuccess: (_request, message) => {
				setError("");
				setFeedback(message);
				setStatus("success");
			},
		});

		if (!initialLoadStartedRef.current) {
			initialLoadStartedRef.current = true;
			void window.fmWidget?.refresh();
		}

		return uninstall;
	}, [mockMode]);

	const openOrder = (order: Order) => {
		window.fmWidget?.sendEvent("open-order", {
			recordId: order.recordId,
			orderNumber: order.orderNumber,
		});
	};

	const toggleJobType = (jobType: JobType) => {
		setHiddenJobTypes((current) => {
			const next = new Set(current);
			if (next.has(jobType)) next.delete(jobType);
			else next.add(jobType);
			return next;
		});
	};

	return (
		<main className="app-shell">
			<header className="toolbar">
				<div className="toolbar__title">
					<h1>{payload?.meta.title ?? "Auftragskarte"}</h1>
					<p className="status" data-status={status} aria-live="polite">
						{status === "waiting" && "Warte auf Daten aus FileMaker …"}
						{status === "loading" && "Aufträge werden geladen …"}
						{status === "ready" &&
							`${visibleOrders.length} von ${orders.length} Aufträgen sichtbar${
								mockMode ? " · Testmodus" : ""
							}`}
						{(status === "processing" || status === "success") && feedback}
						{status === "error" && "Anfrage konnte nicht verarbeitet werden."}
					</p>
				</div>
				<button
					type="button"
					className="button"
					onClick={() => void window.fmWidget?.refresh()}
				>
					Aktualisieren
				</button>
			</header>

			{payload && (
				<nav className="filters" aria-label="Filter nach Auftragsart">
					{jobTypes.map((summary) => (
						<button
							key={summary.jobType}
							type="button"
							className="filter"
							aria-pressed={activeJobTypes.has(summary.jobType)}
							data-empty={summary.count === 0}
							onClick={() => toggleJobType(summary.jobType)}
						>
							<span
								className="filter__icon"
								dangerouslySetInnerHTML={{ __html: glyphSvg(summary.jobType) }}
							/>
							{summary.label}
							<span className="filter__count">{summary.count}</span>
						</button>
					))}
				</nav>
			)}

			{error && (
				<p className="banner banner--error" role="alert">
					{error}
				</p>
			)}
			{payload && payload.skippedCount > 0 && (
				<p className="banner banner--warning">
					{skippedMessage(payload.skippedCount)}
				</p>
			)}
			{orders.length > 0 && visibleOrders.length === 0 && (
				<p className="banner">
					Alle Auftragsarten sind ausgeblendet. Filter oben wieder einschalten.
				</p>
			)}

			<section className="map-area">
				<OrderMap
					meta={payload?.meta ?? DEFAULT_META}
					orders={visibleOrders}
					selectedRecordId={selectedRecordId}
					fitKey={fitKey}
					onSelect={setSelectedRecordId}
					onOpenOrder={openOrder}
				/>

				{payload && orders.length === 0 && (
					<div className="map-empty" role="status">
						<strong>Keine Aufträge mit gültigen Koordinaten</strong>
						<span>Sobald FileMaker Aufträge liefert, erscheinen sie hier.</span>
					</div>
				)}

				{payload && orders.length > 0 && (
					<details className="legend" open>
						<summary>Legende Status</summary>
						<ul>
							{LEGEND.map(([legendStatus, fallback]) => (
								<li key={legendStatus}>
									<span
										className="legend__pin"
										dangerouslySetInnerHTML={{
											__html: pinSvg("other", legendStatus),
										}}
									/>
									{statusLabels.get(legendStatus) ?? fallback}
								</li>
							))}
						</ul>
					</details>
				)}
			</section>

			{mockMode && (
				<section className="mock-request" aria-live="polite">
					<div className="mock-request__actions">
						<p className="eyebrow">Testmodus</p>
						<button
							type="button"
							className="button"
							onClick={() => void window.fmWidget?.requestData()}
						>
							Report Data
						</button>
						<button
							type="button"
							className="button"
							onClick={() => void window.fmWidget?.requestState()}
						>
							Report State
						</button>
					</div>
					{mockRequest ? (
						<>
							<p>
								Zielskript: <code>{mockRequest.script}</code>
							</p>
							<pre>{JSON.stringify(mockRequest.parameter, null, 2)}</pre>
						</>
					) : (
						<p>
							Mehr Details, Report Data oder Report State zeigen hier die
							FileMaker-Anfrage.
						</p>
					)}
				</section>
			)}
		</main>
	);
}

export default App;
