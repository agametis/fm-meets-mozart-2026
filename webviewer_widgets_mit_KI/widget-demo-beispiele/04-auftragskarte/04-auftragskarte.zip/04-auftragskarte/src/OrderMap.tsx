import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useRef } from "react";

import type { MapMeta, Order } from "./fm/types";
import { createOrderIcon, createPopupContent } from "./markers";

interface OrderMapProps {
	meta: MapMeta;
	/** Aktuell sichtbare (gefilterte) Aufträge. */
	orders: Order[];
	selectedRecordId: string | null;
	/** Ändert sich nur beim Laden neuer Daten und löst das Einpassen aus. */
	fitKey: number;
	onSelect: (recordId: string | null) => void;
	onOpenOrder: (order: Order) => void;
}

export function OrderMap({
	meta,
	orders,
	selectedRecordId,
	fitKey,
	onSelect,
	onOpenOrder,
}: OrderMapProps) {
	const containerRef = useRef<HTMLDivElement>(null);
	const mapRef = useRef<L.Map | null>(null);
	const markersRef = useRef(new Map<Order, L.Marker>());
	const latest = useRef({ meta, orders, onSelect, onOpenOrder });
	latest.current = { meta, orders, onSelect, onOpenOrder };

	useEffect(() => {
		const container = containerRef.current;
		if (!container) return;

		const map = L.map(container).setView(
			[latest.current.meta.center.latitude, latest.current.meta.center.longitude],
			latest.current.meta.zoom,
		);
		mapRef.current = map;
		const markers = markersRef.current;

		// Web Viewer werden in FileMaker oft in der Größe verändert.
		const observer = new ResizeObserver(() => map.invalidateSize());
		observer.observe(container);

		return () => {
			observer.disconnect();
			map.remove();
			markers.clear();
			mapRef.current = null;
		};
	}, []);

	useEffect(() => {
		const map = mapRef.current;
		if (!map) return;
		// Keine Vorab- oder Offline-Downloads: Leaflet lädt nur sichtbare Kacheln.
		const tiles = L.tileLayer(meta.tileUrl, {
			attribution: meta.attribution,
			maxZoom: 19,
		}).addTo(map);
		return () => {
			tiles.remove();
		};
	}, [meta.tileUrl, meta.attribution]);

	// Marker nach Objektidentität abgleichen: Filterwechsel lässt sichtbare
	// Marker samt offenem Pop-up stehen, neu geladene Daten ersetzen alle.
	useEffect(() => {
		const map = mapRef.current;
		if (!map) return;
		const markers = markersRef.current;
		const next = new Set(orders);

		for (const [order, marker] of markers) {
			if (!next.has(order)) {
				marker.remove();
				markers.delete(order);
			}
		}

		for (const order of orders) {
			if (markers.has(order)) continue;
			const marker = L.marker([order.latitude, order.longitude], {
				icon: createOrderIcon(order),
				title: order.orderNumber || order.recordId,
				alt: order.orderNumber || order.recordId,
				riseOnHover: true,
			});
			marker.bindPopup(
				() =>
					createPopupContent(order, latest.current.meta.locale, (clicked) =>
						latest.current.onOpenOrder(clicked),
					),
				{ minWidth: 240, maxWidth: 320 },
			);
			marker.on("popupopen", () => latest.current.onSelect(order.recordId));
			marker.on("popupclose", () => latest.current.onSelect(null));
			marker.addTo(map);
			markers.set(order, marker);
		}
	}, [orders]);

	useEffect(() => {
		for (const [order, marker] of markersRef.current) {
			marker
				.getElement()
				?.classList.toggle(
					"order-pin--selected",
					order.recordId === selectedRecordId,
				);
		}
	}, [selectedRecordId, orders]);

	useEffect(() => {
		const map = mapRef.current;
		if (!map || fitKey === 0) return;
		const { meta: currentMeta, orders: currentOrders } = latest.current;

		if (!currentMeta.fitMarkers || currentOrders.length === 0) {
			map.setView(
				[currentMeta.center.latitude, currentMeta.center.longitude],
				currentMeta.zoom,
			);
		} else if (currentOrders.length === 1) {
			map.setView(
				[currentOrders[0].latitude, currentOrders[0].longitude],
				currentMeta.zoom,
			);
		} else {
			map.fitBounds(
				L.latLngBounds(
					currentOrders.map((order) => [order.latitude, order.longitude]),
				),
				{ padding: [48, 48], maxZoom: 17 },
			);
		}
	}, [fitKey]);

	return <div ref={containerRef} className="order-map" />;
}
