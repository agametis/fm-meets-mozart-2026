import { afterEach, describe, expect, it, vi } from "vitest";

const { performScriptMock } = vi.hoisted(() => ({
	performScriptMock: vi.fn(),
}));

vi.mock("fm-gofer", () => ({
	default: { PerformScript: performScriptMock },
}));

import {
	DEFAULT_META,
	createDirtyStatePayload,
	installFMWidgetApi,
	isMockMode,
	parseWidgetPayload,
} from "./bridge";
import type { ReportedViewState } from "./types";

afterEach(() => {
	performScriptMock.mockReset();
	vi.unstubAllGlobals();
});

const validOrder = {
	recordId: "5001",
	orderNumber: "AU-2026-184",
	jobType: "plumbing",
	jobLabel: "Sanitär",
	status: "urgent",
	statusLabel: "Dringend",
	customer: "Musterhaus Verwaltung",
	address: {
		street: "Getreidegasse 15",
		postalCode: "5020",
		city: "Salzburg",
		latitude: 47.80039,
		longitude: 13.04399,
	},
	appointment: { date: "2026-09-15", timeFrom: "09:00", timeTo: "10:30" },
	summary: "Wasserverlust unter dem Waschbecken prüfen",
	contactName: "Maria Leitner",
	contactPhone: "+43 662 555 0101",
};

function withAddress(address: Record<string, unknown>) {
	return { ...validOrder, address: { ...validOrder.address, ...address } };
}

describe("parseWidgetPayload", () => {
	it("accepts the documented meta and data contract", () => {
		const payload = parseWidgetPayload(
			JSON.stringify({
				meta: {
					title: "Auftragskarte Salzburg",
					locale: "de-AT",
					center: { latitude: 47.8, longitude: 13 },
					zoom: 12,
					fitMarkers: false,
					tileUrl: "https://tiles.example/{z}/{x}/{y}.png",
					attribution: "© Beispiel",
				},
				data: [validOrder],
			}),
		);

		expect(payload.meta).toEqual({
			title: "Auftragskarte Salzburg",
			locale: "de-AT",
			center: { latitude: 47.8, longitude: 13 },
			zoom: 12,
			fitMarkers: false,
			tileUrl: "https://tiles.example/{z}/{x}/{y}.png",
			attribution: "© Beispiel",
		});
		expect(payload.skippedCount).toBe(0);
		expect(payload.orders).toEqual([
			{
				recordId: "5001",
				orderNumber: "AU-2026-184",
				jobType: "plumbing",
				jobLabel: "Sanitär",
				status: "urgent",
				statusLabel: "Dringend",
				customer: "Musterhaus Verwaltung",
				street: "Getreidegasse 15",
				postalCode: "5020",
				city: "Salzburg",
				latitude: 47.80039,
				longitude: 13.04399,
				appointment: { date: "2026-09-15", timeFrom: "09:00", timeTo: "10:30" },
				summary: "Wasserverlust unter dem Waschbecken prüfen",
				contactName: "Maria Leitner",
				contactPhone: "+43 662 555 0101",
			},
		]);
	});

	it("preserves German umlauts in interface data", () => {
		const customer = "Größe, Straße, Öl, Äpfel und Grüße";

		expect(
			parseWidgetPayload({ data: [{ ...validOrder, customer }] }).orders[0]
				.customer,
		).toBe(customer);
	});

	it("rejects payloads that cannot drive the widget", () => {
		expect(() => parseWidgetPayload("{kaputt")).toThrow("gültiges JSON");
		expect(() => parseWidgetPayload("[]")).toThrow("JSON-Objekt");
		expect(() => parseWidgetPayload('{"data":{}}')).toThrow('"data"');
	});

	it("skips and counts orders without recordId or valid coordinates", () => {
		const payload = parseWidgetPayload({
			data: [
				validOrder,
				{ ...validOrder, recordId: "" },
				withAddress({ latitude: undefined }),
				withAddress({ latitude: "nicht erfasst" }),
				withAddress({ longitude: 213.5 }),
				withAddress({ latitude: 91 }),
				withAddress({ latitude: 0, longitude: 0 }),
				withAddress({ latitude: Number.NaN }),
				{ ...validOrder, address: null },
				null,
				"5009",
			],
		});

		expect(payload.orders.map((order) => order.recordId)).toEqual(["5001"]);
		expect(payload.skippedCount).toBe(10);
	});

	it("accepts numeric strings as coordinates and numbers as recordId", () => {
		const payload = parseWidgetPayload({
			data: [
				{ ...withAddress({ latitude: "47.8", longitude: " 13.04 " }), recordId: 77 },
			],
		});

		expect(payload.orders[0]).toMatchObject({
			recordId: "77",
			latitude: 47.8,
			longitude: 13.04,
		});
	});

	it("maps unknown job types and statuses without failing", () => {
		const [order] = parseWidgetPayload({
			data: [{ ...validOrder, jobType: "gardening", status: "on-hold", statusLabel: "" }],
		}).orders;

		expect(order.jobType).toBe("other");
		expect(order.status).toBe("unknown");
		expect(order.statusLabel).toBe("on-hold");
	});

	it("falls back to default meta values", () => {
		expect(parseWidgetPayload({ data: [] }).meta).toEqual(DEFAULT_META);
		expect(
			parseWidgetPayload({
				meta: { center: { latitude: "x" }, zoom: 42, tileUrl: "" },
				data: [],
			}).meta,
		).toEqual(DEFAULT_META);
	});
});

describe("isMockMode", () => {
	it("enables mock data only for the data=test URL parameter", () => {
		expect(isMockMode("?data=test")).toBe(true);
		expect(isMockMode("?data=production")).toBe(false);
		expect(isMockMode("?view=test")).toBe(false);
	});
});

const viewState: ReportedViewState = {
	selectedRecordId: "5002",
	activeJobTypes: ["plumbing", "electrical"],
	visibleRecordIds: ["5001", "5002"],
};

describe("FM processing feedback", () => {
	it("awaits FM processing when FileMaker requests current view state", async () => {
		const callbacks = installApi();
		mockFMResult("Data processed");

		const adapterResult = window.fmWidgetRequestData?.();

		expect(adapterResult).toBeUndefined();
		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportData", {
			data: viewState,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("data", {
			script: "fmWidget_reportData",
			parameter: { data: viewState },
		});
		await vi.waitFor(() => {
			expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
				"data",
				"Data processed",
			);
		});
	});

	it("awaits FM processing when FileMaker requests dirty state", async () => {
		const callbacks = installApi();
		mockFMResult("State processed");

		await window.fmWidget?.requestState();

		expect(performScriptMock).toHaveBeenCalledWith("fmWidget_reportState", {
			dirty: false,
		});
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("state", {
			script: "fmWidget_reportState",
			parameter: { dirty: false },
		});
		expect(callbacks.onRequestSuccess).toHaveBeenCalledWith(
			"state",
			"State processed",
		);
	});

	it("reports an FM processing failure to the interface", async () => {
		const callbacks = installApi();
		mockFMError("Validation failed");

		await window.fmWidget?.requestData();

		expect(callbacks.onError).toHaveBeenCalledWith(
			expect.objectContaining({ message: "Validation failed" }),
		);
		expect(callbacks.onRequestSuccess).not.toHaveBeenCalled();
	});
});

describe("sendEvent", () => {
	it("sends open-order fire-and-forget without the FMGofer envelope", () => {
		const callbacks = installApi();
		const data = { recordId: "5002", orderNumber: "AU-2026-185" };

		window.fmWidget?.sendEvent("open-order", data);

		expect(window.FileMaker.PerformScriptWithOption).toHaveBeenCalledWith(
			"fmWidget_handleEvent",
			'{"event":"open-order","data":{"recordId":"5002","orderNumber":"AU-2026-185"}}',
			"0",
		);
		expect(performScriptMock).not.toHaveBeenCalled();
		expect(callbacks.onRequestStart).toHaveBeenCalledWith("event", {
			script: "fmWidget_handleEvent",
			parameter: { event: "open-order", data },
		});
		expect(callbacks.onError).not.toHaveBeenCalled();
	});

	it("only previews the event in mock mode", () => {
		const callbacks = installApi("?data=test");

		window.fmWidget?.sendEvent("open-order", { recordId: "5001" });

		expect(window.FileMaker.PerformScriptWithOption).not.toHaveBeenCalled();
		expect(callbacks.onRequestStart).toHaveBeenCalledOnce();
		expect(callbacks.onError).not.toHaveBeenCalled();
	});

	it("reports an error when FileMaker is unavailable", () => {
		const callbacks = installApi("", false);

		window.fmWidget?.sendEvent("open-order", { recordId: "5001" });

		expect(callbacks.onError).toHaveBeenCalledWith(
			expect.objectContaining({ message: "FileMaker ist nicht verfügbar." }),
		);
		expect(callbacks.onRequestSuccess).not.toHaveBeenCalled();
	});
});

describe("createDirtyStatePayload", () => {
	it("reports only the dirty flag required by FM", () => {
		expect(createDirtyStatePayload(false)).toBe('{"dirty":false}');
	});
});

function installApi(search = "", withFileMaker = true) {
	vi.stubGlobal("window", {
		location: { search },
		...(withFileMaker
			? { FileMaker: { PerformScript: vi.fn(), PerformScriptWithOption: vi.fn() } }
			: {}),
	});

	const callbacks = {
		onError: vi.fn(),
		onLoad: vi.fn(),
		onRefreshStart: vi.fn(),
		onRequestStart: vi.fn(),
		onRequestSuccess: vi.fn(),
	};

	installFMWidgetApi({
		getData: () => viewState,
		getDirty: () => false,
		...callbacks,
	});

	return callbacks;
}

function mockFMResult(message: string) {
	performScriptMock.mockReturnValue(Promise.resolve(message));
}

function mockFMError(message: string) {
	performScriptMock.mockReturnValue(Promise.reject(message));
}
