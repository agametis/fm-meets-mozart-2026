import FMGofer from "fm-gofer";

import {
	JOB_TYPES,
	STATUSES,
	type JobType,
	type MapMeta,
	type Order,
	type ReportedViewState,
	type Status,
	type WidgetPayload,
} from "./types";

const FM_SCRIPTS = {
	getData: "fmWidget_getData",
	handleEvent: "fmWidget_handleEvent",
	reportData: "fmWidget_reportData",
	reportState: "fmWidget_reportState",
} as const;

type FMRequestKind = "data" | "state" | "event";

export interface FMRequestPreview {
	script: string;
	parameter: unknown;
}

interface FMWidgetApi {
	load: (payload: unknown) => void;
	refresh: () => Promise<void>;
	requestData: () => Promise<void>;
	requestState: () => Promise<void>;
	sendEvent: (event: string, data: Record<string, unknown>) => void;
}

interface InstallApiOptions {
	getData: () => ReportedViewState;
	getDirty: () => boolean;
	onLoad: (payload: WidgetPayload) => void;
	onError: (error: Error) => void;
	onRefreshStart: () => void;
	onRequestStart: (request: FMRequestKind, preview: FMRequestPreview) => void;
	onRequestSuccess: (request: FMRequestKind, message: string) => void;
}

declare global {
	interface Window {
		fmWidget?: FMWidgetApi;
		fmWidgetLoad?: FMWidgetApi["load"];
		fmWidgetRefresh?: () => void;
		fmWidgetRequestData?: () => void;
		fmWidgetRequestState?: () => void;
	}
}

export const DEFAULT_META: MapMeta = {
	title: "Auftragskarte",
	locale: "de-DE",
	center: { latitude: 47.8014, longitude: 13.0448 },
	zoom: 13,
	fitMarkers: true,
	tileUrl: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
	attribution: "© OpenStreetMap contributors",
};

export function isMockMode(search = window.location.search): boolean {
	return (
		import.meta.env.DEV && new URLSearchParams(search).get("data") === "test"
	);
}

/**
 * Prüft die Nutzlast aus FileMaker. Nur eine unbrauchbare Gesamtstruktur wirft;
 * einzelne Aufträge ohne recordId oder gültige Koordinaten werden gezählt und
 * ausgelassen, damit die Karte nie an einem Datensatz scheitert.
 */
export function parseWidgetPayload(input: unknown): WidgetPayload {
	let parsed: unknown = input;
	if (typeof input === "string") {
		try {
			parsed = JSON.parse(input);
		} catch {
			throw new Error("Die Widget-Daten sind kein gültiges JSON.");
		}
	}

	if (!isObject(parsed)) {
		throw new Error("Die Widget-Daten müssen ein JSON-Objekt sein.");
	}
	if (!Array.isArray(parsed.data)) {
		throw new Error('Die Widget-Daten brauchen ein Array unter "data".');
	}

	const orders: Order[] = [];
	for (const row of parsed.data) {
		const order = parseOrder(row);
		if (order) orders.push(order);
	}

	return {
		meta: parseMeta(parsed.meta),
		orders,
		skippedCount: parsed.data.length - orders.length,
	};
}

function parseMeta(value: unknown): MapMeta {
	if (!isObject(value)) return DEFAULT_META;

	const center = isObject(value.center)
		? toCoordinates(value.center.latitude, value.center.longitude)
		: null;
	const zoom = toNumber(value.zoom);

	return {
		title: text(value.title) || DEFAULT_META.title,
		locale: text(value.locale) || DEFAULT_META.locale,
		center: center ?? DEFAULT_META.center,
		zoom: zoom !== null && zoom >= 0 && zoom <= 19 ? zoom : DEFAULT_META.zoom,
		fitMarkers: value.fitMarkers !== false,
		tileUrl: text(value.tileUrl) || DEFAULT_META.tileUrl,
		attribution: text(value.attribution) || DEFAULT_META.attribution,
	};
}

function parseOrder(value: unknown): Order | null {
	if (!isObject(value)) return null;

	const recordId = text(value.recordId);
	const address = isObject(value.address) ? value.address : {};
	const coordinates = toCoordinates(address.latitude, address.longitude);
	if (!recordId || !coordinates) return null;

	const appointment = isObject(value.appointment) ? value.appointment : {};
	const jobType = text(value.jobType);
	const status = text(value.status);

	return {
		recordId,
		orderNumber: text(value.orderNumber),
		jobType: (JOB_TYPES as readonly string[]).includes(jobType)
			? (jobType as JobType)
			: "other",
		jobLabel: text(value.jobLabel),
		status: (STATUSES as readonly string[]).includes(status)
			? (status as Status)
			: "unknown",
		statusLabel: text(value.statusLabel) || status,
		customer: text(value.customer),
		street: text(address.street),
		postalCode: text(address.postalCode),
		city: text(address.city),
		...coordinates,
		appointment: {
			date: text(appointment.date),
			timeFrom: text(appointment.timeFrom),
			timeTo: text(appointment.timeTo),
		},
		summary: text(value.summary),
		contactName: text(value.contactName),
		contactPhone: text(value.contactPhone),
	};
}

/** Gültige WGS84-Koordinaten; 0/0 gilt als leerer FileMaker-Wert. */
function toCoordinates(
	latitudeValue: unknown,
	longitudeValue: unknown,
): { latitude: number; longitude: number } | null {
	const latitude = toNumber(latitudeValue);
	const longitude = toNumber(longitudeValue);
	if (latitude === null || longitude === null) return null;
	if (Math.abs(latitude) > 90 || Math.abs(longitude) > 180) return null;
	if (latitude === 0 && longitude === 0) return null;
	return { latitude, longitude };
}

function toNumber(value: unknown): number | null {
	if (typeof value === "string" && value.trim() !== "") value = Number(value);
	return typeof value === "number" && Number.isFinite(value) ? value : null;
}

function text(value: unknown): string {
	if (typeof value === "string") return value.trim();
	if (typeof value === "number" && Number.isFinite(value)) return String(value);
	return "";
}

function isObject(value: unknown): value is Record<string, unknown> {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function createDirtyStatePayload(dirty: boolean): string {
	return JSON.stringify({ dirty });
}

async function fetchWidgetPayload(): Promise<unknown> {
	if (import.meta.env.DEV && isMockMode()) {
		const { samplePayload } = await import("../sampleData");
		return samplePayload;
	}

	return FMGofer.PerformScript(FM_SCRIPTS.getData).json<unknown>();
}

function processInFM(script: string, parameter: unknown): Promise<string> {
	if (!window.FileMaker) {
		return Promise.reject(new Error("FileMaker ist nicht verfügbar."));
	}

	return FMGofer.PerformScript(script, parameter);
}

export function installFMWidgetApi(options: InstallApiOptions): () => void {
	const api: FMWidgetApi = {
		load(payload) {
			try {
				options.onLoad(parseWidgetPayload(payload));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async refresh() {
			options.onRefreshStart();
			try {
				options.onLoad(parseWidgetPayload(await fetchWidgetPayload()));
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestData() {
			const parameter = { data: options.getData() };
			options.onRequestStart("data", {
				script: FM_SCRIPTS.reportData,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportData, parameter);
				options.onRequestSuccess("data", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		async requestState() {
			const parameter = { dirty: options.getDirty() };
			options.onRequestStart("state", {
				script: FM_SCRIPTS.reportState,
				parameter,
			});
			try {
				const result = await processInFM(FM_SCRIPTS.reportState, parameter);
				options.onRequestSuccess("state", result);
			} catch (error) {
				options.onError(normalizeError(error));
			}
		},
		// Ohne Rückmeldung (freigegeben): FileMaker erhält den Parameter ohne FMGofer-Hülle.
		sendEvent(event, data) {
			const parameter = { event, data };
			options.onRequestStart("event", {
				script: FM_SCRIPTS.handleEvent,
				parameter,
			});
			if (isMockMode()) return;
			if (!window.FileMaker) {
				options.onError(new Error("FileMaker ist nicht verfügbar."));
				return;
			}
			window.FileMaker.PerformScriptWithOption(
				FM_SCRIPTS.handleEvent,
				JSON.stringify(parameter),
				"0",
			);
			options.onRequestSuccess("event", "An FileMaker übergeben.");
		},
	};

	window.fmWidget = api;
	window.fmWidgetLoad = api.load;
	window.fmWidgetRefresh = () => {
		void api.refresh();
	};
	window.fmWidgetRequestData = () => {
		void api.requestData();
	};
	window.fmWidgetRequestState = () => {
		void api.requestState();
	};

	return () => {
		if (window.fmWidget === api) {
			window.fmWidget = undefined;
			window.fmWidgetLoad = undefined;
			window.fmWidgetRefresh = undefined;
			window.fmWidgetRequestData = undefined;
			window.fmWidgetRequestState = undefined;
		}
	};
}

function normalizeError(error: unknown): Error {
	return error instanceof Error ? error : new Error(String(error));
}
