export const JOB_TYPES = [
	"plumbing",
	"electrical",
	"heating",
	"painting",
	"carpentry",
	"roofing",
] as const;

export const STATUSES = [
	"new",
	"scheduled",
	"in-progress",
	"urgent",
	"completed",
	"cancelled",
] as const;

/** Bekannte Auftragsart oder "other" für unbekannte Werte aus FileMaker. */
export type JobType = (typeof JOB_TYPES)[number] | "other";

/** Bekannter Status oder "unknown" für unbekannte Werte aus FileMaker. */
export type Status = (typeof STATUSES)[number] | "unknown";

export interface MapMeta {
	title: string;
	locale: string;
	center: { latitude: number; longitude: number };
	zoom: number;
	fitMarkers: boolean;
	tileUrl: string;
	attribution: string;
}

/** Ein Auftrag mit gültiger recordId und gültigen Koordinaten. */
export interface Order {
	recordId: string;
	orderNumber: string;
	jobType: JobType;
	jobLabel: string;
	status: Status;
	statusLabel: string;
	customer: string;
	street: string;
	postalCode: string;
	city: string;
	latitude: number;
	longitude: number;
	appointment: { date: string; timeFrom: string; timeTo: string };
	summary: string;
	contactName: string;
	contactPhone: string;
}

/** Validierte Nutzlast: nur anzeigbare Aufträge plus Anzahl der ausgelassenen. */
export interface WidgetPayload {
	meta: MapMeta;
	orders: Order[];
	skippedCount: number;
}

/** Darstellungszustand, den fmWidget_reportData erhält. */
export interface ReportedViewState {
	selectedRecordId: string | null;
	activeJobTypes: JobType[];
	visibleRecordIds: string[];
}
