import L from "leaflet";

import type { JobType, Order, Status } from "./fm/types";
import { formatAppointment } from "./orders";

// Alle SVG-Bausteine sind feste Konstanten. FileMaker-Texte gelangen nie in
// HTML-Strings; das Pop-up wird als DOM mit textContent aufgebaut.

/** Glyphen in einem 20x20-Raster, farbunabhängig unterscheidbar. */
const JOB_GLYPHS: Record<JobType, string> = {
	// Wassertropfen
	plumbing:
		'<path d="M10 1.5C10 1.5 3.5 9 3.5 13a6.5 6.5 0 0 0 13 0C16.5 9 10 1.5 10 1.5Z" fill="currentColor"/>',
	// Blitz
	electrical:
		'<path d="M11.5 1 3 11.5h6L8 19l9-11.5h-6Z" fill="currentColor"/>',
	// Flamme
	heating:
		'<path d="M10 1c1.5 4 6.5 6.5 6.5 12a6.5 6.5 0 0 1-13 0c0-3 1.5-5 3-6.5.5 2.5 1.5 4 3 4C10.5 7.5 9 4.5 10 1Z" fill="currentColor"/>',
	// Pinsel
	painting:
		'<path d="M12.5 1.5 18.5 7.5 11 15 5 9Z" fill="currentColor"/><path d="M4.5 10.5c-3 1-2.5 5-3.5 8 3-.5 7-.5 8-3.5Z" fill="currentColor"/>',
	// Handsäge
	carpentry:
		'<path d="M1 15.5 13 8v7.5Z" fill="currentColor"/><path d="M13 6.5h5.5v10H13Z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M1.5 15.5l1.4 2.5 1.4-2.5 1.4 2.5 1.4-2.5 1.4 2.5 1.4-2.5 1.4 2.5 1.4-2.5" fill="none" stroke="currentColor" stroke-width="1.4"/>',
	// Hausdach
	roofing:
		'<path d="M1 11 10 2.5 19 11" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linejoin="round"/><path d="M4.5 9.5V18h11V9.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M14.5 2.5v4" stroke="currentColor" stroke-width="2.4"/>',
	// Punkt
	other: '<circle cx="10" cy="10" r="4.5" fill="currentColor"/>',
};

interface StatusStyle {
	color: string;
	/** Abzeichen oben rechts (20x20-Raster), leer = keines. */
	badge: string;
	contour: "normal" | "double" | "dashed";
}

export const STATUS_STYLES: Record<Status, StatusStyle> = {
	new: {
		color: "#2563eb",
		badge:
			'<path d="M10 3.5l1.9 4 4.4.5-3.3 3 .9 4.3L10 13.1l-3.9 2.2.9-4.3-3.3-3 4.4-.5Z" fill="#1e293b"/>',
		contour: "normal",
	},
	scheduled: { color: "#7c3aed", badge: "", contour: "normal" },
	"in-progress": {
		color: "#ea580c",
		badge:
			'<circle cx="10" cy="10" r="5.5" fill="none" stroke="#1e293b" stroke-width="1.8"/><path d="M10 4.5a5.5 5.5 0 0 1 0 11Z" fill="#1e293b"/>',
		contour: "normal",
	},
	urgent: {
		color: "#dc2626",
		badge:
			'<path d="M10 4v7.5" stroke="#1e293b" stroke-width="2.6" stroke-linecap="round"/><circle cx="10" cy="15" r="1.6" fill="#1e293b"/>',
		contour: "double",
	},
	completed: {
		color: "#16a34a",
		badge:
			'<path d="M5.5 10.5 8.5 13.5 14.5 6.5" fill="none" stroke="#1e293b" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
		contour: "normal",
	},
	cancelled: { color: "#6b7280", badge: "", contour: "dashed" },
	unknown: {
		color: "#6b7280",
		badge:
			'<path d="M7.3 7.5a2.8 2.8 0 1 1 3.9 2.6c-.8.4-1.2 1-1.2 1.9v.5" fill="none" stroke="#1e293b" stroke-width="2" stroke-linecap="round"/><circle cx="10" cy="15.3" r="1.3" fill="#1e293b"/>',
		contour: "normal",
	},
};

const PIN_PATH =
	"M18 46S3.5 29.5 3.5 17.5a14.5 14.5 0 0 1 29 0C32.5 29.5 18 46 18 46Z";

/** Pin als SVG-String aus Konstanten: Status = Farbe/Kontur/Abzeichen, Art = Glyphe. */
export function pinSvg(jobType: JobType, status: Status): string {
	const style = STATUS_STYLES[status];
	const outline =
		style.contour === "double"
			? `<path d="${PIN_PATH}" fill="none" stroke="#1e293b" stroke-width="5"/><path d="${PIN_PATH}" fill="${style.color}" stroke="#ffffff" stroke-width="2"/>`
			: `<path d="${PIN_PATH}" fill="${style.color}" stroke="#1e293b" stroke-width="1.6"${
					style.contour === "dashed" ? ' stroke-dasharray="3 2.5"' : ""
				}/>`;
	const badge = style.badge
		? `<circle cx="29" cy="7" r="6.5" fill="#ffffff" stroke="#1e293b" stroke-width="1.2"/><g transform="translate(23.5 1.5) scale(.55)">${style.badge}</g>`
		: "";

	return `<svg class="pin-svg${
		style.contour === "dashed" ? " pin-svg--muted" : ""
	}" viewBox="-2 -2 40 50" width="40" height="50" aria-hidden="true" focusable="false">${outline}<circle cx="18" cy="17.5" r="10" fill="#ffffff"/><g transform="translate(10 9.5) scale(.8)" color="#1e293b">${
		JOB_GLYPHS[jobType]
	}</g>${badge}</svg>`;
}

/** Kleines Symbol der Auftragsart für Filter und Legende. */
export function glyphSvg(jobType: JobType): string {
	return `<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true" focusable="false">${JOB_GLYPHS[jobType]}</svg>`;
}

export function createOrderIcon(order: Order): L.DivIcon {
	return L.divIcon({
		className: "order-pin",
		html: pinSvg(order.jobType, order.status),
		iconSize: [40, 50],
		iconAnchor: [20, 48],
		popupAnchor: [0, -44],
	});
}

export function createPopupContent(
	order: Order,
	locale: string,
	onOpenOrder: (order: Order) => void,
): HTMLElement {
	const root = element("div", "order-popup");

	const header = element("div", "order-popup__header");
	header.append(
		element("strong", "order-popup__number", order.orderNumber || "–"),
	);
	const status = element(
		"span",
		"order-popup__status",
		order.statusLabel || "Unbekannt",
	);
	status.style.setProperty("--status-color", STATUS_STYLES[order.status].color);
	header.append(status);
	root.append(header);

	const cityLine = [order.postalCode, order.city].filter(Boolean).join(" ");
	const rows: [string, string][] = [
		["Kunde", order.customer],
		["Adresse", [order.street, cityLine].filter(Boolean).join("\n")],
		["Termin", formatAppointment(order.appointment, locale)],
		["Beschreibung", order.summary],
		["Ansprechpartner", order.contactName],
		["Telefon", order.contactPhone],
	];
	const list = element("dl", "order-popup__details");
	for (const [label, value] of rows) {
		if (!value) continue;
		list.append(element("dt", "", label), element("dd", "", value));
	}
	root.append(list);

	const button = element("button", "order-popup__action", "Mehr Details");
	button.setAttribute("type", "button");
	button.addEventListener("click", () => onOpenOrder(order));
	root.append(button);

	return root;
}

function element<K extends keyof HTMLElementTagNameMap>(
	tag: K,
	className: string,
	text?: string,
): HTMLElementTagNameMap[K] {
	const node = document.createElement(tag);
	if (className) node.className = className;
	if (text !== undefined) node.textContent = text;
	return node;
}
