import { describe, expect, it } from "vitest";

import type { JobType, Order } from "./fm/types";
import {
	createReportedViewState,
	filterOrders,
	formatAppointment,
	skippedMessage,
	summarizeJobTypes,
} from "./orders";

function order(recordId: string, jobType: JobType, jobLabel = ""): Order {
	return {
		recordId,
		orderNumber: `AU-${recordId}`,
		jobType,
		jobLabel,
		status: "scheduled",
		statusLabel: "Eingeplant",
		customer: "",
		street: "",
		postalCode: "",
		city: "",
		latitude: 47.8,
		longitude: 13.04,
		appointment: { date: "", timeFrom: "", timeTo: "" },
		summary: "",
		contactName: "",
		contactPhone: "",
	};
}

const orders = [
	order("5001", "plumbing", "Sanitär"),
	order("5002", "electrical", "Elektro"),
	order("5003", "plumbing"),
	order("5009", "other"),
];

describe("summarizeJobTypes", () => {
	it("lists all known job types, labels from data and Sonstige only when present", () => {
		const summaries = summarizeJobTypes(orders);

		expect(summaries.map((summary) => summary.jobType)).toEqual([
			"plumbing",
			"electrical",
			"heating",
			"painting",
			"carpentry",
			"roofing",
			"other",
		]);
		expect(summaries[0]).toEqual({ jobType: "plumbing", label: "Sanitär", count: 2 });
		expect(summaries[2]).toEqual({ jobType: "heating", label: "Heizung", count: 0 });
		expect(summaries[6]).toEqual({ jobType: "other", label: "Sonstige", count: 1 });
		expect(summarizeJobTypes(orders.slice(0, 3))).toHaveLength(6);
	});
});

describe("filter and reported view state", () => {
	it("returns the visible record ids for the active job types", () => {
		const active = new Set<JobType>(["plumbing", "other"]);

		expect(filterOrders(orders, active).map((o) => o.recordId)).toEqual([
			"5001",
			"5003",
			"5009",
		]);
		expect(createReportedViewState(orders, active, "5003")).toEqual({
			selectedRecordId: "5003",
			activeJobTypes: ["plumbing", "other"],
			visibleRecordIds: ["5001", "5003", "5009"],
		});
	});

	it("drops a selection that is hidden by the filter", () => {
		expect(
			createReportedViewState(orders, new Set<JobType>(["electrical"]), "5001"),
		).toEqual({
			selectedRecordId: null,
			activeJobTypes: ["electrical"],
			visibleRecordIds: ["5002"],
		});
	});
});

describe("formatAppointment", () => {
	it("formats date and time window with the locale", () => {
		expect(
			formatAppointment(
				{ date: "2026-09-15", timeFrom: "09:00", timeTo: "10:30" },
				"de-AT",
			),
		).toBe("Di., 15.09.2026, 09:00–10:30");
	});

	it("keeps invalid dates raw and tolerates missing parts", () => {
		expect(
			formatAppointment({ date: "15.9.2026", timeFrom: "09:00", timeTo: "" }, "de-AT"),
		).toBe("15.9.2026, 09:00");
		expect(
			formatAppointment({ date: "2026-02-30", timeFrom: "", timeTo: "" }, "de-AT"),
		).toBe("2026-02-30");
		expect(formatAppointment({ date: "", timeFrom: "", timeTo: "" }, "de-AT")).toBe("");
	});

	it("falls back when FileMaker sends an invalid locale", () => {
		expect(
			formatAppointment({ date: "2026-09-15", timeFrom: "", timeTo: "" }, "kein_locale!"),
		).toBe("Di., 15.09.2026");
	});
});

describe("skippedMessage", () => {
	it("uses singular and plural", () => {
		expect(skippedMessage(1)).toMatch(/^1 Auftrag .* wird nicht angezeigt\.$/);
		expect(skippedMessage(2)).toMatch(/^2 Aufträge .* werden nicht angezeigt\.$/);
	});
});
