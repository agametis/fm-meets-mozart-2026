import {
	JOB_TYPES,
	type JobType,
	type Order,
	type ReportedViewState,
} from "./fm/types";

export const DEFAULT_JOB_LABELS: Record<JobType, string> = {
	plumbing: "Sanitär",
	electrical: "Elektro",
	heating: "Heizung",
	painting: "Malerarbeiten",
	carpentry: "Tischlerei",
	roofing: "Dacharbeiten",
	other: "Sonstige",
};

export interface JobTypeSummary {
	jobType: JobType;
	label: string;
	count: number;
}

/**
 * Filterschalter: immer die sechs bekannten Arten, "Sonstige" nur bei Bedarf.
 * Das Label kommt aus dem ersten jobLabel der Daten, sonst der Standardtext.
 */
export function summarizeJobTypes(orders: Order[]): JobTypeSummary[] {
	const types: JobType[] = orders.some((order) => order.jobType === "other")
		? [...JOB_TYPES, "other"]
		: [...JOB_TYPES];

	return types.map((jobType) => {
		const matching = orders.filter((order) => order.jobType === jobType);
		const dataLabel =
			jobType === "other"
				? ""
				: (matching.find((order) => order.jobLabel)?.jobLabel ?? "");
		return {
			jobType,
			label: dataLabel || DEFAULT_JOB_LABELS[jobType],
			count: matching.length,
		};
	});
}

export function filterOrders(
	orders: Order[],
	activeJobTypes: ReadonlySet<JobType>,
): Order[] {
	return orders.filter((order) => activeJobTypes.has(order.jobType));
}

export function createReportedViewState(
	orders: Order[],
	activeJobTypes: ReadonlySet<JobType>,
	selectedRecordId: string | null,
): ReportedViewState {
	const visible = filterOrders(orders, activeJobTypes);
	return {
		selectedRecordId: visible.some((order) => order.recordId === selectedRecordId)
			? selectedRecordId
			: null,
		activeJobTypes: summarizeJobTypes(orders)
			.map((summary) => summary.jobType)
			.filter((jobType) => activeJobTypes.has(jobType)),
		visibleRecordIds: visible.map((order) => order.recordId),
	};
}

/** "Di., 15.09.2026, 09:00–10:30"; ungültige Datumswerte bleiben unverändert. */
export function formatAppointment(
	appointment: Order["appointment"],
	locale: string,
): string {
	const { date, timeFrom, timeTo } = appointment;
	const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
	let datePart = date;

	if (match) {
		const [year, month, day] = match.slice(1).map(Number);
		// Lokales Datum ohne Zeitzonenverschiebung.
		const value = new Date(year, month - 1, day);
		if (value.getMonth() === month - 1 && value.getDate() === day) {
			datePart = formatDate(value, locale);
		}
	}

	const timePart = timeFrom && timeTo ? `${timeFrom}–${timeTo}` : timeFrom || timeTo;
	return [datePart, timePart].filter(Boolean).join(", ");
}

function formatDate(value: Date, locale: string): string {
	const options: Intl.DateTimeFormatOptions = {
		weekday: "short",
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
	};
	try {
		return new Intl.DateTimeFormat(locale, options).format(value);
	} catch {
		// Ungültiges meta.locale aus FileMaker.
		return new Intl.DateTimeFormat("de-DE", options).format(value);
	}
}

export function skippedMessage(count: number): string {
	return count === 1
		? "1 Auftrag ohne gültige Koordinaten oder Datensatz-ID wird nicht angezeigt."
		: `${count} Aufträge ohne gültige Koordinaten oder Datensatz-ID werden nicht angezeigt.`;
}
